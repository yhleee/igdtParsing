CREATE TABLE `settle_team_project` (
    `team_project_no` int(11) NOT NULL AUTO_INCREMENT COMMENT '정보전략팀 투자/비용 취합 No',
    `team_project_settle_type` int(2) unsigned NOT NULL COMMENT '정보전략팀 투자/비용 취합 정산타입(1:투자, 2:비용)',
    `team_project_type` int(2) unsigned NOT NULL COMMENT '정보전략팀 투자/비용 취합 구분 ID',
    `team_project_department` varchar(40) NOT NULL COMMENT '정보전략팀 투자/비용 취합 발의 부서',
    `team_project_deal_check` varchar(180) NOT NULL COMMENT '정보전략팀 투자/비용 취합 사내거래 확인서명',
    `team_project_document_number` varchar(120) NOT NULL COMMENT '정보전략팀 투자/비용 취합 품의서 번호',
    `team_project_document_title` varchar(180) NOT NULL COMMENT '정보전략팀 투자/비용 취합 품의서 제목',
    `team_project_price` int(10) unsigned NOT NULL COMMENT '정보전략팀 투자/비용 취합 금액',
    `team_project_cost_center` varchar(50) NOT NULL COMMENT '정보전략팀 투자/비용 취합 귀속 코스트 센터',
    `team_project_wbs_code` varchar(50) DEFAULT NULL COMMENT '정보전략팀 투자/비용 취합 WBS 코드',
    `team_project_active_type` char(1) NOT NULL DEFAULT 'N' COMMENT '정보전략팀 투자/비용 취합 활성화 여부',
    `team_project_reg_user` varchar(15) NOT NULL COMMENT '정보전략팀 투자/비용 취합 등록자ID',
    `team_project_reg_date` datetime DEFAULT current_timestamp() COMMENT '정보전략팀 투자/비용 취합 등록일시',
    PRIMARY KEY (`team_project_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='정보전략팀 투자/비용 취합';
