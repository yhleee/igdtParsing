CREATE TABLE `settle_hq_invest_store` (
    `INVEST_STORE_NO` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '투자 매장 번호',
    `TO_CST_CNTR_CD` varchar(10) DEFAULT NULL COMMENT '변경코스트센터',
    `INVEST_STORE_NAME` varchar(200) NOT NULL COMMENT '투자 매장명',
    `INVEST_STORE_OPEN_DTIME` datetime NOT NULL COMMENT '투자 매장 오픈일자',
    `INVEST_STORE_TYPE` int(2) NOT NULL COMMENT '투자 매장 신규/리뉴얼 여부(1:신규, 2:리뉴얼)',
    `INVEST_STORE_REMARKS` varchar(250) DEFAULT NULL COMMENT '비고',
    `SYS_REG_DTIME` datetime NOT NULL COMMENT '시스템등록일시',
    `SYS_REGR_ID` varchar(20) NOT NULL COMMENT '시스템등록자아이디',
    PRIMARY KEY (`INVEST_STORE_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='투자(매장) 월별 정산리스트의 1depth 매장 리스트';

CREATE TABLE `settle_hq_invest_store_asset` (
    `INVEST_STORE_ASSET_NO` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '투자 매장 자산 번호',
    `INVEST_STORE_NO` int(11) unsigned NOT NULL,
    `INVEST_STORE_ASSET_TYPE` int(1) unsigned NOT NULL COMMENT '투자 매장 자산 신규/재사용 여부(1:신규, 2:재사용)',
    `INVEST_STORE_ASSET_RACK` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 RACK',
    `INVEST_STORE_ASSET_VPN` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 VPN',
    `INVEST_STORE_ASSET_LED` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 LED',
    `INVEST_STORE_ASSET_SETTOP_PC` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 셋탑PC',
    `INVEST_STORE_ASSET_POS` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 POS',
    `INVEST_STORE_ASSET_SURGE_PROTECTOR` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 서지보호기',
    `INVEST_STORE_ASSET_HUB` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 HUB',
    `INVEST_STORE_ASSET_HAND_SCANNER` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 핸드스캐너',
    `INVEST_STORE_ASSET_PDA` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 PDA',
    `INVEST_STORE_ASSET_SIGN_PAD` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 사인패드',
    `INVEST_STORE_ASSET_CAT` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 CAT',
    `INVEST_STORE_ASSET_SWITCH` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 스위치',
    `INVEST_STORE_ASSET_IC_TERMINAL` int(3) unsigned DEFAULT 0 COMMENT '투자 매장 자산 IC단말기',
    `SYS_REG_DTIME` datetime NOT NULL COMMENT '시스템등록일시',
    `SYS_REGR_ID` varchar(20) NOT NULL COMMENT '시스템등록자아이디',
    PRIMARY KEY (`INVEST_STORE_ASSET_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='투자(매장) 월별 정산리스트의 1depth 매장 리스트';
