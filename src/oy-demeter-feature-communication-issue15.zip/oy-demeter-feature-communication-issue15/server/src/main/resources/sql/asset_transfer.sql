CREATE TABLE `settle_asset_transfer` (
    `ASSET_CD` varchar(30) NOT NULL COMMENT '자산번호',
    `ASSET_TXT` varchar(180) DEFAULT NULL COMMENT '자산명',
    `ASSET_LO` varchar(150) DEFAULT NULL COMMENT '위치',
    `MNG_CST_CNTR_CD` varchar(10) DEFAULT NULL COMMENT '관리코스트센터코드',
    `MNG_CST_CNTR_NM` varchar(200) DEFAULT NULL COMMENT '관리코스트센터명',
    `MNG_MN` varchar(40) DEFAULT NULL COMMENT '관리담당자명',
    `ASSET_PART_TYPE_CD` char(2) NOT NULL COMMENT '이체구분(01:전체, 02:비율, 03:수량)',
    `PART_RATE` int(3) DEFAULT NULL COMMENT '이체비율(%)',
    `PROC_CNT` int(6) DEFAULT NULL COMMENT '이체수량',
    `TO_CST_CNTR_CD` varchar(10) DEFAULT NULL COMMENT '변경코스트센터',
    `TO_CST_CNTR_NM` varchar(200) DEFAULT NULL COMMENT '변경코스트센터명',
    `SYS_REG_DTIME` datetime DEFAULT current_timestamp() COMMENT '등록일시',
    PRIMARY KEY (`ASSET_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='자산이체 일반경비 e-ACC 업로드 취합용(임시)';
