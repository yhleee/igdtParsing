CREATE TABLE `st_schedule` (
    `SCHEDULE_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Schedule No',
    `SCHEDULE_TYPE` char(2) NOT NULL COMMENT 'Schedule 구분(1:방화벽)',
    `SCHEDULE_SYSTEM_NAME` varchar(45) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '시스템명',
    `SCHEDULE_PURPOSE` text CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '용도',
    `SCHEDULE_JSON_CONTENTS` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Schedule JSON Contents' CHECK (json_valid(`SCHEDULE_JSON_CONTENTS`)),
    `USE_YN` char(1) DEFAULT 'N' COMMENT '사용여부(Y or N)',
    `POLICY_START_DATE` varchar(40) NOT NULL COMMENT '정책 시작일자(ex: YYYY-MM-DD)',
    `POLICY_END_DATE` varchar(40) NOT NULL COMMENT '정책 종료일자(ex: YYYY-MM-DD)',
    `POLICY_NOTICE_DATE` varchar(40) NOT NULL COMMENT '알림일자 설정(ex: YYYY-MM-DD)',
    `DOC_NUMBER` varchar(50) DEFAULT NULL,
    `SYS_REGR_ID` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '시스템 등록일',
    `SYS_REG_DTIME` datetime DEFAULT current_timestamp() COMMENT '시스템 등록일자',
    `SYS_MODR_ID` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '시스템 수정자',
    `SYS_MOD_DTIME` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '시스템 수정일자',
    PRIMARY KEY (`SCHEDULE_NO`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='알림 설정 테이블';
