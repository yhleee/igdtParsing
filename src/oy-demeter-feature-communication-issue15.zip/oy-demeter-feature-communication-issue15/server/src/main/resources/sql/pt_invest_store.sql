CREATE TABLE `settle_pt_invest_store` (
    `INVEST_STORE_NO` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '투자 매장 번호',
    `INVEST_STORE_NAME` varchar(200) NOT NULL COMMENT '투자 매장명',
    `INVEST_STORE_TYPE` int(2) unsigned NOT NULL COMMENT '투자 매장 신규/리뉴얼 여부(1:신규, 2:리뉴얼)',
    `INVEST_STORE_CATEGORY_NO` int(2) unsigned NOT NULL COMMENT '업체 카테고리 번호(1:RACK, 2:VPN, 3:IC단말기, 4:IT부문)',
    `INVEST_STORE_ASSET_NO` int(2) unsigned NOT NULL COMMENT '장비 카테고리 번호(1:RACK, 2:VPN, 3:IC단말기, 4:LED, 5:셋탑PC, 6:POS, 7:서지보호기, 8:HUB, 9:핸드스캐너, 10:PDA, 11:사인패드, 12:CAT, 13:스위치)',
    `INVEST_STORE_COUNT` int(3) unsigned DEFAULT 0 COMMENT '수량',
    `INVEST_STORE_PRICE` int(10) unsigned DEFAULT 0 COMMENT '단가',
    `INVEST_STORE_REMARKS` varchar(250) DEFAULT NULL COMMENT '비고',
    `INVEST_STORE_ACTIVE_TYPE` char(1) NOT NULL DEFAULT 'N' COMMENT '팀프로젝트 활성화 여부(Y:비활성화, N:활성화)',
    `SYS_REG_DTIME` datetime NOT NULL COMMENT '시스템등록일시',
    `SYS_REGR_ID` varchar(20) NOT NULL COMMENT '시스템등록자아이디',
    PRIMARY KEY (`INVEST_STORE_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='투자(매장) 업체담당자 월별 정산리스트';
