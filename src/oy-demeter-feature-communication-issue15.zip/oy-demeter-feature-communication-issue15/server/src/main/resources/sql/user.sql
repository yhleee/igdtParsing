CREATE TABLE `st_menu_usr_grp` (
    `USR_GRP_NO` int(11) NOT NULL AUTO_INCREMENT,
    `USR_GRP_NM` varchar(30) NOT NULL COMMENT '사용자그룹명',
    PRIMARY KEY (`USR_GRP_NO`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='메뉴사용자그룹';

CREATE TABLE `st_menu_usr_grp_mppg` (
    `MENU_NO` int(11) NOT NULL COMMENT '메뉴번호',
    `USR_GRP_NO` int(11) NOT NULL COMMENT '사용자그룹번호',
    PRIMARY KEY (`MENU_NO`,`USR_GRP_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='메뉴사용자그룹매핑';

CREATE TABLE `st_oyis_menu` (
    `MENU_NO` int(11) NOT NULL AUTO_INCREMENT,
    `MENU_NM` varchar(100) NOT NULL COMMENT '메뉴명',
    `MENU_ICON_NM` varchar(40) DEFAULT NULL COMMENT '메뉴아이콘명',
    `UPR_MENU_NO` int(11) DEFAULT NULL COMMENT '상위메뉴번호',
    `MENU_LVL` int(5) NOT NULL COMMENT '메뉴레벨',
    `SORT_SEQ` int(11) NOT NULL COMMENT '정렬순번',
    `MENU_URL` varchar(300) DEFAULT NULL COMMENT '메뉴URL',
    `USE_YN` varchar(1) NOT NULL DEFAULT 'N' COMMENT '사용여부',
    `SYS_REG_DTIME` datetime NOT NULL COMMENT '시스템등록일시',
    `SYS_REGR_ID` varchar(20) NOT NULL COMMENT '시스템등록자아이디',
    `SYS_MOD_DTIME` datetime DEFAULT NULL COMMENT '시스템수정일시',
    `SYS_MODR_ID` varchar(20) DEFAULT NULL COMMENT '시스템수정자아이디',
    PRIMARY KEY (`MENU_NO`),
    KEY `ST_OYIS_MENU_IX1` (`UPR_MENU_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='OYIS메뉴';

CREATE TABLE `st_usr` (
    `USR_NO` int(11) NOT NULL AUTO_INCREMENT,
    `LOGIN_ID` varchar(40) NOT NULL COMMENT '로그인아이디',
    `PASSWD` varchar(152) NOT NULL COMMENT '비밀번호',
    `admin_yn` varchar(1) DEFAULT 'N',
    `LAST_LOGIN_DTIME` datetime DEFAULT NULL COMMENT '최종로그인일시',
    `LAST_LOGIN_IP` varchar(50) DEFAULT NULL COMMENT '최종로그인IP',
    PRIMARY KEY (`USR_NO`),
    UNIQUE KEY `LOGIN_ID` (`LOGIN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='사용자';

CREATE TABLE `st_usr_grp_mppg` (
    `USR_GRP_NO` int(11) NOT NULL COMMENT '사용자그룹번호',
    `USR_NO` int(11) NOT NULL COMMENT '사용자번호',
    PRIMARY KEY (`USR_GRP_NO`,`USR_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='사용자그룹매핑';


