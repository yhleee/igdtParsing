package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class MemberVO extends BaseVO {
    private Long memberNo;
    private String memberId;
    private Long employeeNo;
    private String memberName;
    private String password;
}
