package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import java.util.List;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.common.validator.ValidationUtil;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuAuthorityTree;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuMappingGroup;
import kr.co.oliveyoung.demeter.services.api.setting.service.UserMenuAuthorityService;
import kr.co.oliveyoung.demeter.services.api.setting.validator.UserMenuAuthorityValidator;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("api/setting")
public class UserMenuAuthorityController {

    @Autowired
    private UserMenuAuthorityService userMenuAuthorityService;

    @Autowired
    private UserMenuAuthorityValidator userMenuAuthorityValidator;

    @ApiOperation("Fetch Authority")
    @GetMapping("/authority")
    public ApiResponseMessage fetchAuthority(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO) {
        List<UserMenuAuthorityTree> authorities = userMenuAuthorityService.getUserMenuAuthorities(tokenVO.getUserNo());
        ApiResponseMessage message = new ApiResponseMessage(ResponseResult.SUCCESS);
        message.setContents(authorities);
        return message;
    }

    @ApiOperation("Fetch Authority")
    @GetMapping("/authorizedGroups")
    public ApiResponseMessage fetchAuthorizedGroups(
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @RequestParam("menuNo") Integer menuNo) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        ApiResponseMessage message = new ApiResponseMessage(ResponseResult.SUCCESS);
        message.setContents(userMenuAuthorityService.fetchAuthorizedGroups(menuNo));
        return message;
    }

    @ApiOperation("Fetch Authority")
    @GetMapping("/unauthorizedGroups")
    public ApiResponseMessage fetchUnauthorizedGroups(
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @RequestParam("menuNo") Integer menuNo) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        ApiResponseMessage message = new ApiResponseMessage(ResponseResult.SUCCESS);
        message.setContents(userMenuAuthorityService.fetchUnauthorizedGroups(menuNo));
        return message;
    }

    @ApiOperation("Fetch group Authority")
    @GetMapping("/group/{groupNo}/authority")
    public ApiResponseMessage fetchGroupAuthority(@PathVariable("groupNo")Integer groupNo) {        ;
        ApiResponseMessage message = new ApiResponseMessage(ResponseResult.SUCCESS);
        message.setContents(userMenuAuthorityService.fetchGroupMenuAuthorities(groupNo));
        return message;
    }

    @ApiOperation("Modify Authority")
    @PutMapping("/authority")
    public ApiResponseMessage putAuthority(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
                                           @RequestBody UserMenuMappingGroup userMenuGroup, BindingResult errors) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }

        userMenuAuthorityValidator.validate(userMenuGroup, errors);
        if (errors.hasErrors()) {
            return new ApiResponseMessage(ResponseResult.FAIL, ValidationUtil.getFirstErrorMessage(errors));
        }

        userMenuAuthorityService.modifyUserMenuAuthorities(userMenuGroup);

        ApiResponseMessage message = new ApiResponseMessage(ResponseResult.SUCCESS);
        return message;
    }
}
