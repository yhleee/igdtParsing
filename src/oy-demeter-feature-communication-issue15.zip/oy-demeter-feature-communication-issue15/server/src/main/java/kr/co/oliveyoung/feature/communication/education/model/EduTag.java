package kr.co.oliveyoung.feature.communication.education.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EduTag {
    private Long tagNo;
    private String tagName;
    private String tagTypeCode;
    private Long tagGroupNo;
    private String tagOrder;
    @JsonIgnore
    private Integer creator;
    @JsonIgnore
    private String createDatetime;
    @JsonIgnore
    private Integer updater;
    @JsonIgnore
    private String updateDatetime;
}
