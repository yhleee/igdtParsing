package kr.co.oliveyoung.feature.setting;

import java.util.List;
import java.util.Map;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.setting.model.UserMenu;

@MySqlOyisMapper
public interface UserMenuMapper {
    List<UserMenu> selectUserMenu(Map<String, Object> param);
    int insertUserMenu(UserMenu userMenu);
    int updateUserMenu(UserMenu userMenu);
    int deleteUserMenu(Integer... menuNos);
    List<UserMenu> selectUserAuthorityMenuList(Integer userNo);
}
