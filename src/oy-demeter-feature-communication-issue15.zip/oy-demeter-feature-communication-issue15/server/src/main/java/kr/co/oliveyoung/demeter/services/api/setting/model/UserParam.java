package kr.co.oliveyoung.demeter.services.api.setting.model;

import lombok.Data;

@Data
public class UserParam {
    // -------------------- parameter
    // loginId
    private String loginCode1;
    // password
    private String loginCode2;
    // -------------------- parameter end

    private String loginId;
    private String password;
    private String loginIp;
}
