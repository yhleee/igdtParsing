package kr.co.oliveyoung.demeter.common.csv.upload;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public abstract class FileDBInsertParser {
    public abstract List<Map<String, Object>> getParseAssetList() throws IOException;
    public abstract List<Map<String, Object>> getParsePtInvestStoreList() throws IOException;
}
