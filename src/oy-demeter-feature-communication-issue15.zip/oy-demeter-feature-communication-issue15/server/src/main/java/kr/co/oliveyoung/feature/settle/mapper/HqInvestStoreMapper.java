package kr.co.oliveyoung.feature.settle.mapper;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.demeter.services.api.settle.param.HqInvestStoreListParam;
import kr.co.oliveyoung.feature.settle.HqInvestStore;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@MySqlOyisMapper
public interface HqInvestStoreMapper {
    List<HqInvestStore> selectHqInvestStoreList(
        @Param("size") Integer size,
        @Param("offset") Integer offset,
        @Param("param") HqInvestStoreListParam param
    );
    void insertHqInvestStore(@Param("data") HqInvestStore hqInvestStore);
    void updateHqInvestStore(@Param("data") HqInvestStore hqInvestStore);
    void deleteHqInvestStoreAndChildrenAll(Integer investStoreNo);
    Integer selectHqInvestStoreNameChkCnt(String investStoreName);
    Integer selectHqInvestStoreNameCnt(String investStoreName);
}
