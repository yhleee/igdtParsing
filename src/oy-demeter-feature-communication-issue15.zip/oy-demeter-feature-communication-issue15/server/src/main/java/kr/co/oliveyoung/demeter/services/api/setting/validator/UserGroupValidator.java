package kr.co.oliveyoung.demeter.services.api.setting.validator;

import kr.co.oliveyoung.demeter.services.api.setting.model.UserGroupParam;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.Objects;

@Configuration
public class UserGroupValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return UserGroupParam.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserGroupParam userGroupParam = (UserGroupParam) target;

        if (Objects.isNull(userGroupParam.getGroupName())) {
            errors.reject("userGroup.groupName.empty");
            return;
        }
    }
}
