package kr.co.oliveyoung.demeter.common;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class SearchCriteria {

  protected String keyword;
}

