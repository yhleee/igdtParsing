package kr.co.oliveyoung.feature.log;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import org.apache.ibatis.annotations.Param;

@MySqlOyisMapper
public interface ExampleLogMapper {

    void insertExampleLog(@Param("data") ExampleLog data);

}
