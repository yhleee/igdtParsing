package kr.co.oliveyoung.feature.settle.mapper;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.demeter.services.api.settle.param.PtInvestStoreListParam;
import kr.co.oliveyoung.feature.settle.PtInvestStore;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@MySqlOyisMapper
public interface PtInvestStoreMapper {
    List<PtInvestStore> selectPtInvestStoreList(int size, int offset, PtInvestStoreListParam param);
    void deleteInvestStoreAllData(Integer investStoreCategoryNo);
    void insertInvestStore(@Param("data") PtInvestStore ptInvestStore);
    void updateInvestStoreActiveType(String investStoreActiveType);
    Integer selectInvestStoreActiveTypeCnt(String teamProjectActiveType);
    Integer selectPtInvestStoreCnt(String investStoreName, Integer investStoreType, Integer investStoreAssetNo);
}
