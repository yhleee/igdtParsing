package kr.co.oliveyoung.demeter.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import kr.co.oliveyoung.common.utils.DateUtils;
import kr.co.oliveyoung.common.utils.ObjectUtils;
import kr.co.oliveyoung.demeter.common.constants.CommonConstant;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.exception.auth.AuthException;
import kr.co.oliveyoung.demeter.utils.JWTUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.CookieGenerator;

@Component
@AllArgsConstructor
@Slf4j
public class AccessTokenInterceptor extends HandlerInterceptorAdapter {
    private static final int LOGIN_TTL = 300000; //로그인 유지시간 30분

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ParseException {
        String accessToken = null;

        accessToken = request.getHeader(CommonConstant.HTTP_HEADER_TOKEN_KEY);
        log.info("accessToken: " + accessToken);

        if (accessToken == null) {
            Cookie[] cookies = request.getCookies();
            for (Cookie cookie: cookies) {
                if (cookie.getName().equals(CommonConstant.HTTP_HEADER_TOKEN_KEY)) {
                    accessToken = cookie.getValue();
                }
            }
        }

        String ip = request.getHeader("X-FORWARDED-FOR");
        if(ObjectUtils.isEmpty(ip)) {
            ip = request.getRemoteAddr();
        }
        log.info("ACCESS INFO : IP=[" + ip + "]  REFER=[" + request.getHeader("referer")+ "]  USER-AGENT=[" + request.getHeader("User-Agent") + "]");

        if (StringUtils.isBlank(accessToken) || StringUtils.equalsIgnoreCase("null", accessToken)
            || StringUtils.equalsIgnoreCase("undefined", accessToken)) {
            throw new AuthException("Empty Access Token", 401);
        }

        AccessTokenVO accessTokenVO = JWTUtil.parseToken(accessToken, AccessTokenVO.class);

        // user 유효성 검사 추가 , 유효시간, 기타 필수값 여부..
        if (StringUtils.isBlank(accessTokenVO.getLoginId())) {
            throw new AuthException("사용자 정보가 없습니다. 다시 로그인 해주세요.", 401);
        }

        // 토큰 생성 시간
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date tokenDateTime = simpleDateFormat.parse(accessTokenVO.getLastLoginDatetime());

        // 토큰 만료 시간
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(tokenDateTime);
        calendar.add(Calendar.MINUTE, LOGIN_TTL);
        Date endTokenDateTime = simpleDateFormat.parse(simpleDateFormat.format(calendar.getTime()));

        // 현재 시간
        Date currentDateTime = simpleDateFormat.parse(DateUtils.convertFormat(accessTokenVO.getLastLoginDatetime(), "yyyyMMddHHmmss"));
        if (endTokenDateTime.getTime() < currentDateTime.getTime()) {
            throw new AuthException("로그인 유지시간이 만료되었습니다. 다시 로그인 해주세요.", 401);
        }

        // 새 토큰 발급
        CookieGenerator cookieGenerator = new CookieGenerator();
        cookieGenerator.setCookieName("ACCESS_TOKEN");
        accessTokenVO.setLastLoginDatetime(DateUtils.date("yyyyMMddHHmmss"));
        String newAccessToken = JWTUtil.createJWT(accessTokenVO);
        cookieGenerator.addCookie(response, newAccessToken);
        request.setAttribute("accessTokenVO", accessTokenVO);

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) {}

}
