package kr.co.oliveyoung.demeter.services.api.setting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserMenuParam {
    private Integer menuNo;
    private Integer[] menuNos;
    private String menuName;
    private String iconName;
    private Integer upperMenuNo;
    private Integer level;
    private Integer sortSeq;
    private String url;
    private String useYn;
    private String registerId;
    private String modifierId;

    public void setUseYn(String useYn) {
        this.useYn = BooleanUtils.toBoolean(useYn) ? "Y" : "N";
    }
}
