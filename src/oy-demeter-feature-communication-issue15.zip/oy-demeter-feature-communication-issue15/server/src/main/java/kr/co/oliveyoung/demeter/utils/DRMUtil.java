package kr.co.oliveyoung.demeter.utils;

import com.fasoo.adk.packager.WorkPackager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author CJ Oliveyoung
 * @version v1.0
 * @history
 *     |- Version History
 *        - v1.0: DRM Util Class 및 복호화 메서드 생성
 * @description
 *     |- 사용 전 필수 ( linux 64bit 기준 )
 *        1. CJ올리브네트웍스 채범석님에게 DRM 연동 신청 ( 서버 레벨로 할당됨 )
 *        2. compile 'com.fasoo:drm-jni:2.7.7' dependencies 에 등록
 *        3. 프로젝트 경로에 있는 /fasoo_drm/setup_linux_64/libfasoopackager.so 파일을 java lib 폴더에 저장
 *        4. 성공하면 /fasoo_drm/contents/ 내부에 복호화된 파일이 생성된다.
 */
@Slf4j
public class DRMUtil {

    private static final String ROOT_FOLDER_NAME = "./fasoo_drm";
    private static final String FSD_INIT = "./fasoo_drm/fsdinit";
    private static final String DS_DCODE = "0000000000002519";
    private static final String DRM_FILE_PATH = "./fasoo_drm/contents/";
    private static final String[] DRM_REQUIRE_FOLDER_ARRAY = {"fsdinit", "contents"};

    private DRMUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static boolean drmFileCheck(MultipartFile uploadFile) {
        try {
            int fileTypeRetCode = 0;
            boolean nret = false;
            String orgfile = DRM_FILE_PATH + uploadFile.getOriginalFilename();

            // CASE 1: 복호화를 위한 업로드 파일 서버임시저장
            byte[] data = uploadFile.getBytes();
            FileOutputStream fos = new FileOutputStream(orgfile);
            fos.write(data);
            fos.close();

            // CASE 2: 암호화 대상 문서가 지원 가능 확장자인지 확인
            WorkPackager wPackager = new WorkPackager();
            nret = wPackager.IsSupportFile(
                    FSD_INIT,    // fsdinit 폴더 FullPath 설정
                    DS_DCODE,    // 고객사 Key(default)
                    orgfile // 복호화 대상 문서 FullPath + FileName
            );
            if (!nret) {
                log.error("복호화 지원가능 확장자 결과값: {}", nret);
                return false;
            }

            fileTypeRetCode = wPackager.GetFileType(orgfile);
            if (fileTypeRetCode == 29) {
                return false;
            }
        } catch (Exception e) {
            log.info("drmFileCheck: {}", e.getMessage());
        }

        return true;
    }

    public static void drmFileDecode(MultipartFile uploadFile, String decodeFileName) {
        try {
            log.info("-------------------------------------- DRM File Decode Start --------------------------------------");

            boolean bret = false;
            int fileTypeRetCode = 0;
            String orgfile = DRM_FILE_PATH + uploadFile.getOriginalFilename();
            String targetfile = DRM_FILE_PATH + decodeFileName;

            String rootDRMDir = ROOT_FOLDER_NAME; // fasoo_drm array로 값 받아 loop로 유무 체크
            File file = new File(rootDRMDir);

            // CASE 1: 필수 폴더 체크
            for (String folderName: DRM_REQUIRE_FOLDER_ARRAY) {
                if (!file.exists()) {
                    throw new RuntimeException("Folder does not exist: " + folderName);
                }
            }

            WorkPackager wPackager = new WorkPackager();
            //wPackager.setCharset("eucKR");    // 암/복호화 연동 시 한글이 깨지면 사용

            // CASE 2: 복호화 된문서가 암호화된 문서를 덮어쓰지 않음
            wPackager.setOverWriteFlag(false);

            // CASE 3: 대상 문서가 그룹 보안문서일때 복호화 실행
            fileTypeRetCode = wPackager.GetFileType(orgfile);
            if (fileTypeRetCode == 103) {
                bret = wPackager.DoExtract(
                    FSD_INIT,    // fsdinit 폴더 FullPath 설정
                    DS_DCODE,     // 고객사 Key(default) , 계열사에 맞는 DSD코드 입력
                    orgfile,    // 복호화 대상 문서 FullPath + FileName
                    targetfile  // 복호화 된 문서 FullPath + FileName
                );

                // 성공 값(true, 0, "")
                log.info("복호화 결과값: {}", bret);
                log.info("오류코드: {}", wPackager.getLastErrorNum());
                log.info("오류값: {}", wPackager.getLastErrorStr());
                log.info("Encode File Name: {}", uploadFile.getOriginalFilename());
                log.info("Decode File Name: {}", decodeFileName);
            } else {
                throw new RuntimeException("This is not a CJ Group security document. (" + fileTypeRetCode + ")");
            }

            log.info("-------------------------------------- DRM File Decode End --------------------------------------");
        } catch (Exception e) {
            log.error("{}", e.getMessage());
            throw new RuntimeException("getDRMFileDecode ERROR");
        }
    }

    private static String getFileTypeStr(int i) {
        String ret = null;
        switch(i) {
            case 20:
                ret = "파일을 찾을 수 없습니다.";
                break;
            case 21:
                ret = "파일 사이즈가 0 입니다.";
                break;
            case 22:
                ret = "파일을 읽을 수 없습니다.";
                break;
            case 29:
                ret = "암호화 파일이 아닙니다.";
                break;
            case 26:
                ret = "FSD 파일입니다.";
                break;
            case 105:
                ret = "Wrapsody 파일입니다.";
                break;
            case 106:
                ret = "NX 파일입니다.";
                break;
            case 101:
                ret = "MarkAny 파일입니다.";
                break;
            case 104:
                ret = "INCAPS 파일입니다.";
                break;
            case 103:
                ret = "FSN 파일입니다.";
                break;
        }
        return ret;
    }

}
