package kr.co.oliveyoung.demeter.services.api.communication.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.AttachmentVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.MemberGroupAuthorityVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.PostVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.TagTypeCode;
import kr.co.oliveyoung.feature.communication.education.model.Attachment;
import kr.co.oliveyoung.feature.communication.education.model.AttachmentGroup;
import kr.co.oliveyoung.feature.communication.education.model.EduPost;
import kr.co.oliveyoung.feature.communication.education.model.EduTag;
import kr.co.oliveyoung.feature.communication.education.model.MemberGroupAuthority;

public class ModelConverter {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static EduPost convertToEduPostFrom(PostVO post) {
        return EduPost.builder()
            .boardNo(post.getBoardNo())
            .postNo(post.getPostNo())
            .title(post.getTitle())
            .contents(post.getContents())
            .attachGroupNo(post.getAttachGroupNo())
            .useYn(post.getUseYn())
            .noticeYn(post.getNoticeYn())
            .creator(post.getCreator())
            .updater(post.getUpdater())
            .build();
    }

    public static Attachment convertToAttachmentFrom(AttachmentVO attachment) {
        return Attachment.builder()
            .fileType(attachment.getFileTypeCode().getCode())
            .filePath(attachment.getFilePath())
            .fileUrl(attachment.getFileUrl())
            .order(attachment.getOrder())
            .attachmentGroupNo(attachment.getAttachGroupNo())
            .fileSize(attachment.getFileSize())
            .mediaKey(attachment.getMediaKey())
            .attachmentNo(attachment.getAttachNo())
            .creator(attachment.getCreator())
            .updater(attachment.getUpdater())
            .build();
    }

    public static AttachmentGroup convertToAttachmentGroupFrom(AttachmentVO attachment) {
        return AttachmentGroup.builder()
            .attachGroupNo(attachment.getAttachGroupNo())
            .creator(attachment.getCreator())
            .updater(attachment.getUpdater())
            .build();
    }

    public static EduTag convertToEduTagFrom(TagVO tag) {
        return EduTag.builder()
            .tagNo(tag.getTagNo())
            .tagName(tag.getTagName())
            .tagGroupNo(tag.getTagGroupNo())
            .tagTypeCode(tag.getTagTypeCode().getCode())
            .tagOrder(tag.getTagOrder())
            .creator(tag.getCreator())
            .updater(tag.getUpdater())
            .build();
    }

    public static TagVO convertToTagVOFrom(EduTag tag) {
        return TagVO.builder()
            .tagTypeCode(TagTypeCode.codeOf(tag.getTagTypeCode()))
            .tagGroupNo(tag.getTagGroupNo())
            .tagName(tag.getTagName())
            .tagNo(tag.getTagNo())
            .creator(tag.getCreator())
            .updater(tag.getUpdater())
            .tagOrder(tag.getTagOrder())
            .build();
    }

    public static MemberGroupAuthority convertToMemberGroupAuthorityFrom(MemberGroupAuthorityVO authorityVO) {
        return MemberGroupAuthority.builder()
            .memberGroupAuthorityNo(authorityVO.getMemberGroupAuthorityNo())
            .areaTypeCode(authorityVO.getAreaTypeCode().getCode())
            .authorityTypeCode(authorityVO.getAuthorityTypeCode().getCode())
            .targetTypeCode(authorityVO.getTargetTypeCode().getCode())
            .memberGroupNo(authorityVO.getMemberGroupNo())
            .targetNo(authorityVO.getTargetNo())
            .creator(authorityVO.getCreator())
            .updater(authorityVO.getUpdater())
            .build();
    }

    public static <T> T deepCopy(T object, Class<T> clazz) throws IOException {
        return objectMapper.readValue(objectMapper.writeValueAsString(object), clazz);
    }
}
