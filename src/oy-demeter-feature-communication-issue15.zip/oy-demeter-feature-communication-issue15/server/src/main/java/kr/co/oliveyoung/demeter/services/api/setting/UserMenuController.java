package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuParam;
import kr.co.oliveyoung.demeter.services.api.setting.service.UserMenuService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("api/setting/menu")
public class UserMenuController {

    @Autowired
    private UserMenuService userMenuService;

    @ApiOperation("전체 메뉴 조회")
    @GetMapping
    public ApiResponseMessage listMenu(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        apiResponseMessage.setContents(userMenuService.fetchUserMenu());
        return apiResponseMessage;
    }

    @ApiOperation("메뉴 조회")
    @GetMapping("/{menuNos}")
    public ApiResponseMessage listMenu(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        @PathVariable("menuNos") Integer... menuNos) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        apiResponseMessage.setContents(userMenuService.fetchUserMenu(menuNos));
        return apiResponseMessage;
    }

    @ApiOperation("메뉴 등록")
    @PostMapping
    public ApiResponseMessage addMenu(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        @RequestBody UserMenuParam menuParam, BindingResult errors) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }

        menuParam.setRegisterId(tokenVO.getLoginId());
        userMenuService.addUserMenu(menuParam);

        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        return apiResponseMessage;
    }

    @ApiOperation("메뉴 수정")
    @PutMapping
    public ApiResponseMessage modifyMenu(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        @RequestBody UserMenuParam menuParam, BindingResult errors) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        menuParam.setModifierId(tokenVO.getLoginId());
        userMenuService.modifyUserMenu(menuParam);

        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        return apiResponseMessage;
    }

    @ApiOperation("메뉴 삭제")
    @DeleteMapping
    public ApiResponseMessage removeMenu(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        @RequestBody UserMenuParam menuParam) {
        if (!BooleanUtils.toBooleanObject(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        userMenuService.removeUserMenu(menuParam.getMenuNos());

        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        return apiResponseMessage;
    }

    @ApiOperation("유저 권한별 메뉴 조회")
    @GetMapping("userAuthorityList")
    public ApiResponseMessage getUserAuthorityList(
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage apiResponseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        apiResponseMessage.setContents(userMenuService.getUserAuthorityMenuList(tokenVO.getUserNo()));
        return apiResponseMessage;
    }

}
