package kr.co.oliveyoung.demeter.services.api.settle.service;

import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.services.api.settle.param.HqInvestStoreDTO;
import kr.co.oliveyoung.demeter.services.api.settle.param.HqInvestStoreListParam;
import kr.co.oliveyoung.demeter.services.api.settle.param.PtInvestStoreListParam;
import kr.co.oliveyoung.feature.settle.HqInvestStore;
import kr.co.oliveyoung.feature.settle.HqInvestStoreAsset;
import kr.co.oliveyoung.feature.settle.PtInvestStore;
import kr.co.oliveyoung.feature.settle.mapper.HqInvestStoreAssetMapper;
import kr.co.oliveyoung.feature.settle.mapper.HqInvestStoreMapper;
import kr.co.oliveyoung.feature.settle.mapper.PtInvestStoreMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class HqInvestStoreService {

    @Value("${oy-ez.api.host}")
    private String oyEzApiHost;

    private final HqInvestStoreMapper hqInvestStoreMapper;
    private final HqInvestStoreAssetMapper hqInvestStoreAssetMapper;
    private final PtInvestStoreMapper ptInvestStoreMapper;

    public HqInvestStoreService(
        HqInvestStoreMapper hqInvestStoreMapper,
        HqInvestStoreAssetMapper hqInvestStoreAssetMapper,
        PtInvestStoreMapper ptInvestStoreMapper
    ) {
        this.hqInvestStoreMapper = hqInvestStoreMapper;
        this.hqInvestStoreAssetMapper = hqInvestStoreAssetMapper;
        this.ptInvestStoreMapper = ptInvestStoreMapper;
    }

    @Transactional(readOnly = true)
    public List<HqInvestStore> getHqInvestStoreNewList(int page, int size, HqInvestStoreListParam param) {
        Integer offset = (page - 1) * size;
        return hqInvestStoreMapper.selectHqInvestStoreList(size, offset, param);
    }

    @Transactional(readOnly = true)
    public List<HqInvestStore> getHqInvestStoreList(int page, int size, HqInvestStoreListParam param) {
        Integer offset = (page - 1) * size;
        List<HqInvestStore> hqInvestStoreList = hqInvestStoreMapper.selectHqInvestStoreList(size, offset, param);

        for (HqInvestStore hqInvestStore: hqInvestStoreList) {
            /*
            System.out.println("[PT] RACK: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 1));
            System.out.println("[PT] VPN: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 2));
            System.out.println("[PT] LED: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 3));
            System.out.println("[PT] 셋탑: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 4));
            System.out.println("[PT] POS: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 5));
            System.out.println("[PT] 서지보호기: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 6));
            System.out.println("[PT] HUB: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 7));
            System.out.println("[PT] 핸드스캐너: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 8));
            System.out.println("[PT] PDA: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 9));
            System.out.println("[PT] 사인패드: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 10));
            System.out.println("[PT] CAT: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 11));
            System.out.println("[PT] 스위치: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 12));
            System.out.println("[PT] IC단말기: " + ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 13));

            // 업체는 신규에 대한 데이터만 가져와서 비교
            HqInvestStoreAsset hqInvestStoreAsset = hqInvestStoreAssetMapper.selectHqInvestStoreAsset(hqInvestStore.getInvestStoreNo(), 1);
            if (hqInvestStoreAsset != null) {
                System.out.println("[HQ] RACK: " + hqInvestStoreAsset.getInvestStoreAssetRack());
                System.out.println("[HQ] VPN: " + hqInvestStoreAsset.getInvestStoreAssetVpn());
                System.out.println("[HQ] LED: " + hqInvestStoreAsset.getInvestStoreAssetLed());
                System.out.println("[HQ] 셋탑: " + hqInvestStoreAsset.getInvestStoreAssetSettopPc());
                System.out.println("[HQ] POS: " + hqInvestStoreAsset.getInvestStoreAssetPos());
                System.out.println("[HQ] 서지보호기: " + hqInvestStoreAsset.getInvestStoreAssetSurgeProtector());
                System.out.println("[HQ] HUB: " + hqInvestStoreAsset.getInvestStoreAssetHub());
                System.out.println("[HQ] 핸드스캐너: " + hqInvestStoreAsset.getInvestStoreAssetHandScanner());
                System.out.println("[HQ] PDA: " + hqInvestStoreAsset.getInvestStoreAssetPda());
                System.out.println("[HQ] 사인패드: " + hqInvestStoreAsset.getInvestStoreAssetSignPad());
                System.out.println("[HQ] CAT: " + hqInvestStoreAsset.getInvestStoreAssetCat());
                System.out.println("[HQ] 스위치: " + hqInvestStoreAsset.getInvestStoreAssetSwitch());
                System.out.println("[HQ] IC단말기: " + hqInvestStoreAsset.getInvestStoreAssetIcTerminal());
            }
             */

            /* TODO: 1depth 리스트 백업
            HqInvestStoreAsset hqInvestStoreAsset = hqInvestStoreAssetMapper.selectHqInvestStoreAsset(hqInvestStore.getInvestStoreNo(), 1);
            hqInvestStore.setInvestStoreAssetRackYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 1),
                    hqInvestStoreAsset.getInvestStoreAssetRack()
                )
            );
            hqInvestStore.setInvestStoreAssetVpnYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 2),
                    hqInvestStoreAsset.getInvestStoreAssetVpn()
                )
            );
            hqInvestStore.setInvestStoreAssetLedYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 3),
                    hqInvestStoreAsset.getInvestStoreAssetLed()
                )
            );
            hqInvestStore.setInvestStoreAssetSettopPcYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 4),
                    hqInvestStoreAsset.getInvestStoreAssetSettopPc()
                )
            );
            hqInvestStore.setInvestStoreAssetPosYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 5),
                    hqInvestStoreAsset.getInvestStoreAssetPos()
                )
            );
            hqInvestStore.setInvestStoreAssetSurgeProtectorYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 6),
                    hqInvestStoreAsset.getInvestStoreAssetSurgeProtector()
                )
            );
            hqInvestStore.setInvestStoreAssetHubYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 7),
                    hqInvestStoreAsset.getInvestStoreAssetHub()
                )
            );
            hqInvestStore.setInvestStoreAssetHandScannerYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 8),
                    hqInvestStoreAsset.getInvestStoreAssetHandScanner()
                )
            );
            hqInvestStore.setInvestStoreAssetPdaYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 9),
                    hqInvestStoreAsset.getInvestStoreAssetPda()
                )
            );
            hqInvestStore.setInvestStoreAssetSignPadYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 10),
                    hqInvestStoreAsset.getInvestStoreAssetSignPad()
                )
            );
            hqInvestStore.setInvestStoreAssetCatYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 11),
                    hqInvestStoreAsset.getInvestStoreAssetCat()
                )
            );
            hqInvestStore.setInvestStoreAssetSwitchYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 12),
                    hqInvestStoreAsset.getInvestStoreAssetSwitch()
                )
            );
            hqInvestStore.setInvestStoreAssetIcTerminalYn(
                getInvestStoreAssetYn(
                    ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 13),
                    hqInvestStoreAsset.getInvestStoreAssetIcTerminal()
                )
            );
             */

            // TODO: 시간 될 때 쿼리로 수정
            List<HqInvestStoreAsset> hqInvestStoreAssetList = hqInvestStoreAssetMapper.selectHqInvestStoreAssetList(hqInvestStore.getInvestStoreNo());
            if (!hqInvestStoreAssetList.isEmpty()) {
                for (HqInvestStoreAsset hqInvestStoreAsset: hqInvestStoreAssetList) {
                    if (hqInvestStoreAsset.getInvestStoreAssetType() == 1) {
                        hqInvestStoreAsset.setInvestStoreAssetRackYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 1),
                                hqInvestStoreAsset.getInvestStoreAssetRack()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetVpnYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 2),
                                hqInvestStoreAsset.getInvestStoreAssetVpn()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetLedYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 3),
                                hqInvestStoreAsset.getInvestStoreAssetLed()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetSettopPcYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 4),
                                hqInvestStoreAsset.getInvestStoreAssetSettopPc()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetPosYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 5),
                                hqInvestStoreAsset.getInvestStoreAssetPos()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetSurgeProtectorYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 6),
                                hqInvestStoreAsset.getInvestStoreAssetSurgeProtector()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetHubYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 7),
                                hqInvestStoreAsset.getInvestStoreAssetHub()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetHandScannerYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 8),
                                hqInvestStoreAsset.getInvestStoreAssetHandScanner()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetPdaYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 9),
                                hqInvestStoreAsset.getInvestStoreAssetPda()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetSignPadYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 10),
                                hqInvestStoreAsset.getInvestStoreAssetSignPad()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetCatYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 11),
                                hqInvestStoreAsset.getInvestStoreAssetCat()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetSwitchYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 12),
                                hqInvestStoreAsset.getInvestStoreAssetSwitch()
                            )
                        );
                        hqInvestStoreAsset.setInvestStoreAssetIcTerminalYn(
                            getInvestStoreAssetYn(
                                ptInvestStoreMapper.selectPtInvestStoreCnt(hqInvestStore.getInvestStoreName(), hqInvestStore.getInvestStoreType(), 13),
                                hqInvestStoreAsset.getInvestStoreAssetIcTerminal()
                            )
                        );
                    }
                }
            }

            hqInvestStore.setInvestStoreAssetList(hqInvestStoreAssetList);
        }

        return hqInvestStoreList;
    }

    @Transactional(readOnly = true)
    public List<HqInvestStoreAsset> getHqInvestStoreAssetList(String investStoreName, Integer investStoreType, Integer investStoreNo) {
        List<HqInvestStoreAsset> hqInvestStoreAssetList = hqInvestStoreAssetMapper.selectHqInvestStoreAssetList(investStoreNo);
        if (!hqInvestStoreAssetList.isEmpty()) {
            for (HqInvestStoreAsset hqInvestStoreAsset: hqInvestStoreAssetList) {
                if (hqInvestStoreAsset.getInvestStoreAssetType() == 1) {
                    hqInvestStoreAsset.setInvestStoreAssetRackYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 1),
                                    hqInvestStoreAsset.getInvestStoreAssetRack()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetVpnYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 2),
                                    hqInvestStoreAsset.getInvestStoreAssetVpn()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetLedYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 3),
                                    hqInvestStoreAsset.getInvestStoreAssetLed()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetSettopPcYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 4),
                                    hqInvestStoreAsset.getInvestStoreAssetSettopPc()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetPosYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 5),
                                    hqInvestStoreAsset.getInvestStoreAssetPos()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetSurgeProtectorYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 6),
                                    hqInvestStoreAsset.getInvestStoreAssetSurgeProtector()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetHubYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 7),
                                    hqInvestStoreAsset.getInvestStoreAssetHub()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetHandScannerYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 8),
                                    hqInvestStoreAsset.getInvestStoreAssetHandScanner()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetPdaYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 9),
                                    hqInvestStoreAsset.getInvestStoreAssetPda()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetSignPadYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 10),
                                    hqInvestStoreAsset.getInvestStoreAssetSignPad()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetCatYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 11),
                                    hqInvestStoreAsset.getInvestStoreAssetCat()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetSwitchYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 12),
                                    hqInvestStoreAsset.getInvestStoreAssetSwitch()
                            )
                    );
                    hqInvestStoreAsset.setInvestStoreAssetIcTerminalYn(
                            getInvestStoreAssetYn(
                                    ptInvestStoreMapper.selectPtInvestStoreCnt(investStoreName, investStoreType, 13),
                                    hqInvestStoreAsset.getInvestStoreAssetIcTerminal()
                            )
                    );
                }
            }
        }

        return hqInvestStoreAssetList;
    }

    private String getInvestStoreAssetYn(Integer hqInvestStoreAssetCnt, Integer ptInvestStoreAssetCnt) {
        String retYn = "N";
        if (hqInvestStoreAssetCnt == ptInvestStoreAssetCnt) {
            retYn = "Y";
        }

        return retYn;
    }

    @Transactional
    public void setHqInvestStore(HqInvestStoreDTO hqInvestStoreDTO, AccessTokenVO tokenVO) {
        try {
            // Insert Invest Store
            HqInvestStore hqInvestStore = new HqInvestStore();

            // 코스트 센터 코드 매칭
            // 정보전략팀만 예외처리
            String cstCntrCd = null;
            JSONArray getCostCenterArr = getCostCenterArr(hqInvestStoreDTO.getInvestStoreName());
            if (hqInvestStoreDTO.getInvestStoreName().equals("정보전략팀")) {
                cstCntrCd = "2000049";
            } else {
                for(int k=0; k<getCostCenterArr.length(); k++) {
                    JSONObject costCenterObject = getCostCenterArr.getJSONObject(k);

                    if (hqInvestStoreDTO.getInvestStoreName().equals(costCenterObject.getString("costcenterName"))) {
                        cstCntrCd = costCenterObject.getString("costcenterCode");
                    }
                }
            }

            hqInvestStore.setToCstCntrCd(cstCntrCd);

            hqInvestStore.setInvestStoreName(hqInvestStoreDTO.getInvestStoreName());

            DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime parseInvestStoreOpenDate = LocalDateTime.parse(hqInvestStoreDTO.getInvestStoreOpenDate(), dateformatter);
            hqInvestStore.setInvestStoreOpenDate(parseInvestStoreOpenDate);

            hqInvestStore.setInvestStoreType(hqInvestStoreDTO.getInvestStoreType());
            hqInvestStore.setInvestStoreRemarks(hqInvestStoreDTO.getInvestStoreRemarks());
            hqInvestStore.setSysRegDtime(LocalDateTime.now());
            hqInvestStore.setSysRegrId(tokenVO.getLoginId());
            hqInvestStoreMapper.insertHqInvestStore(hqInvestStore);

            // Insert Invest Store Asset (1: new, 2: re)
            for (int i=1; i<3; i++) {
                HqInvestStoreAsset hqInvestStoreAsset = HqInvestStoreAsset.builder()
                        .investStoreNo(hqInvestStore.getInvestStoreNo())
                        .investStoreAssetType(i)
                        .investStoreAssetRack( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetRack() : hqInvestStoreDTO.getReInvestStoreAssetRack() )
                        .investStoreAssetVpn( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetVpn() : hqInvestStoreDTO.getReInvestStoreAssetVpn() )
                        .investStoreAssetLed( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetLed() : hqInvestStoreDTO.getReInvestStoreAssetLed() )
                        .investStoreAssetSettopPc( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSettopPc() : hqInvestStoreDTO.getReInvestStoreAssetSettopPc() )
                        .investStoreAssetPos( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetPos() : hqInvestStoreDTO.getReInvestStoreAssetPos() )
                        .investStoreAssetSurgeProtector( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSurgeProtector() : hqInvestStoreDTO.getReInvestStoreAssetSurgeProtector() )
                        .investStoreAssetHub( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetHub() : hqInvestStoreDTO.getReInvestStoreAssetHub() )
                        .investStoreAssetHandScanner( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetHandScanner() : hqInvestStoreDTO.getReInvestStoreAssetHandScanner() )
                        .investStoreAssetPda( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetPda() : hqInvestStoreDTO.getReInvestStoreAssetPda() )
                        .investStoreAssetSignPad( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSignPad() : hqInvestStoreDTO.getReInvestStoreAssetSignPad() )
                        .investStoreAssetCat( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetCat() : hqInvestStoreDTO.getReInvestStoreAssetCat() )
                        .investStoreAssetSwitch( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSwitch() : hqInvestStoreDTO.getReInvestStoreAssetSwitch() )
                        .investStoreAssetIcTerminal( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetIcTerminal() : hqInvestStoreDTO.getReInvestStoreAssetIcTerminal() )
                        .sysRegDtime(LocalDateTime.now())
                        .sysRegrId(tokenVO.getLoginId())
                        .build();
                hqInvestStoreAssetMapper.insertHqInvestStoreAsset(hqInvestStoreAsset);
            }
        } catch (Exception e) {
            log.info("insertInvestStore ERROR !!", e);
        }
    }

    @Transactional
    public void putHqInvestStore(Integer investStoreNo, HqInvestStoreDTO hqInvestStoreDTO, AccessTokenVO tokenVO) {
        try {
            // Update Invest Store
            HqInvestStore hqInvestStore = new HqInvestStore();
            hqInvestStore.setInvestStoreNo(investStoreNo);

            // 코스트 센터 코드 매칭
            JSONArray getCostCenterArr = getCostCenterArr(hqInvestStoreDTO.getInvestStoreName());
            String cstCntrCd = null;
            for(int k=0; k<getCostCenterArr.length(); k++) {
                JSONObject costCenterObject = getCostCenterArr.getJSONObject(k);

                if (hqInvestStoreDTO.getInvestStoreName().equals(costCenterObject.getString("costcenterName"))) {
                    cstCntrCd = costCenterObject.getString("costcenterCode");
                }
            }
            hqInvestStore.setToCstCntrCd(cstCntrCd);

            hqInvestStore.setInvestStoreName(hqInvestStoreDTO.getInvestStoreName());

            DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime parseInvestStoreOpenDate = LocalDateTime.parse(hqInvestStoreDTO.getInvestStoreOpenDate(), dateformatter);
            hqInvestStore.setInvestStoreOpenDate(parseInvestStoreOpenDate);

            hqInvestStore.setInvestStoreType(hqInvestStoreDTO.getInvestStoreType());
            hqInvestStore.setInvestStoreRemarks(hqInvestStoreDTO.getInvestStoreRemarks());
            hqInvestStoreMapper.updateHqInvestStore(hqInvestStore);

            // Update Invest Store Asset (1: new, 2: re)
            for (int i=1; i<3; i++) {
                HqInvestStoreAsset hqInvestStoreAsset = HqInvestStoreAsset.builder()
                        .investStoreNo(investStoreNo)
                        .investStoreAssetType(i)
                        .investStoreAssetRack( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetRack() : hqInvestStoreDTO.getReInvestStoreAssetRack() )
                        .investStoreAssetVpn( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetVpn() : hqInvestStoreDTO.getReInvestStoreAssetVpn() )
                        .investStoreAssetLed( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetLed() : hqInvestStoreDTO.getReInvestStoreAssetLed() )
                        .investStoreAssetSettopPc( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSettopPc() : hqInvestStoreDTO.getReInvestStoreAssetSettopPc() )
                        .investStoreAssetPos( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetPos() : hqInvestStoreDTO.getReInvestStoreAssetPos() )
                        .investStoreAssetSurgeProtector( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSurgeProtector() : hqInvestStoreDTO.getReInvestStoreAssetSurgeProtector() )
                        .investStoreAssetHub( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetHub() : hqInvestStoreDTO.getReInvestStoreAssetHub() )
                        .investStoreAssetHandScanner( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetHandScanner() : hqInvestStoreDTO.getReInvestStoreAssetHandScanner() )
                        .investStoreAssetPda( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetPda() : hqInvestStoreDTO.getReInvestStoreAssetPda() )
                        .investStoreAssetSignPad( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSignPad() : hqInvestStoreDTO.getReInvestStoreAssetSignPad() )
                        .investStoreAssetCat( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetCat() : hqInvestStoreDTO.getReInvestStoreAssetCat() )
                        .investStoreAssetSwitch( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetSwitch() : hqInvestStoreDTO.getReInvestStoreAssetSwitch() )
                        .investStoreAssetIcTerminal( (i == 1) ? hqInvestStoreDTO.getNewInvestStoreAssetIcTerminal() : hqInvestStoreDTO.getReInvestStoreAssetIcTerminal() )
                        .sysRegDtime(LocalDateTime.now())
                        .sysRegrId(tokenVO.getLoginId())
                        .build();
                hqInvestStoreAssetMapper.updateHqInvestStoreAsset(hqInvestStoreAsset);
            }
        } catch (Exception e) {
            log.info("updateHqInvestStore ERROR !!", e);
        }
    }

    @Transactional
    public void delHqInvestStore(Integer investStoreNo) {
        hqInvestStoreMapper.deleteHqInvestStoreAndChildrenAll(investStoreNo);
    }

    private JSONArray getCostCenterArr(String costCenterName) throws IOException {
        String url = oyEzApiHost;
        HttpClient httpClient = new HttpClient();
        GetMethod method = new GetMethod(url);
        method.setQueryString(new NameValuePair[] {
            new NameValuePair("storeName", costCenterName)
        });

        httpClient.executeMethod(method);
        byte[] responseBody = method.getResponseBody();

        JSONObject storeListStr = null;
        JSONObject storeListJson = null;
        storeListStr = new JSONObject(new String(responseBody));

        storeListJson = new JSONObject(storeListStr.get("contents").toString());
        JSONArray costCenterJsonArray = (JSONArray) storeListJson.get("costcenterList");

        return costCenterJsonArray;
    }

}
