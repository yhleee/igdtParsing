package kr.co.oliveyoung.demeter.config;

import com.google.gson.Gson;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserParam;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Component
@AllArgsConstructor
@Slf4j
public class UserParamInterceptor extends HandlerInterceptorAdapter {
    private static final String SECRET_KEY = "13a083c816f069a3333a4ac1037598bb";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        try {
            BufferedReader reader = request.getReader();
            UserParam userParam = new Gson().fromJson(reader, UserParam.class);
            userParam.setLoginId(new String(Base64Utils.decode(userParam.getLoginCode1().getBytes())));
            userParam.setPassword(hashPassword(new String(Base64Utils.decode(userParam.getLoginCode2().getBytes()))));
            request.setAttribute("userParam", userParam);
        } catch (Exception e) {
            log.error("Hashing password error: {}", e);
            return false;
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) {}

    private String hashPassword(String password)
        throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest mdSHA256 = MessageDigest.getInstance("SHA-256");
        mdSHA256.update(password.getBytes("UTF-8"));
        byte[] sha256Hash = mdSHA256.digest();
        StringBuilder hexSHA256hash = new StringBuilder();
        for(byte b : sha256Hash) {
            String hexString = String.format("%02x", b);
            hexSHA256hash.append(hexString);
        }

        return hexSHA256hash.toString();
    }

}
