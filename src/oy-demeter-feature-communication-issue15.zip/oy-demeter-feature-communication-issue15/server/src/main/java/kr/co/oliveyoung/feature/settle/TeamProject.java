package kr.co.oliveyoung.feature.settle;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
public class TeamProject {

    private Integer teamProjectNo;
    private Integer teamProjectSettleType;
    private Integer teamProjectType;
    private String teamProjectDepartment;
    private String teamProjectDealCheck;
    private String teamProjectDocumentNumber;
    private String teamProjectDocumentTitle;
    private Integer teamProjectPrice;
    private String teamProjectCostCenter;
    private String teamProjectWBSCode;
    private String teamProjectActiveType;
    private String teamProjectRegUser;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime teamProjectRegDate;

    @Builder
    public TeamProject(
        Integer teamProjectNo,
        Integer teamProjectSettleType,
        Integer teamProjectType,
        String teamProjectDepartment,
        String teamProjectDealCheck,
        String teamProjectDocumentNumber,
        String teamProjectDocumentTitle,
        Integer teamProjectPrice,
        String teamProjectCostCenter,
        String teamProjectWBSCode,
        String teamProjectActiveType,
        String teamProjectRegUser,
        LocalDateTime teamProjectRegDate
    ) {
        this.teamProjectNo = teamProjectNo;
        this.teamProjectSettleType = teamProjectSettleType;
        this.teamProjectType = teamProjectType;
        this.teamProjectDepartment = teamProjectDepartment;
        this.teamProjectDealCheck = teamProjectDealCheck;
        this.teamProjectDocumentNumber = teamProjectDocumentNumber;
        this.teamProjectDocumentTitle = teamProjectDocumentTitle;
        this.teamProjectPrice = teamProjectPrice;
        this.teamProjectCostCenter = teamProjectCostCenter;
        this.teamProjectWBSCode = teamProjectWBSCode;
        this.teamProjectActiveType = teamProjectActiveType;
        this.teamProjectRegUser = teamProjectRegUser;
        this.teamProjectRegDate = teamProjectRegDate;
    }

}
