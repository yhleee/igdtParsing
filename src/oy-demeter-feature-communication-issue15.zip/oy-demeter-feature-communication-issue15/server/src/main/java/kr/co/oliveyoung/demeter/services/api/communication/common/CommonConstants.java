package kr.co.oliveyoung.demeter.services.api.communication.common;

public class CommonConstants {
    public static final String VideoServiceUserApiKey = "4798984ab05bc1f4ddc8e1910eec0d26c7ceb5c50faf6dc945dca6e5f0a18340";
}
