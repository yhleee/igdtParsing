package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.TagTypeCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TagVO extends BaseVO{
    private Long tagNo;
    private String tagName;
    private TagTypeCode tagTypeCode;
    private Long tagGroupNo;
    private String tagOrder;

}
