package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "filter",
    "show_by_filter",
    "is_showable"
})
public class SubtitlePolicy {
    @JsonProperty("filter")
    private Filter filter;
    @JsonProperty("show_by_filter")
    private Boolean showByFilter;
    @JsonProperty("is_showable")
    private Boolean isShowable;
}
