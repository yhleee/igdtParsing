package kr.co.oliveyoung.demeter.services.api.settle.service;

import kr.co.oliveyoung.demeter.utils.DRMUtil;
import kr.co.oliveyoung.feature.settle.Asset;
import kr.co.oliveyoung.feature.settle.mapper.AssetMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import static kr.co.oliveyoung.demeter.common.constants.CommonConstant.DRM_FILE_PATH;

@Slf4j
@Service
public class AssetService {

    private final AssetMapper assetMapper;

    @Value("${oy-ez.api.host}")
    private String oyEzApiHost;

    public AssetService(AssetMapper assetMapper) {
        this.assetMapper = assetMapper;
    }

    @Transactional(readOnly = true)
    public List<Asset> getAssetList(int page, int size) {
        Integer offset = (page - 1) * size;
        return assetMapper.selectAssetList(size, offset);
    }

    @Transactional
    public Map<String, String> setDrmExcelParseAsset(MultipartFile uploadFile) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            InputStream upLoadExcelFile = null;

            String[] uploadFileSplitArray = uploadFile.getOriginalFilename().split("\\.");
            String decodeFileName = uploadFileSplitArray[0]
                + "_dec_"
                + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())
                + "."
                + uploadFileSplitArray[1];

            if (DRMUtil.drmFileCheck(uploadFile)) {
                DRMUtil.drmFileDecode(uploadFile, decodeFileName);
                Thread.sleep(4000);
                upLoadExcelFile = new FileInputStream(System.getProperty("user.dir") + DRM_FILE_PATH + decodeFileName);
            } else {
                // DRM 파일이 아닐 때
                upLoadExcelFile = uploadFile.getInputStream();
            }

            // Excel
            Workbook workbook = new HSSFWorkbook(upLoadExcelFile);

            StringBuilder costCenterStr = new StringBuilder();
            List<String> assetCdList = new ArrayList<>();
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                if (row.getCell(10) == null) {
                    break;
                }

                // 자산이체 번호 중복처리를 위한 리스트 가공
                assetCdList.add(row.getCell(0).toString());

                // 업로드할 매장 리스트 가공
                costCenterStr.append(row.getCell(10).toString());
                costCenterStr.append(",");
            }

            log.info("Request costCenterStr: " + costCenterStr);

            // 중복된 자산번호값 예외처리
            StringBuilder duplicateAssetCdStr = new StringBuilder();
            Map<String, Integer> countMap = new HashMap<>();
            assetCdList.forEach(e -> {
                Integer count = countMap.get(e);
                countMap.put(e, count == null ? 1 : count + 1);
            });

            countMap.forEach((k, v) -> {
                if (v > 1) {
                    duplicateAssetCdStr.append(k);
                    duplicateAssetCdStr.append(",");
                }
            });

            if (!duplicateAssetCdStr.toString().isEmpty()) {
                retMap.put("result", "FAIL");
                retMap.put("msg", "업로드 실패: 중복된 데이터 존재 ("
                + duplicateAssetCdStr.toString().substring(0, duplicateAssetCdStr.length()-1)
                + ")");
                return retMap;
            }

            // 업로드할 매장 리스트의 코드 가져오기
            JSONArray costCenterJsonArray = null;
            if (!costCenterStr.toString().isEmpty()) {
                String url = oyEzApiHost;
                HttpClient httpClient = new HttpClient();
                GetMethod method = new GetMethod(url);
                method.setQueryString(new NameValuePair[] {
                    new NameValuePair("storeName", costCenterStr.toString().substring(0, costCenterStr.length()-1))
                });
                httpClient.executeMethod(method);
                byte[] responseBody = method.getResponseBody();

                JSONObject storeListStr = null;
                JSONObject storeListJson = null;
                storeListStr = new JSONObject(new String(responseBody));
                storeListJson = new JSONObject(storeListStr.get("contents").toString());
                costCenterJsonArray = (JSONArray) storeListJson.get("costcenterList");
            }

            // 저장하기 전 데이터 TRUNCATE
            assetMapper.truncateAssetAllData();

            // 데이터를 저장 로직
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                // 코스트 센터 코드 매칭
                // 정보전략팀만 예외처리
                String costCenterCd = "";
                if (row.getCell(10).toString().equals("정보전략팀")) {
                    costCenterCd = "2000049";
                } else {
                    if (costCenterJsonArray != null) {
                        for(int k=0; k<costCenterJsonArray.length(); k++) {
                            JSONObject costCenterObject = costCenterJsonArray.getJSONObject(k);

                            if (row.getCell(10).toString().equals(costCenterObject.getString("costcenterName"))) {
                                costCenterCd = costCenterObject.getString("costcenterCode");
                            }
                        }
                    }
                }

                Asset asset = Asset.builder()
                    .assetCd(row.getCell(0).toString())
                    .assetTxt( (row.getCell(1) == null) ? "" : row.getCell(1).toString() )
                    .assetLo( (row.getCell(2) == null) ? "" : row.getCell(2).toString() )
                    .mngCstCntrCd( (row.getCell(3) == null) ? "" : row.getCell(3).toString() )
                    .mngCstCntrNm( (row.getCell(4) == null) ? "" : row.getCell(4).toString() )
                    .mngMn( (row.getCell(5) == null) ? "" : row.getCell(5).toString() )
                    .assetPartTypeCd(row.getCell(6).toString())
                    .partRate( (row.getCell(7) == null) ? null : Integer.parseInt(row.getCell(7).toString()) )
                    .procCnt( (row.getCell(8) == null) ? null : Integer.parseInt(row.getCell(8).toString()) )
                    .toCstCntrCd(costCenterCd)
                    .toCstCntrNm( (row.getCell(10) == null) ? "" : row.getCell(10).toString() )
                    .build();
                assetMapper.insertAsset(asset);
            }

            // 완료 후 파일 삭제
            File delFile = new File(System.getProperty("user.dir") + DRM_FILE_PATH);
            File[] drmFiles = delFile.listFiles();
            for (File fileItem: drmFiles) {
                fileItem.delete();
                log.info("File Delete OK: " + fileItem.getName());
            }
        } catch (Exception e) {
            log.info("setCSVParseAsset ERROR !!", e);
            retMap.put("result", "FAIL");
            retMap.put("msg", "업로드 실패: 데이터를 확인하여 주시길 바랍니다.");
            return retMap;
        }

        return retMap;
    }

    /*
    @Transactional
    public void setCSVParseAsset(List<Map<String, Object>> parseAssetList) {
        try {
            // 업로드할 매장 리스트
            StringBuilder costCenterStr = new StringBuilder();
            JSONArray array = new JSONArray(parseAssetList);
            for (int i=0; i<array.length(); i++) {
                JSONObject jsonObject = array.getJSONObject(i);
                costCenterStr.append(jsonObject.getString("TO_CST_CNTR_NM"));
                costCenterStr.append(",");
            }

            // 업로드할 매장 리스트의 코드 가져오기
            String url = oyEzApiHost;
            HttpClient httpClient = new HttpClient();
            GetMethod method = new GetMethod(url);
            method.setQueryString(new NameValuePair[] {
                new NameValuePair("storeName", costCenterStr.toString().substring(0, costCenterStr.length()-1))
            });
            httpClient.executeMethod(method);
            byte[] responseBody = method.getResponseBody();

            JSONObject storeListStr = null;
            JSONObject storeListJson = null;
            storeListStr = new JSONObject(new String(responseBody));
            storeListJson = new JSONObject(storeListStr.get("contents").toString());
            JSONArray costCenterJsonArray = (JSONArray) storeListJson.get("costcenterList");

            // 저장하기 전 데이터 TRUNCATE
            assetMapper.truncateAssetAllData();

            // 데이터를 저장 로직
            for (int j=0; j<array.length(); j++) {
                String costCenterCd = null;
                JSONObject jsonObject = array.getJSONObject(j);

                // 코스트 센터 코드 매칭
                for(int k=0; k<costCenterJsonArray.length(); k++) {
                    JSONObject costCenterObject = costCenterJsonArray.getJSONObject(k);

                    if (jsonObject.getString("TO_CST_CNTR_NM").equals(costCenterObject.getString("costcenterName"))) {
                        costCenterCd = costCenterObject.getString("costcenterCode");
                    }
                }

                Asset asset = Asset.builder()
                        .assetCd(Long.parseLong(jsonObject.getString("ASSET_CD")))
                        .assetTxt( (Optional.ofNullable(jsonObject.getString("ASSET_TXT")).map(String::valueOf).orElse(null).equals("")) ? null : jsonObject.getString("ASSET_TXT") )
                        .assetLo( (Optional.ofNullable(jsonObject.getString("ASSET_LO")).map(String::valueOf).orElse(null).equals("")) ? null : jsonObject.getString("ASSET_TXT") )
                        .mngCstCntrCd(jsonObject.getString("MNG_CST_CNTR_CD"))
                        .mngCstCntrNm(jsonObject.getString("MNG_CST_CNTR_NM"))
                        .mngMn(jsonObject.getString("MNG_MN"))
                        .assetPartTypeCd(jsonObject.getString("ASSET_PART_TYPE_CD"))
                        .partRate( (Optional.ofNullable(jsonObject.getString("PART_RATE")).map(String::valueOf).orElse(null).equals("")) ? null : Integer.parseInt(jsonObject.getString("PART_RATE")) )
                        .procCnt( (Optional.ofNullable(jsonObject.getString("PROC_CNT")).map(String::valueOf).orElse(null).equals("")) ? null : Integer.parseInt(jsonObject.getString("PROC_CNT")) )
                        .toCstCntrCd(costCenterCd)
                        .toCstCntrNm(jsonObject.getString("TO_CST_CNTR_NM"))
                        .build();
                assetMapper.insertAsset(asset);
            }
        } catch (Exception e) {
            log.info("setCSVParseAsset ERROR !!", e);
        }
    }
     */



}
