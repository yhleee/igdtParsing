package kr.co.oliveyoung.feature.querybrowser;

import kr.co.oliveyoung.config.mybatis.MySqlEduMapper;

import java.util.List;
import java.util.Map;

@MySqlEduMapper
public interface QueryBrowserMapper {
  List<Map<String, Object>> select(QueryBrowserModel params);
}
