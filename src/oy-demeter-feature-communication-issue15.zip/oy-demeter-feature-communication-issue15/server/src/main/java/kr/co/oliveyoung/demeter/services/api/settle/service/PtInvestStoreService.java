package kr.co.oliveyoung.demeter.services.api.settle.service;

import kr.co.oliveyoung.demeter.common.enums.InvestStoreAssetType;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.services.api.settle.param.PtInvestStoreListParam;
import kr.co.oliveyoung.demeter.utils.DRMUtil;
import kr.co.oliveyoung.feature.settle.PtInvestStore;
import kr.co.oliveyoung.feature.settle.mapper.HqInvestStoreMapper;
import kr.co.oliveyoung.feature.settle.mapper.PtInvestStoreMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import static kr.co.oliveyoung.demeter.common.constants.CommonConstant.DRM_FILE_PATH;

@Slf4j
@Service
@AllArgsConstructor
public class PtInvestStoreService {

    private final PtInvestStoreMapper ptInvestStoreMapper;
    private final HqInvestStoreMapper hqInvestStoreMapper;

    @Transactional(readOnly = true)
    public List<PtInvestStore> getPtInvestStoreList(int page, int size, PtInvestStoreListParam param) {
        Integer offset = (page - 1) * size;
        return ptInvestStoreMapper.selectPtInvestStoreList(size, offset, param);
    }

    /*
    @Transactional(rollbackFor = {Exception.class})
    public Map<String, String> setCSVParseInvestStore(List<Map<String, Object>> parseInvestStoreList, PtInvestStoreListParam param) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            if (ptInvestStoreMapper.selectInvestStoreActiveTypeCnt("Y") > 0) {
                retMap.put("result", "FAIL");
                retMap.put("msg", "이미 확정처리가 완료되었습니다.");
                return retMap;
            }

            JSONArray array = new JSONArray(parseInvestStoreList);

            for (int fi=0; fi<array.length(); fi++) {
                JSONObject jsonObject = array.getJSONObject(fi);

                if (ptInvestStoreMapper.selectInvestStoreNameCnt(jsonObject.getString("INVEST_STORE_NAME")) < 1) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", jsonObject.getString("INVEST_STORE_NAME") + "는 존재하지 않는 매장명입니다.");
                    return retMap;
                }

                if (param.getInvestStoreCategoryNo() != Integer.parseInt(jsonObject.getString("INVEST_STORE_CATEGORY_NO"))) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "카테고리가 일치하지 않습니다.");
                    return retMap;
                }
            }

            ptInvestStoreMapper.deleteInvestStoreAllData(param.getInvestStoreCategoryNo());

            for (int i=0; i<array.length(); i++) {
                JSONObject jsonObject = array.getJSONObject(i);

                PtInvestStore ptInvestStore = PtInvestStore.builder()
                        .investStoreName(jsonObject.getString("INVEST_STORE_NAME"))
                        .investStoreType(Integer.parseInt(jsonObject.getString("INVEST_STORE_TYPE")))
                        .investStoreCategoryNo(param.getInvestStoreCategoryNo())
                        .investStoreAssetNo(Integer.parseInt(jsonObject.getString("INVEST_STORE_ASSET_NO")))
                        .investStoreCount( (Optional.ofNullable(jsonObject.getString("INVEST_STORE_COUNT")).map(String::valueOf).orElse(null).equals("")) ? null : Integer.parseInt(jsonObject.getString("INVEST_STORE_COUNT")) )
                        .investStorePrice( (Optional.ofNullable(jsonObject.getString("INVEST_STORE_PRICE")).map(String::valueOf).orElse(null).equals("")) ? null : Integer.parseInt(jsonObject.getString("INVEST_STORE_PRICE")) )
                        .investStoreRemarks(jsonObject.getString("INVEST_STORE_REMARKS"))
                        .sysRegDtime(LocalDateTime.now())
                        .sysRegrId("bkjeon")
                        .build();
                ptInvestStoreMapper.insertInvestStore(ptInvestStore);
            }
        } catch (Exception e) {
            log.info("setCSVParseInvestStore ERROR !!", e);
        }

        return retMap;
    }
    */

    @Transactional(rollbackFor = {Exception.class})
    public Map<String, String> setExcelParseInvestStore(MultipartFile uploadFile, PtInvestStoreListParam param, AccessTokenVO tokenVO) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            if (ptInvestStoreMapper.selectInvestStoreActiveTypeCnt("Y") > 0) {
                retMap.put("result", "FAIL");
                retMap.put("msg", "이미 확정처리가 완료되었습니다.");
                return retMap;
            }

            // Excel
            Workbook workbook = new HSSFWorkbook(uploadFile.getInputStream());

            // 데이터 검증
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                if (row.getCell(0) == null || row.getCell(1) == null) {
                    break;
                }

                if (hqInvestStoreMapper.selectHqInvestStoreNameCnt(row.getCell(0).toString()) < 1) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", row.getCell(0).toString() + "는 존재하지 않는 매장명입니다.");
                    return retMap;
                }

                if ( param.getInvestStoreCategoryNo() != (int) Double.parseDouble(row.getCell(2).toString()) ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "카테고리가 일치하지 않습니다.");
                    return retMap;
                }
            }

            // 데이터 초기화
            ptInvestStoreMapper.deleteInvestStoreAllData(param.getInvestStoreCategoryNo());

            // 데이터 저장
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                if (row.getCell(0) == null || row.getCell(1) == null) {
                    break;
                }

                PtInvestStore ptInvestStore = PtInvestStore.builder()
                        .investStoreName(row.getCell(0).toString())
                        .investStoreType((int) Double.parseDouble(row.getCell(1).toString()))
                        .investStoreCategoryNo(param.getInvestStoreCategoryNo())
                        .investStoreAssetNo((int) Double.parseDouble(row.getCell(3).toString()))
                        .investStoreCount( (Optional.ofNullable((int) Double.parseDouble(row.getCell(4).toString()))
                                .map(String::valueOf)
                                .orElse(null)
                                .equals("")) ? null : (int) Double.parseDouble(row.getCell(4).toString()) )
                        .investStorePrice( (Optional.ofNullable((int) Double.parseDouble(row.getCell(5).toString()))
                                .map(String::valueOf)
                                .orElse(null)
                                .equals("")) ? null : (int) Double.parseDouble(row.getCell(5).toString()) )
                        .investStoreRemarks(row.getCell(6).toString())
                        .sysRegDtime(LocalDateTime.now())
                        .sysRegrId(tokenVO.getLoginId())
                        .build();
                ptInvestStoreMapper.insertInvestStore(ptInvestStore);
            }
        } catch (Exception e) {
            log.info("setCSVParseInvestStore ERROR !!", e);
        }

        return retMap;
    }

    @Transactional(rollbackFor = {Exception.class})
    public Map<String, String> setDrmExcelParseInvestStore(
        MultipartFile uploadFile,
        PtInvestStoreListParam param,
        AccessTokenVO tokenVO
    ) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            if (ptInvestStoreMapper.selectInvestStoreActiveTypeCnt("Y") > 0) {
                retMap.put("result", "FAIL");
                retMap.put("msg", "이미 확정처리가 완료되었습니다.");
                return retMap;
            }

            InputStream upLoadExcelFile = null;

            String[] uploadFileSplitArray = uploadFile.getOriginalFilename().split("\\.");
            String decodeFileName = uploadFileSplitArray[0]
                    + "_dec_"
                    + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())
                    + "."
                    + uploadFileSplitArray[1];

            if (DRMUtil.drmFileCheck(uploadFile)) {
                DRMUtil.drmFileDecode(uploadFile, decodeFileName);
                Thread.sleep(3000);
                upLoadExcelFile = new FileInputStream(
                    System.getProperty("user.dir") + DRM_FILE_PATH + decodeFileName
                );
            } else {
                // DRM 파일이 아닐 때
                upLoadExcelFile = uploadFile.getInputStream();
            }

            // Excel
            Workbook workbook = new HSSFWorkbook(upLoadExcelFile);

            // 데이터 검증
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                if (row.getCell(0) == null || row.getCell(1) == null) {
                    break;
                }

                if (hqInvestStoreMapper.selectHqInvestStoreNameCnt(row.getCell(0).toString()) < 1) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", row.getCell(0).toString() + "는 존재하지 않는 매장명입니다.");
                    return retMap;
                }

                if ( param.getInvestStoreCategoryNo() != (int) Double.parseDouble(row.getCell(2).toString()) ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "카테고리가 일치하지 않습니다.");
                    return retMap;
                }

                if (getInvestStoreAssetTypeNo(row.getCell(3).toString().trim()) == 0) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", row.getCell(3).toString().trim() + "는 등록되지 않는 장비입니다.");
                    return retMap;
                }
            }

            // 데이터 초기화
            ptInvestStoreMapper.deleteInvestStoreAllData(param.getInvestStoreCategoryNo());

            // 데이터 저장
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 2) {
                    continue;
                }

                if (row.getCell(0) == null || row.getCell(1) == null || row.getCell(2) == null) {
                    break;
                }

                PtInvestStore ptInvestStore = PtInvestStore.builder()
                        .investStoreName(row.getCell(0).toString())
                        .investStoreType((int) Double.parseDouble(row.getCell(1).toString()))
                        .investStoreCategoryNo(param.getInvestStoreCategoryNo())
                        .investStoreAssetNo(getInvestStoreAssetTypeNo(row.getCell(3).toString().trim()))
                        .investStoreCount( (row.getCell(4) == null) ? null : (int) Double.parseDouble(row.getCell(4).toString()) )
                        .investStorePrice( (row.getCell(5) == null) ? null : (int) Double.parseDouble(row.getCell(5).toString()) )
                        .investStoreRemarks( (row.getCell(6) == null) ? "" : row.getCell(6).toString() )
                        .sysRegDtime(LocalDateTime.now())
                        .sysRegrId(tokenVO.getLoginId())
                        .build();
                ptInvestStoreMapper.insertInvestStore(ptInvestStore);
            }
        } catch (Exception e) {
            log.info("setDrmExcelParseInvestStore ERROR !!", e);
        }

        return retMap;
    }

    @Transactional
    public String updateInvestStoreActiveType(String investStoreActiveType) {
        String retMsg = "확정 처리가 완료 되었습니다.";
        if (investStoreActiveType.equals("N")) {
            retMsg = "확정 처리가 취소 되었습니다.";
        }

        ptInvestStoreMapper.updateInvestStoreActiveType(investStoreActiveType);
        return retMsg;
    }

    private int getInvestStoreAssetTypeNo(String investStoreAssetType) {
        int retInvestStoreAssetTypeNo = 0;

        // TODO: switch 문으로 변경 필요
        if (investStoreAssetType.equals("RACK")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.RACK.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("VPN")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.VPN.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("IC단말기")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.IC_TERMINAL.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("LED")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.LED.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("셋탑PC")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.SETTOP_PC.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("POS")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.POS.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("서지보호기")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.SURGE_PROTECTOR.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("HUB")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.HUB.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("핸드스캐너")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.HAND_SCANNER.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("PDA")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.PDA.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("사인패드")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.SIGN_PAD.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("CAT")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.CAT.getInvestStroeAssetNo();
        } else if (investStoreAssetType.equals("스위치")) {
            retInvestStoreAssetTypeNo = InvestStoreAssetType.SWITCH.getInvestStroeAssetNo();
        }

        return retInvestStoreAssetTypeNo;
    }

}
