package kr.co.oliveyoung.feature.communication.education.model;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AttachmentGroup {
    private Long attachGroupNo;
    private String areaTypeCode;
    private Integer creator;
    private String createDatetime;
    private Integer updater;
    private String updateDatetime;
}
