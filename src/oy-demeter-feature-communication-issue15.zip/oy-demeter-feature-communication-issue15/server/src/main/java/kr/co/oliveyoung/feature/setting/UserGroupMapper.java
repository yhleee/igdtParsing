package kr.co.oliveyoung.feature.setting;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.setting.model.User;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import java.util.List;
import java.util.Map;

@MySqlOyisMapper
public interface UserGroupMapper {
    List<UserGroup> selectGroups();
    List<User> selectGroupUsersAndNoGroupUsers(Integer groupNo);
    void insertGroup(UserGroup userGroup);
    void updateGroup(UserGroup userGroup);
    int deleteUserGroups(Integer... groupNos);

//    List<UserGroupMap> selectUserGroupMappings(Integer groupNo, Integer userNo);
    int insertUserGroupMappings(Map<String, Object> param);//groupNo:xxx, userNos...
    int deleteUserGroupMappings(Map<String, Object> param);//groupNo:xxx, userNos...

    int deleteUserGroupMappingsByGroupNos(Integer... groupNos);
//    List<UserGroup> selectUserGroupMapList(String userId);
}
