package kr.co.oliveyoung.feature.setting;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.setting.model.User;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import java.util.List;
import java.util.Map;

@MySqlOyisMapper
public interface UserMapper {
    User selectUser(Map<String, Object> param);
    int updateUser(User user);
    int insertUser(User user);
    List<UserGroup> selectUserGroup(Integer userNo);
}
