package kr.co.oliveyoung.feature.settle;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
public class Asset {
    private String assetCd;
    private String assetTxt;
    private String assetLo;
    private String mngCstCntrCd;
    private String mngCstCntrNm;
    private String mngMn;
    private String assetPartTypeCd;
    private Integer partRate;
    private Integer procCnt;
    private String toCstCntrCd;
    private String toCstCntrNm;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysRegDtime;

    @Builder
    public Asset(
        String assetCd,
        String assetTxt,
        String assetLo,
        String mngCstCntrCd,
        String mngCstCntrNm,
        String mngMn,
        String assetPartTypeCd,
        Integer partRate,
        Integer procCnt,
        String toCstCntrCd,
        String toCstCntrNm,
        LocalDateTime sysRegDtime
    ) {
        this.assetCd = assetCd;
        this.assetTxt = assetTxt;
        this.assetLo = assetLo;
        this.mngCstCntrCd = mngCstCntrCd;
        this.mngCstCntrNm = mngCstCntrNm;
        this.mngMn = mngMn;
        this.assetPartTypeCd = assetPartTypeCd;
        this.partRate = partRate;
        this.procCnt = procCnt;
        this.toCstCntrCd = toCstCntrCd;
        this.toCstCntrNm = toCstCntrNm;
        this.sysRegDtime = sysRegDtime;
    }

}
