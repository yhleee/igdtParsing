package kr.co.oliveyoung.feature.settle;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class HqInvestStoreAsset {

    private Integer investStoreAssetNo;
    private Integer investStoreNo;
    private Integer investStoreAssetType;
    private Integer investStoreAssetRack;
    private Integer investStoreAssetVpn;
    private Integer investStoreAssetLed;
    private Integer investStoreAssetSettopPc;
    private Integer investStoreAssetPos;
    private Integer investStoreAssetSurgeProtector;
    private Integer investStoreAssetHub;
    private Integer investStoreAssetHandScanner;
    private Integer investStoreAssetPda;
    private Integer investStoreAssetSignPad;
    private Integer investStoreAssetCat;
    private Integer investStoreAssetSwitch;
    private Integer investStoreAssetIcTerminal;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysRegDtime;

    private String sysRegrId;

    // pt invest store data check
    private String investStoreAssetRackYn;
    private String investStoreAssetVpnYn;
    private String investStoreAssetLedYn;
    private String investStoreAssetSettopPcYn;
    private String investStoreAssetPosYn;
    private String investStoreAssetSurgeProtectorYn;
    private String investStoreAssetHubYn;
    private String investStoreAssetHandScannerYn;
    private String investStoreAssetPdaYn;
    private String investStoreAssetSignPadYn;
    private String investStoreAssetCatYn;
    private String investStoreAssetSwitchYn;
    private String investStoreAssetIcTerminalYn;

    @Builder
    public HqInvestStoreAsset(
        Integer investStoreAssetNo,
        Integer investStoreNo,
        Integer investStoreAssetType,
        Integer investStoreAssetRack,
        Integer investStoreAssetVpn,
        Integer investStoreAssetLed,
        Integer investStoreAssetSettopPc,
        Integer investStoreAssetPos,
        Integer investStoreAssetSurgeProtector,
        Integer investStoreAssetHub,
        Integer investStoreAssetHandScanner,
        Integer investStoreAssetPda,
        Integer investStoreAssetSignPad,
        Integer investStoreAssetCat,
        Integer investStoreAssetSwitch,
        Integer investStoreAssetIcTerminal,
        LocalDateTime sysRegDtime,
        String sysRegrId,
        String investStoreAssetLedYn,
        String investStoreAssetSettopPcYn,
        String investStoreAssetPosYn,
        String investStoreAssetSurgeProtectorYn,
        String investStoreAssetHubYn,
        String investStoreAssetHandScannerYn,
        String investStoreAssetPdaYn,
        String investStoreAssetSignPadYn,
        String investStoreAssetCatYn,
        String investStoreAssetSwitchYn,
        String investStoreAssetIcTerminalYn
    ) {
        this.investStoreAssetNo = investStoreAssetNo;
        this.investStoreNo = investStoreNo;
        this.investStoreAssetType = investStoreAssetType;
        this.investStoreAssetRack = investStoreAssetRack;
        this.investStoreAssetVpn = investStoreAssetVpn;
        this.investStoreAssetLed = investStoreAssetLed;
        this.investStoreAssetSettopPc = investStoreAssetSettopPc;
        this.investStoreAssetPos = investStoreAssetPos;
        this.investStoreAssetSurgeProtector = investStoreAssetSurgeProtector;
        this.investStoreAssetHub = investStoreAssetHub;
        this.investStoreAssetHandScanner = investStoreAssetHandScanner;
        this.investStoreAssetPda = investStoreAssetPda;
        this.investStoreAssetSignPad = investStoreAssetSignPad;
        this.investStoreAssetCat = investStoreAssetCat;
        this.investStoreAssetSwitch = investStoreAssetSwitch;
        this.investStoreAssetIcTerminal = investStoreAssetIcTerminal;
        this.sysRegDtime = sysRegDtime;
        this.sysRegrId = sysRegrId;
        this.investStoreAssetLedYn = investStoreAssetLedYn;
        this.investStoreAssetSettopPcYn = investStoreAssetSettopPcYn;
        this.investStoreAssetPosYn = investStoreAssetPosYn;
        this.investStoreAssetSurgeProtectorYn = investStoreAssetSurgeProtectorYn;
        this.investStoreAssetHubYn = investStoreAssetHubYn;
        this.investStoreAssetHandScannerYn = investStoreAssetHandScannerYn;
        this.investStoreAssetPdaYn = investStoreAssetPdaYn;
        this.investStoreAssetSignPadYn = investStoreAssetSignPadYn;
        this.investStoreAssetCatYn = investStoreAssetCatYn;
        this.investStoreAssetSwitchYn = investStoreAssetSwitchYn;
        this.investStoreAssetIcTerminalYn = investStoreAssetIcTerminalYn;
    }

}
