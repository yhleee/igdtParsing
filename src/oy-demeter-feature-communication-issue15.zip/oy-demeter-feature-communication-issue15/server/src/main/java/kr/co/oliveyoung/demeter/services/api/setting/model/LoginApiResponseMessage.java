package kr.co.oliveyoung.demeter.services.api.setting.model;

import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
public class LoginApiResponseMessage extends ApiResponseMessage {
    private String accessToken;

    public LoginApiResponseMessage(ResponseResult result) {
        super(result);
    }

    public LoginApiResponseMessage(ResponseResult result, String message) {
        super(result, message);
    }
}
