package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum AttachTargetTypeCode {
    POST("POST", "게시물"),
    COMMENT("COMMENT", "댓글"),
    QUIZ("QUIZ", "평가"),
    SURVEY("SURVEY", "설문");

    private String code;
    private String text;

    AttachTargetTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
