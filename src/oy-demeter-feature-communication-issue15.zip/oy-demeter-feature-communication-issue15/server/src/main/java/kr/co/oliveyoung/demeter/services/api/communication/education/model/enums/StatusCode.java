package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum StatusCode {
    NORMAL("NORMAL", "정상"),
    DELETED("DELETED", "사용자 삭제"),
    HIDDEN("HIDDEN", "게시물 숨김처리(관리자)"),
    REPORTED("REPORTED", "신고처리");

    private String code;
    private String text;

    StatusCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
