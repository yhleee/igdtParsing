package kr.co.oliveyoung.feature.querybrowser;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryBrowserModel implements Serializable {

  private static final long serialVersionUID = -3202772902987063709L;
  private String query;
}
