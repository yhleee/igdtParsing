package kr.co.oliveyoung.demeter.services.api.setting.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Sets;
import java.util.Objects;
import java.util.Set;
import kr.co.oliveyoung.feature.setting.model.UserMenuAuthority;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserMenuAuthorityTree implements Comparable<UserMenuAuthorityTree>{
    private Integer menuNo;
    private String menuName;
    private String iconName;
    private int sortSeq;
    private Integer level;
    private Integer upperMenuNo;
    private String url;
    private Boolean usable;
    private Set<UserMenuAuthorityTree> children;

    public UserMenuAuthorityTree(UserMenuAuthority userMenuAuthority) {
        this.menuNo = userMenuAuthority.getMenuNo();
        this.menuName = userMenuAuthority.getMenuName();
        this.iconName = userMenuAuthority.getIconName();
        this.sortSeq = userMenuAuthority.getSortSeq();
        this.level = userMenuAuthority.getLevel();
        this.upperMenuNo = userMenuAuthority.getUpperMenuNo();
        this.url = userMenuAuthority.getUrl();
        this.usable = userMenuAuthority.isUsable();
        this.children = Sets.newHashSet();
    }

    public void addChildMenu(UserMenuAuthorityTree userMenuAuthorityTree) {
        this.children.add(userMenuAuthorityTree);
    }

    public boolean isLeaf() {
        return CollectionUtils.isEmpty(children);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + menuNo;
        return result;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (Objects.isNull(object)) return false;
        if (getClass() != object.getClass()) return false;
        if (object instanceof UserMenuAuthorityTree) {
            if (((UserMenuAuthorityTree)object).menuNo == menuNo) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int compareTo(UserMenuAuthorityTree o) {
        return this.sortSeq - o.getSortSeq();
    }
}
