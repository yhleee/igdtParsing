package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserParam;
import kr.co.oliveyoung.demeter.services.api.setting.service.UserService;
import kr.co.oliveyoung.demeter.utils.JWTUtil;
import kr.co.oliveyoung.feature.setting.model.User;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@CrossOrigin
@RestController
@AllArgsConstructor
@RequestMapping("api/setting/user")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("회원 정보 조회")
    @GetMapping("/{userNo}")
    public ApiResponseMessage fetchUser(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        @PathVariable("userNo") Integer userNo) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS);
        result.setContents(userService.fetchUser(userNo));
        return result;
    }

    @ApiOperation("회원 등록")
    @PostMapping
    public ApiResponseMessage addUser(@RequestAttribute("userParam") UserParam userParam) {
        int insertCount = userService.addUser(
            User.builder()
                .loginId(userParam.getLoginId())
                .password(userParam.getPassword())
                .lastLoginDatetime(LocalDateTime.now().toString())
                .lastLoginIp("127.0.0.1")
                .build());
        if(insertCount != 1) {
            return new ApiResponseMessage(ResponseResult.FAIL, "이미 존재하는 아이디입니다.");
        }
        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }

    @ApiOperation("회원 그룹 조회")
    @GetMapping("/{userNo}/groups")
    public ApiResponseMessage fetchUserGroup(@PathVariable("userNo")Integer userNo) {        ;
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS);
        result.setContents(userService.fetchUserGroup(userNo));
        return result;
    }
}
