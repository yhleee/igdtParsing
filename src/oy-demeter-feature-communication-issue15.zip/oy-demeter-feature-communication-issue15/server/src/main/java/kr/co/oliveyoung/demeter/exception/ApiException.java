package kr.co.oliveyoung.demeter.exception;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ApiException extends RuntimeException {

    private String exceptionMsg;

    public String getMessage() {
        return this.exceptionMsg;
    }

}
