package kr.co.oliveyoung.feature.settle.mapper;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.settle.HqInvestStoreAsset;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@MySqlOyisMapper
public interface HqInvestStoreAssetMapper {
    List<HqInvestStoreAsset> selectHqInvestStoreAssetList(Integer investStoreNo);
    HqInvestStoreAsset selectHqInvestStoreAsset(Integer investStoreNo, Integer investStoreAssetType);
    void insertHqInvestStoreAsset(@Param("data") HqInvestStoreAsset hqInvestStoreAsset);
    void updateHqInvestStoreAsset(@Param("data") HqInvestStoreAsset hqInvestStoreAsset);
}
