package kr.co.oliveyoung.demeter.services.api.setting.service;

import com.google.common.collect.Maps;
import io.jsonwebtoken.lang.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuAuthorityTree;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuMappingGroup;
import kr.co.oliveyoung.feature.setting.UserMenuAuthorityMapper;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import kr.co.oliveyoung.feature.setting.model.UserMenu;
import kr.co.oliveyoung.feature.setting.model.UserMenuAuthority;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserMenuAuthorityService {

    @Autowired
    private UserMenuAuthorityMapper userMenuAuthorityMapper;

    @Transactional
    public int modifyUserMenuAuthorities(UserMenuMappingGroup userMenuGroup) {
        int updatedCount = 0;
        Map<String, Object> param = Maps.newHashMap();
        param.put("menuNo", userMenuGroup.getMenuNo());

        if(!Collections.isEmpty(userMenuGroup.getUnauthorizedGroups())) {
            param.put("groups", userMenuGroup.getUnauthorizedGroups());
            updatedCount += userMenuAuthorityMapper.deleteUserMenuAuthority(param);
        }

        if(!Collections.isEmpty(userMenuGroup.getAuthorizedGroups())) {
            param.put("groups", userMenuGroup.getAuthorizedGroups());
            updatedCount += userMenuAuthorityMapper.insertUserMenuAuthority(param);
        }
        return updatedCount;
    }

    public List<UserMenuAuthorityTree> getUserMenuAuthorities(Integer userNo) {
        Map<String, Object> param = Maps.newHashMap();
        param.put("userNo", userNo);

        return makeMenuAuthorityTree(userMenuAuthorityMapper.selectUserMenuAuthority(param));
    }

    public List<UserGroup> fetchAuthorizedGroups(Integer... menuNos) {
        return userMenuAuthorityMapper.selectAuthorizedGroup(menuNos);
    }

    public List<UserGroup> fetchUnauthorizedGroups(Integer... menuNos) {
        return userMenuAuthorityMapper.selectUnauthorizedGroup(menuNos);
    }

    public List<UserMenu> fetchGroupMenuAuthorities(Integer groupNo) {
        return userMenuAuthorityMapper.selectGroupMenuAuthority(groupNo);
    }

    private List<UserMenuAuthorityTree> makeMenuAuthorityTree(
        List<UserMenuAuthority> userMenuAuthorities) {

        Map<Integer, UserMenuAuthorityTree> authorityTreeMap = Maps.newTreeMap();

        userMenuAuthorities.stream().forEach(userMenuAuthority -> {
            authorityTreeMap.put(userMenuAuthority.getMenuNo(), new UserMenuAuthorityTree(userMenuAuthority));
        });

        authorityTreeMap.entrySet().stream().forEach(entry -> {
            UserMenuAuthorityTree userMenuAuthorityTree = entry.getValue();
            if (Objects.nonNull(userMenuAuthorityTree.getUpperMenuNo()) && authorityTreeMap
                .containsKey(userMenuAuthorityTree.getUpperMenuNo())) {
                authorityTreeMap.get(userMenuAuthorityTree.getUpperMenuNo()).addChildMenu(userMenuAuthorityTree);
            }
        });

        List<UserMenuAuthorityTree> menuTrees = authorityTreeMap.values().stream()
            .filter(
                userMenuAuthorityTree -> Objects.isNull(userMenuAuthorityTree.getUpperMenuNo()))
            .sorted()
            .collect(
                Collectors.toList());

        return menuTrees;
    }
}
