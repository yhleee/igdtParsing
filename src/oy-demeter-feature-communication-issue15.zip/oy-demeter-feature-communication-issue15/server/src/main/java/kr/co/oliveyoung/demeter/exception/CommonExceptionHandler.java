package kr.co.oliveyoung.demeter.exception;

import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice("kr.co.oliveyoung.oms")
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class CommonExceptionHandler {

    @ExceptionHandler(BindException.class)
    @ResponseBody
    public ApiResponseMessage bindException(BindException exception) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.FAIL, null, null);
        result.setMessage(exception.getFieldError().getDefaultMessage() + "32434");
        return result;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ApiException.class)
    @ResponseBody
    public ApiResponseMessage handleApiException(ApiException e) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.FAIL, null, null);
        result.setMessage("ApiExceptionHandler.handleException: " + e);
        return result;
    }


}
