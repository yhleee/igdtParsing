package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "mckey",
    "mcpf",
    "title",
    "intr",
    "seek",
    "seekable_end",
    "disable_playrate",
    "thumbnail",
    "play_section",
    "subtitle_policy"
})
@Data
@Builder
public class MediaContent {
    @JsonProperty("mckey")
    private String mckey;
    @JsonProperty("mcpf")
    private String mcpf;
    @JsonProperty("title")
    private String title;
    @JsonProperty("intr")
    private Boolean intr;
    @JsonProperty("seek")
    private Boolean seek;
    @JsonProperty("seekable_end")
    private Integer seekableEnd;
    @JsonProperty("disable_playrate")
    private Boolean disablePlayrate;
    @JsonProperty("thumbnail")
    private Thumbnail thumbnail;
    @JsonProperty("play_section")
    private PlaySection playSection;
    @JsonProperty("subtitle_policy")
    private SubtitlePolicy subtitlePolicy;
}
