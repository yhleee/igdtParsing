package kr.co.oliveyoung.demeter.services.api.communication.education.validator;

import java.util.Objects;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.AttachmentVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AttachFileTypeCode;
import org.apache.commons.io.FilenameUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Configuration
public class AttachmentValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return AttachmentVO.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        if(Objects.isNull(target)) {
            return;
        }

        if (!supports(target.getClass())) {
            throw new IllegalArgumentException(
                "Validator [" + this.getClass() + "] does not support [" + target.getClass() + "]");
        }

        AttachmentVO attachment = (AttachmentVO) target;

        //파일타입 필수
        if (Objects.isNull(attachment.getFileTypeCode())) {
            errors.reject("communication.eduction.empty", new Object[]{"fileType"}, null);
            return;
        }

        // 관리되는 첨부일 경우 (동영상 제외)
        if (AttachFileTypeCode.MANAGED_ATTACHMENT.contains(attachment.getFileTypeCode())) {
            if (Objects.isNull(attachment.getFilePath())) {
                errors.reject("communication.eduction.empty", new Object[]{"파일 경로"}, null);
                return;
            }
            String fileExtension = FilenameUtils.getExtension(attachment.getFilePath()).toLowerCase();
            if(!attachment.getFileTypeCode().getAllowedExtensions().contains(fileExtension)) {
                errors.reject("communication.attachment.notAllowed.fileExtension");
                return;
            }
        }
    }

    public void validateUpdate(Object target, Errors errors) {
        if(Objects.isNull(target)) {
            return;
        }

        if (!supports(target.getClass())) {
            throw new IllegalArgumentException(
                "Validator [" + this.getClass() + "] does not support [" + target.getClass() + "]");
        }

        AttachmentVO attachment = (AttachmentVO) target;

        if (Objects.isNull(attachment.getAttachNo())) {
            errors.reject("communication.eduction.empty", new Object[]{"attachNo"}, null);
            return;
        }

        if (Objects.isNull(attachment.getAttachGroupNo())) {
            errors.reject("communication.eduction.empty", new Object[]{"attachGroupNo"}, null);
            return;
        }

    }
}
