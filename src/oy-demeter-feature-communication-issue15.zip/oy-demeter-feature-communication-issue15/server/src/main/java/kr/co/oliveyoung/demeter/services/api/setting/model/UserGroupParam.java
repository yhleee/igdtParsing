package kr.co.oliveyoung.demeter.services.api.setting.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserGroupParam {
    private String groupName;
    private Integer[] groupNos;
    private Integer groupNo;
}
