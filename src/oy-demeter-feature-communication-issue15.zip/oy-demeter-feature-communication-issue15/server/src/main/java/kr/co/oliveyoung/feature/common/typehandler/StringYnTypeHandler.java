package kr.co.oliveyoung.feature.common.typehandler;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

public class StringYnTypeHandler implements TypeHandler<Boolean> {

    @Override
    public void setParameter(PreparedStatement ps, int i, Boolean parameter, JdbcType jdbcType)
        throws SQLException {
        ps.setString(1, parseString(parameter));
    }

    @Override
    public Boolean getResult(ResultSet rs, String columnName) throws SQLException {
        return parseBoolean(rs.getString(columnName));
    }

    @Override
    public Boolean getResult(ResultSet rs, int columnIndex) throws SQLException {
        return parseBoolean(rs.getString(columnIndex));
    }

    @Override
    public Boolean getResult(CallableStatement cs, int columnIndex) throws SQLException {
        return parseBoolean(cs.getString(columnIndex));
    }

    private Boolean parseBoolean(String value) {
        return StringUtils.equalsIgnoreCase(value, "y") ? true : false;
    }

    private String parseString(Boolean parameter) {
        return Objects.nonNull(parameter) && parameter ? "Y" : "N";
    }
}
