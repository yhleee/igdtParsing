package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import com.google.common.collect.Sets;
import java.util.EnumSet;
import java.util.Set;
import lombok.Getter;

@Getter
public enum AttachFileTypeCode {
    MOVIE("MOVIE", "동영상", Sets.newHashSet("avi", "mp4"), Integer.MAX_VALUE) {
        @Override
        public String getBaseUrl() {
            return "http://v.kr.kollus.com/s";
        }
    },
    BANNER("BANNER", "배너", Sets.newHashSet("jpg", "jpeg", "png", "bmp"), 10485760) {
        @Override
        public String getBaseUrl() {
            return "http://test.com";
        }
    },
    THUMBNAIL("THUMBNAIL", "썸네일", Sets.newHashSet("jpg", "jpeg", "png", "bmp"), 10485760) {
        @Override
        public String getBaseUrl() {
            return "http://test.com";
        }
    },
    IMAGE("IMAGE", "이미지", Sets.newHashSet("jpg", "jpeg", "png", "bmp"), 10485760) {
        @Override
        public String getBaseUrl() {
            return "http://test.com";
        }
    },
    ETC("ETC", "일반파일", Sets.newHashSet("zip", "doc", "pdf", "txt", "ppt"), 10485760) {
        @Override
        public String getBaseUrl() {
            return "http://image-educ.oliveyoung.co.kr";
        }
    };

    private String code;
    private String text;
    private Set<String> allowedExtensions;
    private int maxFileSize;

    AttachFileTypeCode(String code, String text, Set<String> allowedExtensions, int maxFileSize) {
        this.code = code;
        this.text = text;
        this.allowedExtensions = allowedExtensions;
        this.maxFileSize = maxFileSize;
    }
    public abstract String getBaseUrl();

    public static EnumSet<AttachFileTypeCode> MANAGED_ATTACHMENT = EnumSet.of(BANNER, THUMBNAIL, IMAGE, ETC);
}
