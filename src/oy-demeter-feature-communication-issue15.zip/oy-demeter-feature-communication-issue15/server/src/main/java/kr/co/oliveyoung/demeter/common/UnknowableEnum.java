package kr.co.oliveyoung.demeter.common;

public interface UnknowableEnum<T extends Enum<T>> {

  public T getUnknown();
}
