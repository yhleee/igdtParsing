package kr.co.oliveyoung.demeter.common.csv.upload;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class CSVFileDBInsert extends FileDBInsertParser {

    private final MultipartFile uploadFile;

    public CSVFileDBInsert(MultipartFile uploadFile) {
        this.uploadFile = uploadFile;
    }

    @Override
    public List<Map<String, Object>> getParseAssetList() throws IOException {
        CSVReaderExtended reader = new CSVReaderExtended(new InputStreamReader(uploadFile.getInputStream(), "EUC-KR"));
        String[] nextLine;
        List<Map<String, Object>> parseList = new ArrayList<>();
        int i = 0;

        try {
            while ((nextLine = reader.readNext()) != null) {
                Map<String, Object> vMap = new HashMap<>();

                if (i > 1) {
                    vMap.put("ASSET_CD", nextLine[0]);
                    vMap.put("ASSET_TXT", nextLine[1]);
                    vMap.put("ASSET_LO", nextLine[2]);
                    vMap.put("MNG_CST_CNTR_CD", nextLine[3]);
                    vMap.put("MNG_CST_CNTR_NM", nextLine[4]);
                    vMap.put("MNG_MN", nextLine[5]);
                    vMap.put("ASSET_PART_TYPE_CD", nextLine[6]);
                    vMap.put("PART_RATE", nextLine[7]);
                    vMap.put("PROC_CNT", nextLine[8]);
                    vMap.put("TO_CST_CNTR_CD", nextLine[9]);
                    vMap.put("TO_CST_CNTR_NM", nextLine[10]);

                    parseList.add(vMap);
                }

                i++;
            }
        } catch (Exception e) {
            log.info("getAssetList ERROR !! : {}", e.getMessage());
        }

        return parseList;
    }

    @Override
    public List<Map<String, Object>> getParsePtInvestStoreList() throws IOException {
        CSVReaderExtended reader = new CSVReaderExtended(new InputStreamReader(uploadFile.getInputStream(), "EUC-KR"));
        String[] nextLine;
        List<Map<String, Object>> parseList = new ArrayList<>();
        int i = 0;

        try {
            while ((nextLine = reader.readNext()) != null) {
                Map<String, Object> vMap = new HashMap<>();

                if (i > 1) {
                    vMap.put("INVEST_STORE_NAME", nextLine[0]);
                    vMap.put("INVEST_STORE_TYPE", nextLine[1]);
                    vMap.put("INVEST_STORE_CATEGORY_NO", nextLine[2]);
                    vMap.put("INVEST_STORE_ASSET_NO", nextLine[3]);
                    vMap.put("INVEST_STORE_COUNT", nextLine[4]);
                    vMap.put("INVEST_STORE_PRICE", nextLine[5]);
                    vMap.put("INVEST_STORE_REMARKS", nextLine[6]);

                    parseList.add(vMap);
                }

                i++;
            }
        } catch (Exception e) {
            log.info("getParsePtInvestStoreList ERROR !! : {}", e.getMessage());
        }

        return parseList;
    }

}
