package kr.co.oliveyoung.feature.communication.education.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MemberGroupAuthority {
    private Long memberGroupAuthorityNo;
    private Long memberGroupNo;
    private String areaTypeCode;
    private String targetTypeCode;
    private Long targetNo;
    private String authorityTypeCode;
    private Integer creator;
    private String createDatetime;
    private Integer updater;
    private String updateDatetime;
}
