package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "enable",
    "thread",
    "type"
})
public class Thumbnail {
    @JsonProperty("enable")
    public Boolean enable;
    @JsonProperty("thread")
    public Boolean thread;
    @JsonProperty("type")
    public String type;
}
