package kr.co.oliveyoung.feature.test;

import kr.co.oliveyoung.config.mybatis.MySqlEZMapper;

import java.util.List;

@MySqlEZMapper
public interface MySqlTestMapper {

    List<MySqlTest> selectTest();
}
