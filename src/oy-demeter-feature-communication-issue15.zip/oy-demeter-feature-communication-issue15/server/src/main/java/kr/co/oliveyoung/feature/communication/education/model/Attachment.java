package kr.co.oliveyoung.feature.communication.education.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Attachment {
    private Long attachmentNo;
    private Long attachmentGroupNo;
    private String fileType;
    private String filePath;
    private String fileUrl;
    private Long fileSize;
    private String mediaKey;
    private Integer order;
    private Integer creator;
    private String createDatetime;
    private Integer updater;
    private String updateDatetime;
}
