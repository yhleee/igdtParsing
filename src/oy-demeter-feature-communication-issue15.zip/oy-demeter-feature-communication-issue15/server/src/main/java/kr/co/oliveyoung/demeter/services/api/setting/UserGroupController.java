package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.common.validator.ValidationUtil;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserGroupParam;
import kr.co.oliveyoung.demeter.services.api.setting.service.UserGroupService;
import kr.co.oliveyoung.demeter.services.api.setting.validator.UserGroupValidator;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("api/setting")
public class UserGroupController {

    @Autowired
    private UserGroupService userGroupService;

    @Autowired
    private UserGroupValidator userGroupValidator;

    @ApiOperation("그룹 정보 리스트")
    @GetMapping("groups")
    public ApiResponseMessage getGroupList() {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS);
        result.setContents(userGroupService.getAllUserGroups());
        return result;
    }

    @ApiOperation("그룹 생성")
    @PostMapping("/group")
    public ApiResponseMessage addGroup(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @RequestBody UserGroupParam userGroupparam, BindingResult errors) {

        if(!BooleanUtils.toBoolean(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }

        userGroupValidator.validate(userGroupparam, errors);
        if (errors.hasErrors()) {
            return new ApiResponseMessage(ResponseResult.FAIL, ValidationUtil.getFirstErrorMessage(errors));
        }

        userGroupService.insertUserGroup(userGroupparam);

        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }

    @ApiOperation("그룹 수정")
    @PutMapping("/group")
    public ApiResponseMessage modifyGroup(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @RequestBody UserGroupParam userGroupParam, BindingResult errors) {
        if(!BooleanUtils.toBoolean(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }

        userGroupValidator.validate(userGroupParam, errors);
        if (errors.hasErrors()) {
            return new ApiResponseMessage(ResponseResult.FAIL, ValidationUtil.getFirstErrorMessage(errors));
        }

        userGroupService.updateUserGroup(userGroupParam);

        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }

    @ApiOperation("그룹 삭제")
    @DeleteMapping("/group")
    public ApiResponseMessage removeGroup(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @RequestBody UserGroupParam userGroupParam) {
        if(!BooleanUtils.toBoolean(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        userGroupService.deleteUserGroups(userGroupParam.getGroupNos());
        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }

    @ApiOperation("그룹별 사용자 조회")
    @GetMapping("group/{groupNo}/users")
    public ApiResponseMessage getGroupUsers(
        @PathVariable("groupNo") Integer groupNo) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS);
        result.setContents(userGroupService.getGroupUsers(groupNo));
        return result;
    }

    @ApiOperation("사용자-그룹 매핑 추가")
    @PostMapping("/group/{groupNo}/users/{userNos}")
    public ApiResponseMessage addUserGroupMapping(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @PathVariable("groupNo") Integer groupNo
        , @PathVariable("userNos") Integer... userNos) {
        if(!BooleanUtils.toBoolean(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        userGroupService.insertUserGroupMappings(groupNo, userNos);
        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }

    @ApiOperation("사용자-그룹 매핑 삭제")
    @DeleteMapping("/group/{groupNo}/users/{userNos}")
    public ApiResponseMessage removeUserGroupMapping(@RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
        , @PathVariable("groupNo") Integer groupNo
        , @PathVariable("userNos") Integer... userNos) {
        if(!BooleanUtils.toBoolean(tokenVO.getAdminYn())) {
            return new ApiResponseMessage(ResponseResult.FAIL, "관리자 권한이 없습니다.");
        }
        userGroupService.deleteUserGroupMappings(groupNo, userNos);
        return new ApiResponseMessage(ResponseResult.SUCCESS);
    }
}
