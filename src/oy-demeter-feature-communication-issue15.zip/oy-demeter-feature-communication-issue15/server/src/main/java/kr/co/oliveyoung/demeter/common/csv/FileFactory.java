package kr.co.oliveyoung.demeter.common.csv;

import kr.co.oliveyoung.demeter.common.csv.download.CSVFileDownload;
import kr.co.oliveyoung.demeter.common.csv.download.FileDownloader;
import kr.co.oliveyoung.demeter.common.csv.upload.CSVFileDBInsert;
import kr.co.oliveyoung.demeter.common.csv.upload.FileDBInsertParser;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class FileFactory extends FileFactoryAbstract {

    @Override
    public FileDBInsertParser fileDBInsert(String type, MultipartFile uploadFile) {
        if (type.equals("csv")) {
            return new CSVFileDBInsert(uploadFile);
        } else {
            return new CSVFileDBInsert(uploadFile);
        }
    }

    @Override
    public FileDownloader fileDownloader(String type, HttpServletResponse response)
        throws IOException {
        if (type.equals("csv")) {
            return new CSVFileDownload(response);
        } else {
            return new CSVFileDownload(response);
        }
    }

}
