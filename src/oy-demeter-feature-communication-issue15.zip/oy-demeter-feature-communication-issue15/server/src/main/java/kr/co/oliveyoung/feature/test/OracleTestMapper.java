package kr.co.oliveyoung.feature.test;

import kr.co.oliveyoung.config.mybatis.OracleMapper;

import java.util.List;

@OracleMapper
public interface OracleTestMapper {

    List<OracleTest> selectTest();
}
