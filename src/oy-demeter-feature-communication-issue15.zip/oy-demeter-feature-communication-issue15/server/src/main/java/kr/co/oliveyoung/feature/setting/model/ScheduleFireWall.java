package kr.co.oliveyoung.feature.setting.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleFireWall {

    private Long scheduleNo;
    private String scheduleType;
    private String scheduleSystemName;
    private String schedulePurpose;
    private String scheduleJsonContents;
    private String sourceIp;
    private String destinationIp;
    private String port;
    private String useYn;
    private String policyStartDate;
    private String policyEndDate;
    private String policyNoticeDate;
    private String docNumber;

    private String sysRegrId;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysRegDtime;

    private String sysModrId;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysModDtime;

}
