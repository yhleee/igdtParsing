package kr.co.oliveyoung.feature.setting.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private Integer userNo;
    private String loginId;
    @JsonIgnore
    private String password;
    private String adminYn;
    private String lastLoginDatetime;
    private String lastLoginIp;
    private Integer groupNo;
    private Integer eduCommMemberNo;

    @JsonIgnore
    public boolean isAdmin() {
        return StringUtils.equalsIgnoreCase(adminYn, "y");
    }
}
