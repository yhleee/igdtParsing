package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum AuthorityTypeCode {
    READ("READ", "읽기"),
    WRITE("WRITE", "쓰기"),
    DELETE("DELETE", "삭제");

    private String code;
    private String text;

    AuthorityTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
