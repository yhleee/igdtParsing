package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import kr.co.oliveyoung.common.utils.DateUtils;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.exception.auth.AuthException;
import kr.co.oliveyoung.demeter.services.api.setting.model.LoginApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserParam;
import kr.co.oliveyoung.demeter.services.api.setting.service.UserService;
import kr.co.oliveyoung.demeter.utils.JWTUtil;
import kr.co.oliveyoung.feature.setting.model.User;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("api/login")
public class LoginController {

    @Autowired
    private UserService userService;

    @ApiOperation("Login")
    @PostMapping
    public ApiResponseMessage login(@RequestAttribute("userParam") UserParam userParam, HttpServletRequest request) {
        User user = userService.fetchUser(userParam);

        if (Objects.isNull(user)) {
            throw new AuthException("User 정보가 없습니다.", 401);
        }

        //로그인 정보 업데이트
        user.setLastLoginIp(Optional.ofNullable(request.getHeader("X-FORWARDED-FOR"))
            .orElse(request.getRemoteAddr()));
        userService.modifyUser(user);

        //토큰 생성
        String accessToken = JWTUtil.createJWT(
            AccessTokenVO.builder().loginId(user.getLoginId()).userNo(user.getUserNo())
                .adminYn(user.getAdminYn())
                .lastLoginDatetime(DateUtils.date("yyyyMMddHHmmss", new Date()))
                .eduCommMemberNo(user.getEduCommMemberNo()).build());

        LoginApiResponseMessage responseMessage = new LoginApiResponseMessage(ResponseResult.SUCCESS);
        responseMessage.setAccessToken(accessToken);
        return responseMessage;
    }

}
