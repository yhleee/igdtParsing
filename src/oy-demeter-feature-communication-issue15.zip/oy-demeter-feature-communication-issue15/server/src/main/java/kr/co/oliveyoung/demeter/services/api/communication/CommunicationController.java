package kr.co.oliveyoung.demeter.services.api.communication;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("api/communication")
public class CommunicationController {

}
