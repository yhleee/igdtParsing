package kr.co.oliveyoung.demeter.services.api.settle.service;

import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.services.api.settle.param.TeamProjectDTO;
import kr.co.oliveyoung.demeter.services.api.settle.param.TeamProjectListParam;
import kr.co.oliveyoung.demeter.utils.DRMUtil;
import kr.co.oliveyoung.feature.settle.TeamProject;
import kr.co.oliveyoung.feature.settle.mapper.TeamProjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static kr.co.oliveyoung.demeter.common.constants.CommonConstant.DRM_FILE_PATH;

@Slf4j
@Service
@AllArgsConstructor
public class TeamProjectService {

    private final TeamProjectMapper teamProjectMapper;

    @Transactional(readOnly = true)
    public List<TeamProject> getTeamProjectList(int page, int size, TeamProjectListParam param) {
        Integer offset = (page - 1) * size;
        return teamProjectMapper.selectTeamProjectList(size, offset, param);
    }

    @Transactional(readOnly = true)
    public TeamProject selectTeamProjectDetail(Integer teamProjectNo) {
        return teamProjectMapper.selectTeamProjectDetail(teamProjectNo);
    }

    @Transactional(readOnly = true)
    public Integer getTeamProjectActiveTypeYnCnt(String teamProjectActiveType) {
        return teamProjectMapper.selectTeamProjectActiveTypeYnCnt(teamProjectActiveType);
    }

    @Transactional
    public void insertTeamProject(TeamProjectDTO teamProjectDTO, AccessTokenVO tokenVO) {
        TeamProject teamProject = TeamProject.builder()
                .teamProjectSettleType(teamProjectDTO.getTeamProjectSettleType())
                .teamProjectType(teamProjectDTO.getTeamProjectType())
                .teamProjectDepartment(teamProjectDTO.getTeamProjectDepartment())
                .teamProjectDealCheck(teamProjectDTO.getTeamProjectDealCheck())
                .teamProjectDocumentNumber(teamProjectDTO.getTeamProjectDocumentNumber())
                .teamProjectDocumentTitle(teamProjectDTO.getTeamProjectDocumentTitle())
                .teamProjectPrice(teamProjectDTO.getTeamProjectPrice())
                .teamProjectCostCenter(teamProjectDTO.getTeamProjectCostCenter())
                .teamProjectActiveType("N")
                .teamProjectRegUser(tokenVO.getLoginId())
                .build();

        teamProjectMapper.insertTeamProject(teamProject);
    }

    @Transactional
    public void updateTeamProject(Integer teamProjectNo, TeamProjectDTO teamProjectDTO, AccessTokenVO tokenVO) {
        TeamProject teamProject = TeamProject.builder()
                .teamProjectNo(teamProjectNo)
                .teamProjectSettleType(teamProjectDTO.getTeamProjectSettleType())
                .teamProjectType(teamProjectDTO.getTeamProjectType())
                .teamProjectDepartment(teamProjectDTO.getTeamProjectDepartment())
                .teamProjectDealCheck(teamProjectDTO.getTeamProjectDealCheck())
                .teamProjectDocumentNumber(teamProjectDTO.getTeamProjectDocumentNumber())
                .teamProjectDocumentTitle(teamProjectDTO.getTeamProjectDocumentTitle())
                .teamProjectPrice(teamProjectDTO.getTeamProjectPrice())
                .teamProjectCostCenter(teamProjectDTO.getTeamProjectCostCenter())
                .teamProjectWBSCode(teamProjectDTO.getTeamProjectWBSCode())
                .teamProjectRegUser(tokenVO.getLoginId())
                .build();
        teamProjectMapper.updateTeamProject(teamProject);
    }

    @Transactional
    public void deleteTeamProject(Integer teamProjectNo) {
        teamProjectMapper.deleteTeamProject(teamProjectNo);
    }

    @Transactional
    public void updateTeamProjectActiveType(String teamProjectActiveType, String teamProjectRegYearMonth) {
        teamProjectMapper.updateTeamProjectActiveType(teamProjectActiveType, teamProjectRegYearMonth);
    }

    @Transactional
    public Map<String, String> setExcelParseTeamProject(MultipartFile uploadFile, AccessTokenVO tokenVO) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            // Excel
            Workbook workbook = new HSSFWorkbook(uploadFile.getInputStream());

            // 업로드할 매장 리스트
            StringBuilder costCenterStr = new StringBuilder();
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 1) {
                    continue;
                }

                if (row.getCell(0) == null) {
                    break;
                }

                costCenterStr.append(row.getCell(10));
                costCenterStr.append(",");

                // 입력값 체크
                for (int i=1; i < 9; i++) {
                    if (StringUtils.isEmpty(row.getCell(i).toString())) {
                        retMap.put("result", "FAIL");
                        retMap.put("msg", "비어있는 값이 존재합니다.");
                        return retMap;
                    }
                }

                // 정산구분이 비용인 경우에는 WBS CODE 입력이 불가능하다.
                if ( row.getCell(1).toString().equals("비용") && StringUtils.isNotEmpty(row.getCell(9).toString()) ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "정산구분이 투자인 경우에만 WBS CODE 입력이 가능합니다.");
                    return retMap;
                }

                // 확정된 값이 하나라도 있을 때
                if ( row.getCell(10).toString().equals("Y") ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "확정된 데이터가 존재합니다. 다시 확인하여 주시길 바랍니다.");
                    return retMap;
                }

                TeamProject teamProject = TeamProject.builder()
                    .teamProjectNo((int) Double.parseDouble(row.getCell(0).toString()))
                    .teamProjectSettleType(row.getCell(1).toString().equals("투자") ? 1 : 2)
                    .teamProjectType(row.getCell(2).toString().equals("프로젝트") ? 1 : 2)
                    .teamProjectDepartment(row.getCell(3).toString())
                    .teamProjectDealCheck(row.getCell(4).toString())
                    .teamProjectDocumentNumber(row.getCell(5).toString())
                    .teamProjectDocumentTitle(row.getCell(6).toString())
                    .teamProjectPrice((int) Double.parseDouble(row.getCell(7).toString()))
                    .teamProjectCostCenter(row.getCell(8).toString())
                    .teamProjectWBSCode(row.getCell(9).toString())
                    .teamProjectActiveType(row.getCell(10).toString())
                    .teamProjectRegUser(tokenVO.getLoginId())
                    .build();
                teamProjectMapper.upsertTeamProject(teamProject);
            }
        } catch (Exception e) {
            log.info("setExcelParseTeamProject ERROR !!", e);
        }

        return retMap;
    }

    @Transactional
    public Map<String, String> setDrmExcelParseTeamProject(MultipartFile uploadFile, AccessTokenVO tokenVO) {
        Map<String, String> retMap = new HashMap<>();
        retMap.put("result", "SUCCESS");
        retMap.put("msg", "업로드가 완료되었습니다.");

        try {
            InputStream upLoadExcelFile = null;

            String[] uploadFileSplitArray = uploadFile.getOriginalFilename().split("\\.");
            String decodeFileName = uploadFileSplitArray[0]
                    + "_dec_"
                    + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())
                    + "."
                    + uploadFileSplitArray[1];

            if (DRMUtil.drmFileCheck(uploadFile)) {
                DRMUtil.drmFileDecode(uploadFile, decodeFileName);
                Thread.sleep(3000);
                upLoadExcelFile = new FileInputStream(System.getProperty("user.dir") + DRM_FILE_PATH + decodeFileName);
            } else {
                // DRM 파일이 아닐 때
                upLoadExcelFile = uploadFile.getInputStream();
            }

            // Excel
            Workbook workbook = new HSSFWorkbook(upLoadExcelFile);

            // 업로드할 매장 리스트
            StringBuilder costCenterStr = new StringBuilder();
            for (Row row: workbook.getSheetAt(0)) {
                if (row.getRowNum() < 1) {
                    continue;
                }

                if (row.getCell(0) == null) {
                    break;
                }

                costCenterStr.append(row.getCell(10));
                costCenterStr.append(",");

                // 입력값 체크
                for (int i=1; i < 9; i++) {
                    if (StringUtils.isEmpty(row.getCell(i).toString())) {
                        retMap.put("result", "FAIL");
                        retMap.put("msg", "비어있는 값이 존재합니다.");
                        return retMap;
                    }
                }

                // 정산구분이 비용인 경우에는 WBS CODE 입력이 불가능하다.
                if ( row.getCell(1).toString().equals("비용") && StringUtils.isNotEmpty(row.getCell(9).toString()) ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "정산구분이 투자인 경우에만 WBS CODE 입력이 가능합니다.");
                    return retMap;
                }

                // 확정된 값이 하나라도 있을 때
                if ( row.getCell(10).toString().equals("Y") ) {
                    retMap.put("result", "FAIL");
                    retMap.put("msg", "확정된 데이터가 존재합니다. 다시 확인하여 주시길 바랍니다.");
                    return retMap;
                }

                TeamProject teamProject = TeamProject.builder()
                        .teamProjectNo((int) Double.parseDouble(row.getCell(0).toString()))
                        .teamProjectSettleType(row.getCell(1).toString().equals("투자") ? 1 : 2)
                        .teamProjectType(row.getCell(2).toString().equals("프로젝트") ? 1 : 2)
                        .teamProjectDepartment(row.getCell(3).toString())
                        .teamProjectDealCheck(row.getCell(4).toString())
                        .teamProjectDocumentNumber(row.getCell(5).toString())
                        .teamProjectDocumentTitle(row.getCell(6).toString())
                        .teamProjectPrice((int) Double.parseDouble(row.getCell(7).toString()))
                        .teamProjectCostCenter(row.getCell(8).toString())
                        .teamProjectWBSCode(row.getCell(9).toString())
                        .teamProjectActiveType(row.getCell(10).toString())
                        .teamProjectRegUser(tokenVO.getLoginId())
                        .build();
                teamProjectMapper.upsertTeamProject(teamProject);
            }
        } catch (Exception e) {
            log.info("setDrmExcelParseTeamProject ERROR !!", e);
        }

        return retMap;
    }

}
