package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "skin_path",
    "skin_sha1sum"
})
@Data
public class PcSkin {
    @JsonProperty("skin_path")
    private String skinPath;
    @JsonProperty("skin_sha1sum")
    private String skinSha1sum;
}
