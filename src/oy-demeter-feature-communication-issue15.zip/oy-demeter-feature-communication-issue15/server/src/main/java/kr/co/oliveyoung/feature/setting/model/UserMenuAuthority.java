package kr.co.oliveyoung.feature.setting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserMenuAuthority {
    private Integer menuNo;
    private String menuName;
    private String iconName;
    private Integer sortSeq;
    private Integer level;
    private Integer upperMenuNo;
    private String url;
    private boolean usable;
}
