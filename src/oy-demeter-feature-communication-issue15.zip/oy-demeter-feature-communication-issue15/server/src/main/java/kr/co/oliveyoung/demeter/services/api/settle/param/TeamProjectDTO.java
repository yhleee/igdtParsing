package kr.co.oliveyoung.demeter.services.api.settle.param;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class TeamProjectDTO {

    private Integer teamProjectType;
    private Integer teamProjectSettleType;
    private String teamProjectDepartment;
    private String teamProjectDealCheck;
    private String teamProjectDocumentNumber;
    private String teamProjectDocumentTitle;
    private Integer teamProjectPrice;
    private String teamProjectCostCenter;
    private String teamProjectWBSCode;

    // insert
    public TeamProjectDTO(
        Integer teamProjectType,
        Integer teamProjectSettleType,
        String teamProjectDepartment,
        String teamProjectDealCheck,
        String teamProjectDocumentNumber,
        String teamProjectDocumentTitle,
        Integer teamProjectPrice,
        String teamProjectCostCenter
    ) {
        this.teamProjectType = teamProjectType;
        this.teamProjectSettleType = teamProjectSettleType;
        this.teamProjectDepartment = teamProjectDepartment;
        this.teamProjectDealCheck = teamProjectDealCheck;
        this.teamProjectDocumentNumber = teamProjectDocumentNumber;
        this.teamProjectDocumentTitle = teamProjectDocumentTitle;
        this.teamProjectPrice = teamProjectPrice;
        this.teamProjectCostCenter = teamProjectCostCenter;
    }

    // update
    public TeamProjectDTO(
        Integer teamProjectType,
        Integer teamProjectSettleType,
        String teamProjectDepartment,
        String teamProjectDealCheck,
        String teamProjectDocumentNumber,
        String teamProjectDocumentTitle,
        Integer teamProjectPrice,
        String teamProjectCostCenter,
        String teamProjectWBSCode
    ) {
        this.teamProjectType = teamProjectType;
        this.teamProjectSettleType = teamProjectSettleType;
        this.teamProjectDepartment = teamProjectDepartment;
        this.teamProjectDealCheck = teamProjectDealCheck;
        this.teamProjectDocumentNumber = teamProjectDocumentNumber;
        this.teamProjectDocumentTitle = teamProjectDocumentTitle;
        this.teamProjectPrice = teamProjectPrice;
        this.teamProjectCostCenter = teamProjectCostCenter;
        this.teamProjectWBSCode = teamProjectWBSCode;
    }

}
