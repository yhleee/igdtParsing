package kr.co.oliveyoung.demeter.common.csv;

import kr.co.oliveyoung.demeter.common.csv.download.FileDownloader;
import kr.co.oliveyoung.demeter.common.csv.upload.FileDBInsertParser;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public abstract class FileFactoryAbstract {
    public abstract FileDBInsertParser fileDBInsert(String type, MultipartFile uploadFile);
    public abstract FileDownloader fileDownloader(String type, HttpServletResponse response)
        throws IOException;
}
