package kr.co.oliveyoung.demeter.services.api.settle;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.settle.param.HqInvestStoreDTO;
import kr.co.oliveyoung.demeter.services.api.settle.param.HqInvestStoreListParam;
import kr.co.oliveyoung.demeter.services.api.settle.service.HqInvestStoreService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("api/settle")
public class HqInvestStoreController {

    private final HqInvestStoreService hqInvestStoreService;

    @ApiOperation("본사 정산 담당자 투자(매장) 월별 정산 리스트 조회")
    @GetMapping("hqInvestStores")
    public ApiResponseMessage getInvestStoreList(
        @ApiParam(value = "page 번호를 설정할 수 있으며 설정 값은 1-N까지 입니다.", name = "page", defaultValue = "1", required = true) @RequestParam int page,
        @ApiParam(value = "페이지 별 레코드 갯수를 설정 할 수 있습니다.", name = "size", defaultValue = "10", required = true) @RequestParam int size,
        HqInvestStoreListParam param
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setParams(param);
        result.setContents(hqInvestStoreService.getHqInvestStoreList(page, size, param));
        return result;
    }

    @ApiOperation("본사 정산 담당자 투자(매장) 월별 정산 자산 리스트 조회")
    @GetMapping("hqInvestStore/{investStoreNo}/assets")
    public ApiResponseMessage getInvestStoreAssetList(
        @RequestParam String investStoreName,
        @RequestParam Integer investStoreType,
        @PathVariable("investStoreNo") Integer investStoreNo
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(hqInvestStoreService.getHqInvestStoreAssetList(investStoreName, investStoreType, investStoreNo));
        return result;
    }

    @ApiOperation("본사 정산 담당자 투자(매장) 월별 정산 등록")
    @PostMapping("hqInvestStore")
    public ApiResponseMessage setInvestStore(
        @RequestBody HqInvestStoreDTO hqInvestStoreDTO,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "등록이 완료되었습니다.", null);
        hqInvestStoreService.setHqInvestStore(hqInvestStoreDTO, tokenVO);
        return result;
    }

    @ApiOperation("본사 정산 담당자 투자(매장) 월별 정산 수정")
    @PutMapping("hqInvestStore/{investStoreNo}")
    public ApiResponseMessage putHqInvestStore(
        @PathVariable("investStoreNo") Integer investStoreNo,
        @RequestBody HqInvestStoreDTO hqInvestStoreDTO,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "수정이 완료되었습니다.", null);
        hqInvestStoreService.putHqInvestStore(investStoreNo, hqInvestStoreDTO, tokenVO);
        return result;
    }

    @ApiOperation("본사 정산 담당자 투자(매장) 월별 정산 삭제")
    @DeleteMapping("hqInvestStore/{investStoreNo}")
    public ApiResponseMessage delHqInvestStore(
        @PathVariable("investStoreNo") Integer investStoreNo
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "삭제가 완료되었습니다.", null);
        hqInvestStoreService.delHqInvestStore(investStoreNo);
        return result;
    }

}
