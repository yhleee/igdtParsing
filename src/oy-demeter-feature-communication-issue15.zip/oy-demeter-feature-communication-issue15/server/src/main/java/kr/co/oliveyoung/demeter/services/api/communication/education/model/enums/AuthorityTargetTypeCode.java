package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum AuthorityTargetTypeCode {
    BOARD("BOARD", "게시판"),
    POST("POST", "게시물"),
    MENU("MENU", "메뉴태그");

    private String code;
    private String text;

    AuthorityTargetTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
