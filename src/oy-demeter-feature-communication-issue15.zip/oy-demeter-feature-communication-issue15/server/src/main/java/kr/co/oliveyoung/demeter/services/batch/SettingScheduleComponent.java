package kr.co.oliveyoung.demeter.services.batch;

import kr.co.oliveyoung.demeter.services.api.setting.service.ScheduleService;
import kr.co.oliveyoung.feature.setting.model.ScheduleFireWall;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@AllArgsConstructor
public class SettingScheduleComponent {

    private final ScheduleService scheduleService;

    // @Scheduled(cron = "0 0 2 * * *") 2시
    // @Scheduled(cron = "*/1 * * * * *") 1초
    public void batchScheduleFireWall() {
        // scheduleService.noticeFireWallSchedule();
    }

}
