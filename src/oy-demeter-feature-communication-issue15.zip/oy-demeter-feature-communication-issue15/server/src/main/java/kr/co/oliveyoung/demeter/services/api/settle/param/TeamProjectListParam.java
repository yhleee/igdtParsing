package kr.co.oliveyoung.demeter.services.api.settle.param;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeamProjectListParam {

    private Integer teamProjectSettleType;
    private Integer teamProjectType;
    private String teamProjectRegUser;
    private String teamProjectRegYearMonth;

}
