package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "code_kind",
    "font_size",
    "font_color",
    "show_time",
    "hide_time",
    "alpha",
    "enable_html5_player"
})
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VideoWatermarkingCodePolicy {
    @JsonProperty("code_kind")
    private String codeKind;
    @JsonProperty("font_size")
    private Integer fontSize;
    @JsonProperty("font_color")
    private String fontColor;
    @JsonProperty("show_time")
    private Integer showTime;
    @JsonProperty("hide_time")
    private Integer hideTime;
    @JsonProperty("alpha")
    private Integer alpha;
    @JsonProperty("enable_html5_player")
    private Boolean enableHtml5Player;
}
