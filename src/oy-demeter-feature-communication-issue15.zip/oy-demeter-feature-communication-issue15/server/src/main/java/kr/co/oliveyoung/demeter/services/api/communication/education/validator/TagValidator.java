package kr.co.oliveyoung.demeter.services.api.communication.education.validator;

import java.util.List;
import java.util.Objects;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.TagTypeCode;
import lombok.AllArgsConstructor;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Configuration
@AllArgsConstructor
public class TagValidator implements Validator {

    private final int maxUserTagSize = 150; // 150자

    @Override
    public boolean supports(Class<?> clazz) {
        return TagVO.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        if(Objects.isNull(target)) {
            return;
        }

        if (!supports(target.getClass())) {
            throw new IllegalArgumentException(
                "Validator [" + this.getClass() + "] does not support [" + target.getClass() + "]");
        }

        if(Objects.isNull(target)) {
            return;
        }

        TagVO tagVO = (TagVO) target;

        // 태그유형 코드 체크
        if(Objects.isNull(tagVO.getTagTypeCode())) {
            errors.reject("communication.eduction.empty", new Object[]{"태그유형코드"}, null);
            return;
        }

        // 사용자태그는 최대 150자리까지 입력 가능
        if (tagVO.getTagTypeCode() == TagTypeCode.USER && tagVO.getTagName().length() > maxUserTagSize) {
            errors.reject("communication.eduction.tag.max.size", new Object[]{maxUserTagSize}, null);
            return;
        }
    }

    public void validateUserTagSize(List<String> userTags, Errors errors) {
        for(String userTag: userTags) {
            if(StringUtils.isNotBlank(userTag) && userTag.length() > maxUserTagSize) {
                errors.reject("communication.eduction.tag.max.size", new Object[]{maxUserTagSize, userTag}, null);
                return;
            }
        }
    }

    public void validate(List<TagVO> tags, Errors errors) {
        ListUtils.emptyIfNull(tags).stream().forEach(tag -> {
            validate(tag, errors);
        });
    }
}
