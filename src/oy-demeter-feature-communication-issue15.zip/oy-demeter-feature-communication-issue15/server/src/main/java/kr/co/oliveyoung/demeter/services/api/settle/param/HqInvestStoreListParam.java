package kr.co.oliveyoung.demeter.services.api.settle.param;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HqInvestStoreListParam {

    private String investStoreOpenYearMonth;

}
