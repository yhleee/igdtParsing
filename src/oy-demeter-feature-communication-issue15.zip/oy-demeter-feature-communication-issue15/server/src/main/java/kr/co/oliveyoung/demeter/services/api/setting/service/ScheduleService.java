package kr.co.oliveyoung.demeter.services.api.setting.service;

import kr.co.oliveyoung.demeter.common.enums.ScheduleType;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.services.api.setting.param.ScheduleFireWallDTO;
import kr.co.oliveyoung.feature.setting.ScheduleMapper;
import kr.co.oliveyoung.feature.setting.model.ScheduleFireWall;
import lombok.AllArgsConstructor;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class ScheduleService {

    private final ScheduleMapper scheduleMapper;

    public List<ScheduleFireWall> getScheduleFireWallList() {
        return scheduleMapper.selectScheduleList(ScheduleType.FIREWALL.getScheduleType());
    }

    @Transactional
    public void setScheduleFireWall(ScheduleFireWallDTO scheduleFireWallDTO, AccessTokenVO tokenVO) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("sourceIp", scheduleFireWallDTO.getSourceIp());
        jsonObject.put("destinationIp", scheduleFireWallDTO.getDestinationIp());
        jsonObject.put("port", scheduleFireWallDTO.getPort());

        ScheduleFireWall scheduleFireWall = ScheduleFireWall.builder()
            .scheduleType(ScheduleType.FIREWALL.getScheduleType())
            .scheduleSystemName(scheduleFireWallDTO.getScheduleSystemName())
            .schedulePurpose(scheduleFireWallDTO.getSchedulePurpose())
            .scheduleJsonContents(jsonObject.toString())
            .useYn("N")
            .policyStartDate(scheduleFireWallDTO.getPolicyStartDate())
            .policyEndDate(scheduleFireWallDTO.getPolicyEndDate())
            .policyNoticeDate(scheduleFireWallDTO.getPolicyNoticeDate())
            .sysRegrId(tokenVO.getLoginId())
            .sysRegDtime(LocalDateTime.now())
            .sysModrId(tokenVO.getLoginId())
            .sysModDtime(LocalDateTime.now())
            .build();
        scheduleMapper.insertFireWallSchedule(scheduleFireWall);
    }

    @Transactional(readOnly = true)
    public void noticeFireWallSchedule() {
        List<ScheduleFireWall> scheduleList = scheduleMapper.selectBatchScheduleList(ScheduleType.FIREWALL.getScheduleType(), LocalDate.now());
        for (ScheduleFireWall scheduleFireWall: scheduleList) {

        }
    }

}
