package kr.co.oliveyoung.demeter.aspect.example;

import kr.co.oliveyoung.demeter.services.api.log.ExampleLogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(Ordered.LOWEST_PRECEDENCE)
@Slf4j
@AllArgsConstructor
public class ExampleAspect {

    private ExampleLogService exampleLogService;

    // @AfterReturning(pointcut = "execution(* kr.co.oliveyoung.oms.services.api.example.ExampleService.*(..) && args(example))", returning = "result")
    /*
    @AfterReturning(pointcut = "execution(* kr.co.oliveyoung.oms.services.api.example.ExampleService.*(..))", returning = "result")
    public void doSomethingAfterReturning(JoinPoint joinPoint, Object result) {
        Signature signature = joinPoint.getSignature();
        Object target = joinPoint.getTarget();
        Object[] args = joinPoint.getArgs();

        System.out.println("Signature : " + signature.toString());
        System.out.println("target : " + target.toString());
        System.out.println("name : " + signature.getName());
        System.out.println("longName : " + signature.toLongString());
        System.out.println("shortName : " + signature.toShortString());

        for(int i=0; i < args.length; i++){
            System.out.println("args[" + i + "] : " + args[i].toString());
        }
        String methodName = joinPoint.getSignature().getName();
        if (methodName.equals("insertExample") || methodName.equals("updateExample") || methodName.equals("deleteExample")) {
            exampleLogService.insertExampleLog(result, joinPoint);
        }

    }
     */

//    @AfterThrowing(pointcut = "execution(* kr.co.oliveyoung.oms.services.api.example.ExampleService.*(..))", throwing = "exception")
//    public void afterThrowingMethod(JoinPoint joinPoint, Exception exception) throws Exception {
//        log.info("afterThrowingMethod() called: " + exception.getMessage());
//    }

}
