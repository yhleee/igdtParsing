package kr.co.oliveyoung.demeter.services.api.querybrowser;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.feature.querybrowser.QueryBrowserMapper;
import kr.co.oliveyoung.feature.querybrowser.QueryBrowserModel;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.web.bind.annotation.*;

import java.io.FileOutputStream;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("api/querybrowser")
public class QueryBrowserController {

    private QueryBrowserMapper queryBrowserMapper;

    @ApiOperation("Query Browser for Select")
    @GetMapping("/select")
    public ApiResponseMessage select(String query) {
        try {
            query = URLDecoder.decode(query, "UTF-8");
        } catch (Exception e) {}
        QueryBrowserModel queryParams = new QueryBrowserModel();
        queryParams.setQuery(query);
        List<Map<String, Object>> result = queryBrowserMapper.select(queryParams);
        ApiResponseMessage message = new ApiResponseMessage();
        message.setResult(ResponseResult.SUCCESS);
        message.setContents(result);
        return message;
    }
}
