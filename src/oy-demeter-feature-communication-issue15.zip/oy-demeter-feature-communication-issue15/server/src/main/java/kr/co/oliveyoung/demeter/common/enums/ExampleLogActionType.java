package kr.co.oliveyoung.demeter.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * DESC
 * INSERT(I): 등록
 * UPDATE(U): 수정
 * DELETE(D): 삭제
 */
@Getter
@AllArgsConstructor
public enum ExampleLogActionType {
    INSERT("I"),
    UPDATE("U"),
    DELETE("D");

    private String actionType;
}
