package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AuthorityTargetTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AuthorityTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.ServiceAreaTypeCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberGroupAuthorityVO extends BaseVO{
    @JsonProperty("authorityNo")
    private Long memberGroupAuthorityNo;
    private Long memberGroupNo;
    private ServiceAreaTypeCode areaTypeCode;
    private AuthorityTargetTypeCode targetTypeCode;
    private Long targetNo;
    private AuthorityTypeCode authorityTypeCode;
    private MemberGroupVO memberGroup;
}
