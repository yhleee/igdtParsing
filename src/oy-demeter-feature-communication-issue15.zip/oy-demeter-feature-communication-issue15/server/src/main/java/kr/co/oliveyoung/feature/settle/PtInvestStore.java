package kr.co.oliveyoung.feature.settle;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
public class PtInvestStore {
    private Integer investStoreNo;
    private String investStoreName;
    private Integer investStoreType;
    private Integer investStoreCategoryNo;
    private Integer investStoreAssetNo;
    private Integer investStoreCount;
    private Integer investStorePrice;
    private String investStoreRemarks;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysRegDtime;

    private String sysRegrId;

    @Builder
    public PtInvestStore(
        Integer investStoreNo,
        String investStoreName,
        Integer investStoreType,
        Integer investStoreCategoryNo,
        Integer investStoreAssetNo,
        Integer investStoreCount,
        Integer investStorePrice,
        String investStoreRemarks,
        LocalDateTime sysRegDtime,
        String sysRegrId
    ) {
        this.investStoreNo = investStoreNo;
        this.investStoreName = investStoreName;
        this.investStoreType = investStoreType;
        this.investStoreCategoryNo = investStoreCategoryNo;
        this.investStoreAssetNo = investStoreAssetNo;
        this.investStoreCount = investStoreCount;
        this.investStorePrice = investStorePrice;
        this.investStoreRemarks = investStoreRemarks;
        this.sysRegDtime = sysRegDtime;
        this.sysRegrId = sysRegrId;
    }

}
