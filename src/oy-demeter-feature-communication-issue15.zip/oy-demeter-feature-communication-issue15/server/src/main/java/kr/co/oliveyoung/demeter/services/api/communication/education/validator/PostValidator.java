package kr.co.oliveyoung.demeter.services.api.communication.education.validator;

import java.util.Objects;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.PostVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.ActionTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AttachFileTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.TagTypeCode;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Configuration
@AllArgsConstructor
public class PostValidator implements Validator {

    private final int maxImageCount = 10;
    private final int maxUserTagCount = 50; //50개

    @Override
    public boolean supports(Class<?> clazz) {
        return PostVO.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        if (Objects.isNull(target)) {
            return;
        }

        if (!supports(target.getClass())) {
            throw new IllegalArgumentException(
                "Validator [" + this.getClass() + "] does not support [" + target.getClass() + "]");
        }

        PostVO post = (PostVO) target;

        // 제목 본문은 필수값
        if (StringUtils.isBlank(post.getTitle())) {
            errors.reject("communication.eduction.empty", new Object[]{"제목"}, null);
            return;
        }

        if (StringUtils.isBlank(post.getContents())) {
            errors.reject("communication.eduction.empty", new Object[]{"본문"}, null);
            return;
        }

        if (StringUtils.isBlank(post.getNoticeYn())) {
            errors.reject("communication.eduction.empty", new Object[]{"공지여부"}, null);
            return;
        }

        if (StringUtils.isBlank(post.getUseYn())) {
            errors.reject("communication.eduction.empty", new Object[]{"사용여부"}, null);
            return;
        }

        // 사용자 입력 태그 수 제한
        if (Objects.nonNull(post.getTags())) {
            if (post.getTags().stream().filter(tagVO -> tagVO.getTagTypeCode() == TagTypeCode.USER)
                .count() > maxUserTagCount) {
                errors.reject("communication.eduction.tag.max.count", new Object[]{maxUserTagCount},
                    null);
                return;
            }
        }

        if (post.getActionTypeCode() == ActionTypeCode.CREATE) {
            validateCreate(post, errors);
        } else if (post.getActionTypeCode() == ActionTypeCode.UPDATE) {
            validateUpdate(post, errors);
        }
    }

    private void validateCreate(PostVO post, Errors errors) {
        // 이미지는 최대 10개까지 등록 가능
        if (Objects.nonNull(post.getImages()) && post.getImages().size() > maxImageCount) {
            errors.reject("communication.eduction.post.image.count", new Object[]{maxImageCount},
                null);
            return;
        }

        // 배너 이미지 필수 등록
        if (Objects.isNull(post.getBanner())) {
            errors.reject("communication.eduction.empty", new Object[]{"배너이미지"}, null);
            return;
        }
    }

    private void validateUpdate(PostVO post, Errors errors) {
        if (Objects.nonNull(post.getAttachments()) && Objects.isNull(post.getAttachGroupNo())) {
            errors.reject("communication.eduction.empty", new Object[]{"첨부파일그룹번호"}, null);
            return;
        }

        // 배너는 필수
        if (Objects.isNull(post.getAttachments()) || post.getAttachments().stream()
            .filter(attachmentVO -> attachmentVO.getFileTypeCode() == AttachFileTypeCode.BANNER)
            .count() == 0) {
            errors.reject("communication.eduction.empty", new Object[]{"배너이미지"}, null);
            return;
        }

        // 이미지는 최대 10개까지 등록 가능
        if (Objects.isNull(post.getAttachments()) || post.getAttachments().stream()
            .filter(attachmentVO -> attachmentVO.getFileTypeCode() == AttachFileTypeCode.IMAGE)
            .count() > maxImageCount) {
            errors.reject("communication.eduction.post.image.count", new Object[]{maxImageCount},
                null);
            return;
        }
    }
}
