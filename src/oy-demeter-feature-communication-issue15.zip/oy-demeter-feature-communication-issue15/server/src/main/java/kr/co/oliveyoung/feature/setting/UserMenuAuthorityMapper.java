package kr.co.oliveyoung.feature.setting;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.setting.model.UserMenuAuthority;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import kr.co.oliveyoung.feature.setting.model.UserMenu;
import java.util.List;
import java.util.Map;

@MySqlOyisMapper
public interface UserMenuAuthorityMapper {
    List<UserMenuAuthority> selectUserMenuAuthority(Map<String, Object> param);
    List<UserGroup> selectAuthorizedGroup(Integer... menuNo);
    List<UserGroup> selectUnauthorizedGroup(Integer... menuNo);
    int deleteUserMenuAuthority(Map<String, Object> param);
    int deleteUserMenuAuthorityByGroupNos(Integer... groupNos);
    int insertUserMenuAuthority(Map<String, Object> param);
    List<UserMenu> selectGroupMenuAuthority(Integer... groupNos);
}
