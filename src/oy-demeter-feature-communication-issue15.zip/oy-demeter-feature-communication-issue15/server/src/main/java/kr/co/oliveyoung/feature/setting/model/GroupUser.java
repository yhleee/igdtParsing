package kr.co.oliveyoung.feature.setting.model;

import com.google.common.collect.Lists;
import java.util.List;
import lombok.Data;

@Data
public class GroupUser {
    private int groupNo;
    private List<User> mappingUsers = Lists.newArrayList();
    private List<User> unmappingUsers = Lists.newArrayList();
}
