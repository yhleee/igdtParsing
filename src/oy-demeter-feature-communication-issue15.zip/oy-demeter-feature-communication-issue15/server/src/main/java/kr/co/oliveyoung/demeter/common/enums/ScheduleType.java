package kr.co.oliveyoung.demeter.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * DESC
 * FIREWALL(1): 방화벽
 */
@Getter
@AllArgsConstructor
public enum ScheduleType {
    FIREWALL("1");

    private String scheduleType;
}
