package kr.co.oliveyoung.feature.log;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
public class ExampleLog {

    private Integer seq;
    private String actionType;
    private String methodName;
    private Integer exampleId;
    private String exampleName;
    private Integer exampleAge;
    private String exampleTitle;
    private String exampleDescription;
    private String regUser;
    private LocalDateTime regDate;

    @Builder
    public ExampleLog(
        Integer seq,
        String actionType,
        String methodName,
        Integer exampleId,
        String exampleName,
        Integer exampleAge,
        String exampleTitle,
        String exampleDescription,
        String regUser,
        LocalDateTime regDate
    ) {
        this.seq = seq;
        this.actionType = actionType;
        this.methodName = methodName;
        this.exampleId = exampleId;
        this.exampleName = exampleName;
        this.exampleAge = exampleAge;
        this.exampleTitle = exampleTitle;
        this.exampleDescription = exampleDescription;
        this.regUser = regUser;
        this.regDate = regDate;
    }

}
