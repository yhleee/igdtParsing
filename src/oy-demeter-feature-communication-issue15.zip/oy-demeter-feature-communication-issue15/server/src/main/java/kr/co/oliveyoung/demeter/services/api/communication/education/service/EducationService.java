package kr.co.oliveyoung.demeter.services.api.communication.education.service;

import com.google.common.collect.Lists;
import io.jsonwebtoken.lang.Collections;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.validation.ValidationException;
import kr.co.oliveyoung.demeter.common.model.PageRequest;
import kr.co.oliveyoung.demeter.common.validator.ValidationUtil;
import kr.co.oliveyoung.demeter.services.api.communication.common.FileUploadService;
import kr.co.oliveyoung.demeter.services.api.communication.common.ModelConverter;
import kr.co.oliveyoung.demeter.services.api.communication.common.VideoService;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.AttachmentVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.MemberGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.PostVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AttachFileTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AuthorityTargetTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.ServiceAreaTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.validator.AttachmentValidator;
import kr.co.oliveyoung.demeter.services.api.communication.education.validator.PostValidator;
import kr.co.oliveyoung.demeter.services.api.communication.education.validator.TagValidator;
import kr.co.oliveyoung.feature.communication.education.EducationMapper;
import kr.co.oliveyoung.feature.communication.education.model.Attachment;
import kr.co.oliveyoung.feature.communication.education.model.AttachmentGroup;
import kr.co.oliveyoung.feature.communication.education.model.EduPost;
import kr.co.oliveyoung.feature.communication.education.model.EduTag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
@AllArgsConstructor
public class EducationService {

    private final FileUploadService fileUploadService;
    private final VideoService videoService;
    private final EducationMapper educationMapper;
    private final PostValidator postValidator;
    private final TagValidator tagValidator;
    private final AttachmentValidator attachmentValidator;

    @Transactional(transactionManager = "mySqlEducomTxManager")
    public void savePost(PostVO post, BindingResult errors)
        throws ValidationException, IOException {

        postValidator.validate(post, errors);
        if (errors.hasErrors()) {
            throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
        }

        /**
         * 첨부 이미지, 일반 파일을 업로드.
         */
        List<AttachmentVO> attachmentVOList = Lists.newArrayList();
        attachmentVOList.addAll(
            saveFiles(AttachmentVO.builder()
                    .fileTypeCode(AttachFileTypeCode.BANNER)
                    .order(attachmentVOList.size() + 1)
                    .creator(post.getCreator())
                    .updater(post.getUpdater())
                    .build(),
                post.getBanner()));
        attachmentVOList.addAll(
            saveFiles(AttachmentVO.builder()
                    .fileTypeCode(AttachFileTypeCode.THUMBNAIL)
                    .order(attachmentVOList.size() + 1)
                    .creator(post.getCreator())
                    .updater(post.getUpdater())
                    .build(),
                post.getThumbnail()));
        /**
         * 동영상 정보 추가
         */
        if (Objects.nonNull(post.getMediaKey())) {
            AttachmentVO movie = AttachmentVO.builder()
                .fileTypeCode(AttachFileTypeCode.MOVIE)
                .order(attachmentVOList.size() + 1)
                .mediaKey(post.getMediaKey())
                .creator(post.getCreator())
                .updater(post.getUpdater())
                .build();
            attachmentVOList.add(movie);
        }
        attachmentVOList
            .addAll(saveFiles(AttachmentVO.builder()
                    .fileTypeCode(AttachFileTypeCode.IMAGE)
                    .order(attachmentVOList.size() + 1)
                    .creator(post.getCreator())
                    .updater(post.getUpdater())
                    .build(),
                Optional.ofNullable(post.getImages())
                    .orElse(Lists.newArrayList()).toArray(new MultipartFile[0])));
        attachmentVOList.addAll(
            saveFiles(AttachmentVO.builder()
                    .fileTypeCode(AttachFileTypeCode.ETC)
                    .order(attachmentVOList.size() + 1)
                    .creator(post.getCreator())
                    .updater(post.getUpdater())
                    .build(),
                post.getAttachment()));

        // 첨부파일 유효성 체크
        for (AttachmentVO attachment : attachmentVOList) {
            attachmentValidator.validate(attachment, errors);
        }

        if (errors.hasErrors()) {
            fileUploadService.delete(
                attachmentVOList.stream().map(attachmentVO -> attachmentVO.getFileUrl())
                    .collect(Collectors.toList()));
            throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
        }

        // 첨부파일 db 등록
        AttachmentGroup attachmentGroup = AttachmentGroup.builder()
            .areaTypeCode(ServiceAreaTypeCode.EDUCATION.getCode())
            .creator(post.getCreator())
            .updater(post.getUpdater())
            .build();
        educationMapper.insertAttachmentGroup(attachmentGroup);
        post.setAttachGroupNo(attachmentGroup.getAttachGroupNo());

        attachmentVOList.stream().forEach(attachmentVO -> {
            attachmentVO.setAttachGroupNo(attachmentGroup.getAttachGroupNo());
            educationMapper
                .insertAttachment(ModelConverter.convertToAttachmentFrom(attachmentVO));
        });

        EduPost eduPost = ModelConverter.convertToEduPostFrom(post);
        educationMapper.insertPost(eduPost);
        post.setPostNo(eduPost.getPostNo());

        /**
         * 게시물 - 태그 매핑 추가
         */
        for (TagVO tag : post.getTags()) {
            educationMapper
                .insertPostTagMapping(post.getPostNo(), tag.getTagNo(), post.getCreator());
        }

        // 회원그룹매핑 추가
        ListUtils.defaultIfNull(post.getMemberGroupAuthorities(), Lists.newArrayList()).stream()
            .map(authorityVO -> {
                authorityVO.setAreaTypeCode(ServiceAreaTypeCode.EDUCATION);
                authorityVO.setTargetTypeCode(AuthorityTargetTypeCode.POST);
                authorityVO.setCreator(post.getCreator());
                authorityVO.setUpdater(post.getUpdater());
                authorityVO.setTargetNo(post.getPostNo());
                return ModelConverter.convertToMemberGroupAuthorityFrom(authorityVO);
            }).forEach(memberGroupAuthority -> educationMapper
            .insertMemberGroupAuthority(memberGroupAuthority));
    }

    @Transactional(transactionManager = "mySqlEducomTxManager")
    public void modifyPost(PostVO post, BindingResult errors) {
        postValidator.validate(post, errors);
        if (errors.hasErrors()) {
            throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
        }

        /**
         * 동영상 정보 추가
         */
        if (Objects.nonNull(post.getMediaKey())) {
            AttachmentVO movie = AttachmentVO.builder()
                .fileTypeCode(AttachFileTypeCode.MOVIE)
                .mediaKey(post.getMediaKey())
                .creator(post.getCreator())
                .updater(post.getUpdater())
                .build();
            post.addAttachment(movie);
        }

        if (!Collections.isEmpty(post.getAttachments())) {
            for (AttachmentVO attachment : post.getAttachments()) {
                attachmentValidator.validateUpdate(attachment, errors);
            }
            if (errors.hasErrors()) {
                throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
            }
            post.getAttachments().stream().forEach(attachmentVO -> {
                attachmentVO.setAttachGroupNo(post.getAttachGroupNo());
                attachmentVO.setUpdater(post.getUpdater());
                educationMapper
                    .updateAttachment(ModelConverter.convertToAttachmentFrom(attachmentVO));
            });
        }

        EduPost eduPost = ModelConverter.convertToEduPostFrom(post);
        educationMapper.updatePost(eduPost);

        /**
         * 게시물 - 태그 매핑 추가
         */
        educationMapper.deletePostTagMappings(post.getPostNo());
        for (TagVO tag : post.getTags()) {
            educationMapper
                .insertPostTagMapping(post.getPostNo(), tag.getTagNo(), post.getCreator());
        }

        // 회원권한그룹매핑추가
        educationMapper.deleteMemberGroupAuthority(new HashMap<>() {
            {
                put("areaTypeCode", ServiceAreaTypeCode.EDUCATION.getCode());
                put("targetTypeCode", AuthorityTargetTypeCode.POST.getCode());
                put("targetNo", post.getPostNo());
            }
        });
        ListUtils.defaultIfNull(post.getMemberGroupAuthorities(), Lists.newArrayList()).stream()
            .map(authorityVO -> {
                authorityVO.setAreaTypeCode(ServiceAreaTypeCode.EDUCATION);
                authorityVO.setTargetTypeCode(AuthorityTargetTypeCode.POST);
                authorityVO.setCreator(post.getCreator());
                authorityVO.setUpdater(post.getUpdater());
                authorityVO.setTargetNo(post.getPostNo());
                return ModelConverter.convertToMemberGroupAuthorityFrom(authorityVO);
            }).forEach(memberGroupAuthority -> educationMapper
            .insertMemberGroupAuthority(memberGroupAuthority));
    }

    @Transactional(transactionManager = "mySqlEducomTxManager")
    public List<TagVO> saveTags(List<TagVO> tags, Integer creator, BindingResult errors) {
        if (Collections.isEmpty(tags)) {
            return tags;
        }
        for (TagVO tag : tags) {
            tagValidator.validate(tag, errors);
        }
        if (errors.hasErrors()) {
            return tags;
        }
        List<EduTag> eduTags = tags.stream().map(tagVO -> {
            tagVO.setCreator(creator);
            tagVO.setUpdater(creator);
            return ModelConverter.convertToEduTagFrom(tagVO);
        }).collect(Collectors.toList());
        for (EduTag tag : eduTags) {
            educationMapper.insertTag(tag);
        }
        return eduTags.stream().map(eduTag -> ModelConverter.convertToTagVOFrom(eduTag)).collect(
            Collectors.toList());
    }

    @Transactional(transactionManager = "mySqlEducomTxManager")
    public List<AttachmentVO> uploadFiles(AttachmentVO param, List<MultipartFile> files,
        BindingResult errors)
        throws IOException, ValidationException {
        List<AttachmentVO> attachmentList = Lists.newArrayList();
        if (param.getFileTypeCode() == AttachFileTypeCode.MOVIE) {
            attachmentList.add(ModelConverter.deepCopy(param, AttachmentVO.class));
        } else {
            attachmentList.addAll(saveFiles(param, files.toArray(new MultipartFile[0])));
        }
        for (AttachmentVO vo : attachmentList) {
            attachmentValidator.validate(vo, errors);
        }
        if (errors.hasErrors()) {
            fileUploadService.delete(attachmentList.stream()
                .filter(vo -> AttachFileTypeCode.MANAGED_ATTACHMENT.contains(vo.getFileTypeCode()))
                .map(vo -> vo.getFilePath()).collect(
                    Collectors.toList()));
            throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
        }

        try {
            //그룹번호가 없을 경우 신규 등록
            if (Objects.isNull(param.getAttachGroupNo())) {
                AttachmentGroup group = ModelConverter.convertToAttachmentGroupFrom(param);
                group.setAreaTypeCode(ServiceAreaTypeCode.EDUCATION.getCode());
                educationMapper.insertAttachmentGroup(group);
                param.setAttachGroupNo(group.getAttachGroupNo());
            }

            attachmentList.stream().forEach(vo -> {
                vo.setAttachGroupNo(param.getAttachGroupNo());
                Attachment attachment = ModelConverter.convertToAttachmentFrom(vo);
                educationMapper
                    .insertAttachment(ModelConverter.convertToAttachmentFrom(vo));
                vo.setAttachNo(attachment.getAttachmentNo());
            });

            return attachmentList;
        } catch (Exception e) {
            fileUploadService.delete(attachmentList.stream()
                .filter(vo -> AttachFileTypeCode.MANAGED_ATTACHMENT.contains(vo.getFileTypeCode()))
                .map(vo -> vo.getFilePath()).collect(
                    Collectors.toList()));
            throw e;
        }
    }

    @Transactional(transactionManager = "mySqlEducomTxManager")
    public void deleteFiles(List<AttachmentVO> attachmentList) {
        List<AttachmentVO> attachments = educationMapper.selectAttachments(new HashMap<>() {
            {
                put("attachmentNos", attachmentList.stream().map(vo -> vo.getAttachNo())
                    .collect(Collectors.toList()));
            }
        });
        attachments.stream().forEach(attachmentVO -> {
            educationMapper
                .deleteAttachments(attachmentVO.getAttachGroupNo(), attachmentVO.getAttachNo());
        });
        fileUploadService.delete(
            attachments.stream()
                .filter(vo -> AttachFileTypeCode.MANAGED_ATTACHMENT.contains(vo.getFileTypeCode())
                    && StringUtils.isNotBlank(vo.getFilePath()))
                .map(attachmentVO -> attachmentVO.getFilePath())
                .collect(Collectors.toList()));
    }

    public List<PostVO> fetchPosts(String searchKeyword, String tagName, PageRequest pageRequest) {
        Map<String, Object> params = new HashMap<>() {
            {
                put("searchKeyword", searchKeyword);
                put("tagName", tagName);
                put("page", pageRequest);
            }
        };
        return educationMapper.selectPosts(params);
    }

    public int countPosts(String searchKeyword, String tagName) {
        Map<String, Object> params = new HashMap<>() {
            {
                put("searchKeyword", searchKeyword);
                put("tagName", tagName);
            }
        };
        return educationMapper.countPosts(params);
    }

    public PostVO fetchPost(Long postNo) {
        return educationMapper.selectPostById(postNo);
    }

    public List<TagVO> fetchTags(String tagName, Long tagGroupNo, String tagTypeCode, Long postNo,
        PageRequest pageRequest) {
        Map<String, Object> params = new HashMap<>() {
            {
                put("tagName", tagName);
                put("tagGroupNo", tagGroupNo);
                put("tagTypeCode", tagTypeCode);
                put("postNo", postNo);
                put("page", pageRequest);
            }
        };
        return educationMapper.selectTags(params);
    }

    public int countTags(String tagName, Long tagGroupNo, String tagTypeCode, Long postNo) {
        Map<String, Object> params = new HashMap<>() {
            {
                put("tagName", tagName);
                put("tagGroupNo", tagGroupNo);
                put("tagTypeCode", tagTypeCode);
                put("postNo", postNo);
            }
        };
        return educationMapper.countTags(params);
    }

    public List<TagGroupVO> fetchTagGroups(String tagGroupName, PageRequest pageRequest) {
        return educationMapper.selectTagGroups(tagGroupName, pageRequest);
    }

    public int countTagGroups(String tagGroupName) {
        return educationMapper.countTagGroups(tagGroupName);
    }

    public List<MemberGroupVO> fetchMemberGroups(String groupName, PageRequest pageRequest) {
        return educationMapper.selectMemberGroups(groupName, pageRequest);
    }

    public int countMemberGroups(String groupName) {
        return educationMapper.countMemberGroups(groupName);
    }

    private AttachmentVO saveFile(AttachmentVO param, MultipartFile multipartFile)
        throws IOException {
        if (Objects.isNull(multipartFile)) {
            return null;
        }
        AttachmentVO attachmentVO = ModelConverter.deepCopy(param, AttachmentVO.class);
        Pair</*filePath, fileUrl */String, String> savePath = fileUploadService.save(multipartFile);
        attachmentVO.setFileSize(multipartFile.getSize());
        attachmentVO.setFilePath(savePath.getLeft());
        attachmentVO.setFileUrl(param.getFileTypeCode().getBaseUrl() + savePath.getRight());
        return attachmentVO;
    }

    private List<AttachmentVO> saveFiles(AttachmentVO param, MultipartFile... multipartFiles)
        throws IOException {
        List<AttachmentVO> attachmentVOList = Lists.newArrayList();
        int order = Optional.ofNullable(param.getOrder()).orElse(1);
        for (MultipartFile multipartFile : multipartFiles) {
            if (Objects.isNull(multipartFile)) {
                continue;
            }
            param.setOrder(order++);
            attachmentVOList.add(saveFile(param, multipartFile));
        }
        return attachmentVOList;
    }
}
