package kr.co.oliveyoung.demeter.services.api.common;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/common")
public class CommonController {

    @GetMapping("healthCheck")
    public void getHealth() {
        // TODO: 서드파티관련 API 헬스체크 전용
    }

}
