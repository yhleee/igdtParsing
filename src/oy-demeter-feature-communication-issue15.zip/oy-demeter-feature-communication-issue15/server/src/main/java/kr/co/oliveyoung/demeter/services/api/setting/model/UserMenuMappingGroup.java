package kr.co.oliveyoung.demeter.services.api.setting.model;

import java.util.List;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserMenuMappingGroup {

    private Integer menuNo;
    private List<UserGroup> authorizedGroups;
    private List<UserGroup> unauthorizedGroups;
}
