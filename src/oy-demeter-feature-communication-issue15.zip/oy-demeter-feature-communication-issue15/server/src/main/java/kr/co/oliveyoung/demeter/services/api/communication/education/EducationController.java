package kr.co.oliveyoung.demeter.services.api.communication.education;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.annotations.ApiOperation;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;
import javax.validation.ValidationException;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.common.model.PageRequest;
import kr.co.oliveyoung.demeter.common.validator.ValidationUtil;
import kr.co.oliveyoung.demeter.services.api.communication.CommunicationController;
import kr.co.oliveyoung.demeter.services.api.communication.common.CommonConstants;
import kr.co.oliveyoung.demeter.services.api.communication.common.VideoService;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.AttachmentVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.MemberGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.PostVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.ActionTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AttachFileTypeCode;
import kr.co.oliveyoung.demeter.services.api.communication.education.service.EducationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/communication/edu")
public class EducationController extends CommunicationController {

    private final EducationService educationService;
    private final VideoService videoService;

    @ApiOperation("교육 컨텐츠 등록")
    @PostMapping(value = "/post", headers = {"content-type=multipart/mixed",
        "content-type=multipart/form-data"}
        , consumes = {"multipart/mixed"})
    public ApiResponseMessage createEduPost(@RequestPart PostVO post,
        @RequestPart(required = false) MultipartFile banner,
        @RequestPart(required = false) MultipartFile thumbnail,
        @RequestPart(required = false) List<MultipartFile> images,
        @RequestPart(required = false) MultipartFile attachment,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        BindingResult errors
    ) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            post.setActionTypeCode(ActionTypeCode.CREATE);
            post.setBanner(banner);
            post.setThumbnail(thumbnail);
            post.setImages(images);
            post.setAttachment(attachment);
            post.setCreator(tokenVO.getEduCommMemberNo());
            post.setUpdater(tokenVO.getEduCommMemberNo());

            educationService.savePost(post, errors);
            if (errors.hasErrors()) {
                throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
            }
            responseMessage.setLastCreatedNo(post.getPostNo());
        } catch (ValidationException e) {
            log.error("교육컨텐츠 등록 오류 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        } catch (Exception e) {
            log.error("교육컨텐츠 등록 오류 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage("교육 컨텐츠 등록 중 오류가 발생하였습니다.");
        }
        return responseMessage;
    }

    @ApiOperation("교육 컨텐츠 수정")
    @PutMapping(value = "/post")
    public ApiResponseMessage modifyEduPost(@RequestBody PostVO post,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        BindingResult errors
    ) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            post.setActionTypeCode(ActionTypeCode.UPDATE);
            post.setCreator(tokenVO.getEduCommMemberNo());
            post.setUpdater(tokenVO.getEduCommMemberNo());

            educationService.modifyPost(post, errors);
            if (errors.hasErrors()) {
                throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
            }
            responseMessage.setLastCreatedNo(post.getPostNo());
        } catch (ValidationException e) {
            log.error("교육컨텐츠 수정 오류 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        } catch (Exception e) {
            log.error("교육컨텐츠 수정 오류 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage("교육 컨텐츠 수정 중 오류가 발생하였습니다.");
        }
        return responseMessage;
    }

    /**
     * 교육 컨텐츠 상세
     */
    @GetMapping("/post")
    public ApiResponseMessage fetchEduPost(@RequestParam Long postNo,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            PostVO post = educationService.fetchPost(postNo);
            AttachmentVO attachmentVO = post.getAttachments().stream()
                .filter(vo -> vo.getFileTypeCode() == AttachFileTypeCode.MOVIE).findFirst()
                .orElse(null);
            if(Objects.nonNull(attachmentVO)) {
                setMovieUrl(attachmentVO, tokenVO.getLoginId());
            }
            responseMessage.setContents(post);
        } catch (Exception e) {
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        }
        return responseMessage;
    }

    /**
     * 교육컨텐츠 리스트 조회
     */
    @GetMapping("/post/list")
    public ApiResponseMessage fetchEduPostList(
        @RequestParam(value = "searchKeyword", required = false) String searchKeyword,
        @RequestParam(value = "tagName", required = false) String tagName,
        PageRequest pageRequest) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            responseMessage.setTotalCnt(educationService.countPosts(searchKeyword, tagName));
            responseMessage
                .setContents(educationService.fetchPosts(searchKeyword, tagName, pageRequest));
        } catch (Exception e) {
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        }
        return responseMessage;
    }

    @ApiOperation("첨부 파일 업로드")
    @PostMapping(value = "/file/upload", headers = {"content-type=multipart/mixed",
        "content-type=multipart/form-data"}
        , consumes = {"multipart/mixed"})
    public ApiResponseMessage uploadFile(@RequestPart AttachmentVO attachment,
        @RequestPart(required = false) List<MultipartFile> files,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO,
        BindingResult errors) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            attachment.setCreator(tokenVO.getEduCommMemberNo());
            attachment.setUpdater(tokenVO.getEduCommMemberNo());
            List<AttachmentVO> attachmentList = educationService
                .uploadFiles(attachment, files, errors);
            if (errors.hasErrors()) {
                throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
            }
            responseMessage.setContents(attachmentList);
        } catch (ValidationException e) {
            log.error("파일 업로드 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        } catch (Exception e) {
            log.error("파일 업로드 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage("파일 업로드 실패");
        }
        return responseMessage;
    }

    @ApiOperation("첨부 파일 삭제")
    @PostMapping(value = "/file/delete")
    public ApiResponseMessage deleteFile(@RequestBody List<AttachmentVO> attachments) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            educationService.deleteFiles(attachments);
        } catch (Exception e) {
            log.error("파일 삭제 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage("파일 삭제 실패");
        }
        return responseMessage;
    }

    @ApiOperation("태그 등록")
    @PostMapping("/tag")
    public ApiResponseMessage postEduContent(@RequestBody List<TagVO> tags,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO, BindingResult errors) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            List<TagVO> insertedTags = educationService
                .saveTags(tags, tokenVO.getEduCommMemberNo(), errors);
            if (errors.hasErrors()) {
                throw new ValidationException(ValidationUtil.getFirstErrorMessage(errors));
            }
            responseMessage.setContents(insertedTags);
        } catch (ValidationException e) {
            log.error("태그 등록 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        } catch (Exception e) {
            log.error("태그 등록 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage("태그 등록시 오류가 발생하였습니다.");
        }
        return responseMessage;
    }

    @ApiOperation("태그 조회")
    @GetMapping("/tag/list")
    public ApiResponseMessage fetchTags(
        @RequestParam(value = "tagName", required = false) String tagName,
        @RequestParam(value = "tagGroupNo", required = false) Long tagGroupNo,
        @RequestParam(value = "tagTypeCode", required = false) String tagTypeCode,
        @RequestParam(value = "postNo", required = false) Long postNo,
        PageRequest pageRequest,
        BindingResult errors
    ) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            int totalCount = educationService.countTags(tagName, tagGroupNo, tagTypeCode, postNo);
            pageRequest.setTotalCount(totalCount);
            List<TagVO> tags = educationService
                .fetchTags(tagName, tagGroupNo, tagTypeCode, postNo, pageRequest);

            responseMessage.setTotalCnt(totalCount);
            responseMessage.setContents(tags);
        } catch (Exception e) {
            log.error("태그 조회 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        }
        return responseMessage;
    }

    @ApiOperation("태그 그룹 조회")
    @GetMapping("/tagGroup/list")
    public ApiResponseMessage fetchTagGroups(
        @RequestParam(value = "tagGroupName", required = false) String tagGroupName,
        PageRequest pageRequest
    ) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            int totalCount = educationService.countTagGroups(tagGroupName);
            pageRequest.setTotalCount(totalCount);
            List<TagGroupVO> tags = educationService
                .fetchTagGroups(tagGroupName, pageRequest);

            responseMessage.setTotalCnt(totalCount);
            responseMessage.setContents(tags);
        } catch (Exception e) {
            log.error("태그 그룹 조회 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        }
        return responseMessage;
    }

    @ApiOperation("회원 그룹 조회")
    @GetMapping("/memberGroup/list")
    public ApiResponseMessage fetchMemberGroups(
        @RequestParam(value = "groupName", required = false) String groupName,
        PageRequest pageRequest
    ) {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        try {
            int totalCount = educationService.countMemberGroups(groupName);
            pageRequest.setTotalCount(totalCount);
            List<MemberGroupVO> memberGroups = educationService
                .fetchMemberGroups(groupName, pageRequest);
            responseMessage.setTotalCnt(totalCount);
            responseMessage.setContents(memberGroups);
        } catch (Exception e) {
            log.error("회원 그룹 조회 실패 {}", e);
            responseMessage.setResult(ResponseResult.FAIL);
            responseMessage.setMessage(e.getMessage());
        }
        return responseMessage;
    }

    @GetMapping("/token")
    public ApiResponseMessage token()
        throws NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException {
        ApiResponseMessage responseMessage = new ApiResponseMessage(ResponseResult.SUCCESS);
        responseMessage.setContents(videoService.token("testUser", "4qlxe61l"));
        return responseMessage;
    }

    private void setMovieUrl(AttachmentVO attachmentVO, String memberId)
        throws NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException {
        if (Objects.isNull(attachmentVO)) {
            return;
        }
        String token = videoService.token(memberId, attachmentVO.getMediaKey());
        attachmentVO.setFileUrl(String.format("%s?custom_key=%s&jwt=%s&player_version=html5",
            AttachFileTypeCode.MOVIE.getBaseUrl(), CommonConstants.VideoServiceUserApiKey, token));
    }
}
