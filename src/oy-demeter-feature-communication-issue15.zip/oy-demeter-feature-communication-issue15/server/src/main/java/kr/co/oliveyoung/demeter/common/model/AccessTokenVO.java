package kr.co.oliveyoung.demeter.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccessTokenVO {
    private Integer userNo;
    private String loginId;
    private String adminYn;
    private String lastLoginDatetime;
    private Integer eduCommMemberNo;
}
