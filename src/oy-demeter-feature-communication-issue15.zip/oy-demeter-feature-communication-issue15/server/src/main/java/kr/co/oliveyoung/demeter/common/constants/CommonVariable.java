package kr.co.oliveyoung.demeter.common.constants;

public class CommonVariable {

    public static String userId;
    public static String loginId;

}
