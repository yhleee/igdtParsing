package kr.co.oliveyoung.feature.setting.model;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
public class UserGroup implements Comparable<UserGroup>{
    private Integer groupNo;
    private String groupName;

    @Builder
    public UserGroup(int groupNo, String groupName) {
        this.groupNo = groupNo;
        this.groupName = groupName;
    }

    @Override
    public int compareTo(UserGroup o) {
        return this.groupNo - o.groupNo;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + groupNo;
        return result;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (Objects.isNull(object)) return false;
        if (getClass() != object.getClass()) return false;
        if (object instanceof UserGroup) {
            if (((UserGroup)object).groupNo == groupNo) {
                return true;
            }
        }
        return false;
    }
}
