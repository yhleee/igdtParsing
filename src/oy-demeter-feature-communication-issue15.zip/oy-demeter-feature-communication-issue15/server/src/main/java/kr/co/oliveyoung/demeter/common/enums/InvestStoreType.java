package kr.co.oliveyoung.demeter.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum InvestStoreType {
    NEW(1, "신규점"),
    RENEW(2, "리뉴얼");

    private Integer InvestStoreType;
    private String InvestStoreTypeStr;
}
