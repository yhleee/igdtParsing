package kr.co.oliveyoung.demeter.services.api.setting.validator;

import com.google.common.collect.Lists;
import java.util.Objects;
import java.util.Optional;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuMappingGroup;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Configuration
public class UserMenuAuthorityValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return UserMenuMappingGroup.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserMenuMappingGroup userMenuGroup = (UserMenuMappingGroup) target;

        if (Objects.isNull(userMenuGroup.getMenuNo())) {
            errors.reject("menuAuthority.menuId.empty");
            return;
        }

        long duplicatedGroupCount = Optional.ofNullable(userMenuGroup.getAuthorizedGroups()).orElse(
            Lists.newArrayList()).stream()
            .filter(authorizedUserGroup -> Optional.ofNullable(userMenuGroup.getUnauthorizedGroups()).orElse(
                Lists.newArrayList()).contains(authorizedUserGroup)).count();

        if(duplicatedGroupCount > 0) {
            errors.reject("menuAuthority.group.duplication");
            return;
        }
    }
}
