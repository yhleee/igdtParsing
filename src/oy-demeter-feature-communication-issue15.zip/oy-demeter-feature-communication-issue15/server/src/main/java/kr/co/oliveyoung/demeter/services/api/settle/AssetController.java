package kr.co.oliveyoung.demeter.services.api.settle;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.oliveyoung.demeter.common.csv.FileFactory;
import kr.co.oliveyoung.demeter.common.csv.download.FileDownloader;
import kr.co.oliveyoung.demeter.common.csv.upload.FileDBInsertParser;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.settle.service.AssetService;
import kr.co.oliveyoung.demeter.utils.DRMUtil;
import kr.co.oliveyoung.feature.settle.Asset;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("api/settle")
public class AssetController {

    private final AssetService assetService;

    @ApiOperation("자산이체(일반경비) 리스트")
    @GetMapping("assets")
    public ApiResponseMessage getAssetList() {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(assetService.getAssetList(1, 100000));

        return result;
    }

//    @ApiOperation("자산이체(일반경비) Excel UpLoad")
//    @PostMapping("assets/excelUpLoad")
//    public ApiResponseMessage assetExcelUpLoad(
//        @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart(required = true) MultipartFile uploadFile
//    ) {
//        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드가 완료되었습니다.", null);
//
//        try {
//            assetService.setExcelParseAsset(uploadFile);
//            // CSV
////            FileFactory fileFactory = new FileFactory();
////            FileDBInsertParser fileDBInsertParser = fileFactory.fileDBInsert("csv", uploadFile);
////            List<Map<String, Object>> parseAssetList = fileDBInsertParser.getParseAssetList();
////            assetService.setCSVParseAsset(parseAssetList);
////        } catch (FileNotFoundException fnfe) {
////            log.info("FileNotFoundException ERROR !!", fnfe);
////        } catch (IOException ie) {
////            log.info("IOException ERROR !!", ie);
//        } catch (Exception e) {
//            log.info("assetExcelUpLoad ERROR !!", e);
//        }
//
//        return result;
//    }

    @ApiOperation("자산이체(일반경비) Excel UpLoad (DRM)")
    @PostMapping("assets/drmExcelUpLoad")
    public ApiResponseMessage assetDrmExcelUpLoad(
        @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart MultipartFile uploadFile
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드 완료", null);

        Map<String, String> retMap = assetService.setDrmExcelParseAsset(uploadFile);
        result.setMessage(retMap.get("msg"));
        result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);

        return result;
    }


    @ApiOperation("자산이체(일반경비) Excel DownLoad")
    @GetMapping("assets/excelDownLoad")
    public void assetExcelDownLoad(HttpServletResponse response) {
        // Excel
        try {
            List<Asset> assetList = assetService.getAssetList(1, 100000);

            Workbook wb = new HSSFWorkbook();
            Sheet sheet = wb.createSheet("asset");
            Row row = null;
            Cell cell = null;
            int rowNo = 0;

            // header
            CellStyle headStyle = wb.createCellStyle();

            // 경계선
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);

            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 데이터는 가운데 정렬합니다.
            headStyle.setAlignment(HorizontalAlignment.CENTER);

            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);

            // 1depth headers
            row = sheet.createRow(rowNo++);

            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("자산번호");

            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("자산명");

            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("위치");

            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("관리코스트센터코드");

            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("관리코스트센터명");

            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("관리담당자명");

            cell = row.createCell(6);
            cell.setCellStyle(headStyle);
            cell.setCellValue("이체구분(01:전체,02:비율,03:수량)");

            cell = row.createCell(7);
            cell.setCellStyle(headStyle);
            cell.setCellValue("이체비율(%)");

            cell = row.createCell(8);
            cell.setCellStyle(headStyle);
            cell.setCellValue("이체수량");

            cell = row.createCell(9);
            cell.setCellStyle(headStyle);
            cell.setCellValue("변경코스트센터");

            cell = row.createCell(10);
            cell.setCellStyle(headStyle);
            cell.setCellValue("변경코스트센터명");


            // 2depth headers
            row = sheet.createRow(rowNo++);

            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("ASSET_CD");


            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("ASSET_TXT");

            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("ASSET_LO");

            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("MNG_CST_CNTR_CD");

            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("MNG_CST_CNTR_NM");

            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("MNG_MN");

            cell = row.createCell(6);
            cell.setCellStyle(headStyle);
            cell.setCellValue("ASSET_PART_TYPE_CD");

            cell = row.createCell(7);
            cell.setCellStyle(headStyle);
            cell.setCellValue("PART_RATE");

            cell = row.createCell(8);
            cell.setCellStyle(headStyle);
            cell.setCellValue("PROC_CNT");

            cell = row.createCell(9);
            cell.setCellStyle(headStyle);
            cell.setCellValue("TO_CST_CNTR_CD");

            cell = row.createCell(10);
            cell.setCellStyle(headStyle);
            cell.setCellValue("TO_CST_CNTR_NM");


            // Output Data
            for(Asset asset : assetList) {
                row = sheet.createRow(rowNo++);
                cell = row.createCell(0);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getAssetCd())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(1);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getAssetTxt())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(2);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getAssetLo())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(3);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getMngCstCntrCd())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(4);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getMngCstCntrNm())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(5);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getMngMn())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(6);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getAssetPartTypeCd())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(7);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getPartRate())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(8);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getProcCnt())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(9);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getToCstCntrCd())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(10);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(asset.getToCstCntrNm())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );
            }

            // 컨텐츠 타입과 파일명 지정
            response.setContentType("ms-vnd/excel");
            response.setHeader("Content-Disposition", "attachment;filename=settle_asset.xls");

            // 엑셀 출력
            wb.write(response.getOutputStream());
            wb.close();
        } catch (Exception e) {
            log.info("assetExcelDownLoad ERROR !!", e);
        }

        // CSV
        /*
        int page = 1;
        int size = 5000;
        FileFactory fileFactory = new FileFactory();
        try (FileDownloader fileDownloader = fileFactory.fileDownloader("csv", response)) {
            while (true) {
                List<Asset> assetList = assetService.getAssetList(page, size);
                if (assetList.isEmpty()) {
                    break;
                }

                fileDownloader.assetListPartDown(assetList, page);
                page++;
            }
        } catch (Exception e) {
            log.info("assetExcelDownLoad ERROR !!", e);
        }
         */

    }

}
