package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class BaseVO {
    Integer creator;
    Integer updater;
    String createDatetime;
    String updateDatetime;
    String updaterName;
    String creatorName;
}
