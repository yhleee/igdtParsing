package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import lombok.Data;

@Data
public class MovieInfoVO {

}
