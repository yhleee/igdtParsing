package kr.co.oliveyoung.feature.settle;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
public class HqInvestStore {

    private Integer investStoreNo;
    private String toCstCntrCd;
    private String investStoreName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime investStoreOpenDate;

    private Integer investStoreType;
    private String investStoreRemarks;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
    private LocalDateTime sysRegDtime;

    private String sysRegrId;
    private List<HqInvestStoreAsset> investStoreAssetList;

    // pt invest store data check
//    private String investStoreAssetRackYn;
//    private String investStoreAssetVpnYn;
//    private String investStoreAssetLedYn;
//    private String investStoreAssetSettopPcYn;
//    private String investStoreAssetPosYn;
//    private String investStoreAssetSurgeProtectorYn;
//    private String investStoreAssetHubYn;
//    private String investStoreAssetHandScannerYn;
//    private String investStoreAssetPdaYn;
//    private String investStoreAssetSignPadYn;
//    private String investStoreAssetCatYn;
//    private String investStoreAssetSwitchYn;
//    private String investStoreAssetIcTerminalYn;
}
