package kr.co.oliveyoung.feature.setting;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.setting.model.ScheduleFireWall;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@MySqlOyisMapper
public interface ScheduleMapper {
    List<ScheduleFireWall> selectScheduleList(
        @Param("scheduleType") String scheduleType
    );
    List<ScheduleFireWall> selectBatchScheduleList(
        @Param("scheduleType") String scheduleType,
        @Param("currentDate") LocalDate currentDate
    );
    void insertFireWallSchedule(@Param("data") ScheduleFireWall scheduleFireWall);
}
