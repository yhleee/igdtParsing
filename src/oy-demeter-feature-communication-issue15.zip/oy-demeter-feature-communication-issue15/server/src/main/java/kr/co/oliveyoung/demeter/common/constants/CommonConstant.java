package kr.co.oliveyoung.demeter.common.constants;

public class CommonConstant {

    // public final static String HTTP_HEADER_TOKEN_KEY = "X-Token";
    public final static String HTTP_HEADER_TOKEN_KEY = "ACCESS_TOKEN";
    public final static String DRM_FILE_PATH = "/fasoo_drm/contents/";

}
