package kr.co.oliveyoung.demeter.services.api.setting.service;

import java.util.HashMap;
import java.util.List;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserParam;
import kr.co.oliveyoung.feature.setting.UserMapper;
import kr.co.oliveyoung.feature.setting.model.User;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public User fetchUser(Integer userNo) {
        return userMapper.selectUser(new HashMap<>(){
            {
                put("userNo", userNo);
            }
        });
    };

    public User fetchUser(String loginId, String password) {
        return userMapper.selectUser(new HashMap<>(){
            {
                put("loginId", loginId);
                put("password", password);
            }
        });
    };

    public User fetchUser(UserParam userParam) {
        return this.fetchUser(userParam.getLoginId(), userParam.getPassword());
    }

    public int modifyUser(User user) {
        return userMapper.updateUser(user);
    }

    public int addUser(User user) {
        return userMapper.insertUser(user);
    }

    public List<UserGroup> fetchUserGroup(Integer userNo) {
        return userMapper.selectUserGroup(userNo);
    }
}
