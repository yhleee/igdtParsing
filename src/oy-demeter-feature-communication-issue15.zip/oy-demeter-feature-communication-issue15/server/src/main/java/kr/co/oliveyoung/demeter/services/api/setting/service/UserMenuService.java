package kr.co.oliveyoung.demeter.services.api.setting.service;

import java.util.HashMap;
import java.util.List;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserMenuParam;
import kr.co.oliveyoung.feature.setting.UserMenuMapper;
import kr.co.oliveyoung.feature.setting.model.UserMenu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserMenuService {

    @Autowired
    private UserMenuMapper userMenuMapper;

    public List<UserMenu> fetchUserMenu(Integer... menuNos) {
        return userMenuMapper.selectUserMenu(new HashMap<>(){
            {
                put("menuNos", menuNos);
            }
        });
    }

    public int addUserMenu(UserMenuParam param) {
        return userMenuMapper.insertUserMenu(UserMenu.builder().menuIconName(param.getIconName())
            .menuLevel(param.getLevel()).menuName(param.getMenuName())
            .menuUrl(param.getUrl()).modifierId(param.getModifierId())
            .registerId(param.getRegisterId()).upperMenuNo(param.getUpperMenuNo())
            .sortSeq(param.getSortSeq()).useYn(param.getUseYn()).build());
    }

    public int modifyUserMenu(UserMenuParam param) {
        return userMenuMapper.updateUserMenu(UserMenu.builder().menuNo(param.getMenuNo())
            .menuIconName(param.getIconName()).menuLevel(param.getLevel())
            .menuName(param.getMenuName()).menuUrl(param.getUrl())
            .modifierId(param.getModifierId()).upperMenuNo(param.getUpperMenuNo())
            .sortSeq(param.getSortSeq()).useYn(param.getUseYn()).build());
    }

    public int removeUserMenu(Integer... menuNos) {
        return userMenuMapper.deleteUserMenu(menuNos);
    }

    public List<UserMenu> getUserAuthorityMenuList(Integer userNo) {
        return userMenuMapper.selectUserAuthorityMenuList(userNo);
    }

}
