package kr.co.oliveyoung.demeter.common.csv.download;

import kr.co.oliveyoung.feature.settle.Asset;
import kr.co.oliveyoung.feature.settle.PtInvestStore;

import java.util.List;

public abstract class FileDownloader implements AutoCloseable {
    public abstract void assetListPartDown(List<Asset> assetList, int page);
    public abstract void ptInvestStoreListPartDown(List<PtInvestStore> ptInvestStoreList, int page);
}
