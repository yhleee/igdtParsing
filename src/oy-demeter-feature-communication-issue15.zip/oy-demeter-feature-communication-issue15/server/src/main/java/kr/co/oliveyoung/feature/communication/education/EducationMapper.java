package kr.co.oliveyoung.feature.communication.education;

import java.util.List;
import java.util.Map;
import kr.co.oliveyoung.config.mybatis.MySqlEducomMapper;
import kr.co.oliveyoung.demeter.common.model.PageRequest;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.AttachmentVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.MemberGroupAuthorityVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.MemberGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.PostVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagGroupVO;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.TagVO;
import kr.co.oliveyoung.feature.communication.education.model.Attachment;
import kr.co.oliveyoung.feature.communication.education.model.AttachmentGroup;
import kr.co.oliveyoung.feature.communication.education.model.EduPost;
import kr.co.oliveyoung.feature.communication.education.model.EduTag;
import kr.co.oliveyoung.feature.communication.education.model.MemberGroupAuthority;
import org.apache.ibatis.annotations.Param;

@MySqlEducomMapper
public interface EducationMapper {

    int insertPost(EduPost post);

    int updatePost(EduPost post);

    int insertTag(EduTag tags);

    int insertPostTagMapping(@Param("postNo") Long postNo, @Param("tagNo") Long tagNo,
        @Param("creator") Integer creator);

    int deletePostTagMappings(@Param("postNo") Long postNo, @Param("tagNos") Long... tagNos);

    List<TagVO> selectTags(Map<String, Object> params);

    int countTags(Map<String, Object> params);

    List<TagGroupVO> selectTagGroups(@Param("tagGroupName") String tagGroupName,
        @Param("page") PageRequest page);

    int countTagGroups(@Param("tagGroupName") String tagGroupName);

    int insertMemberGroupAuthority(MemberGroupAuthority memberGroupAuthority);

    int deleteMemberGroupAuthority(Map<String, Object> params);

    List<MemberGroupVO> selectMemberGroups(@Param("groupName")String groupName, @Param("page") PageRequest page);

    int countMemberGroups(@Param("groupName")String groupName);

    int insertAttachment(Attachment attachment);

    int updateAttachment(Attachment attachment);

    int deleteAttachments(@Param("attachmentGroupNo")Long attachmentGroupNo, @Param("attachmentNos")Long... attachmentNos);

    List<AttachmentVO> selectAttachments(Map<String, Object> params);

    int insertAttachmentGroup(AttachmentGroup group);

    PostVO selectPostById(@Param("postNo") Long postNo);

    List<PostVO> selectPosts(Map<String, Object> params);

    int countPosts(Map<String, Object> params);

    List<MemberGroupAuthorityVO> selectGroupAuthorities(Map<String, Object> params);
}
