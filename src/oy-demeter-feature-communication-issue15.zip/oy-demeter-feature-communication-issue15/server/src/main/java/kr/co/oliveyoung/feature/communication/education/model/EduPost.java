package kr.co.oliveyoung.feature.communication.education.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EduPost {
    private Long postNo;
    private Long boardNo;
    private String title;
    private String contents;
    private Long viewCount;
    private Long attachGroupNo;
    private String noticeYn;
    private String useYn;
    private Integer creator;
    private String createDatetime;
    private Integer updater;
    private String updateDatetime;
}
