package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.AttachFileTypeCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentVO extends BaseVO implements Serializable {

    private static final long serialVersionUID = -3167895029529189437L;

    private Long attachNo;
    private Long attachGroupNo;
    private AttachFileTypeCode fileTypeCode;
    @JsonIgnore
    private String filePath;
    private String fileUrl;
    private Integer order;
    private Long fileSize;
    private String mediaKey;
}
