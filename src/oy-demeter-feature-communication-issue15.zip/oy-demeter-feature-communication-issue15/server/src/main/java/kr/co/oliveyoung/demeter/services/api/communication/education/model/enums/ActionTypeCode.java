package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum ActionTypeCode {
    CREATE("CREATE", "등록"),
    UPDATE("UPDATE", "수정"),
    DELETE("DELETE", "삭제");

    private String code;
    private String text;

    ActionTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
