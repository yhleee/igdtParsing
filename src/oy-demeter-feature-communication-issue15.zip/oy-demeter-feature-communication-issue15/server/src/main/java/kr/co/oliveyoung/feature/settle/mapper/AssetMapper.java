package kr.co.oliveyoung.feature.settle.mapper;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.feature.settle.Asset;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@MySqlOyisMapper
public interface AssetMapper {
    List<Asset> selectAssetList(int size, int offset);
    void insertAsset(@Param("data") Asset asset);
    void truncateAssetAllData();
}
