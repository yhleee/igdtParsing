package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;

@Getter
public enum ServiceAreaTypeCode {

    EDUCATION("EDUCATION", "교육"),
    SOTONG("SOTONG", "교육"),
    NEWS("NEWS", "소식");

    private String code;
    private String text;

    ServiceAreaTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }
}
