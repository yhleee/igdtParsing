package kr.co.oliveyoung.demeter.common.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;

import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponseMessage implements Serializable {
    private static final long serialVersionUID = 9189489544166339048L;
    private Integer statusCode = 200;
    private ResponseResult result;
    private String message;
    private String redirectUrl;
    private Long lastCreatedNo;
    private Integer totalCnt;
    private Object contents;
    private Object params;

    public ApiResponseMessage() {
    }

    public ApiResponseMessage(ResponseResult result) {
        this.result = result;
    }

    public ApiResponseMessage(ResponseResult result, String message) {
        this.result = result;
        if (ResponseResult.FAIL.equals(result)) {
            this.message = "[ERROR] 오류가 발생하였습니다.";
        }
        if (StringUtils.isNotBlank(message)) {
            this.message = message;
        }
    }

    public ApiResponseMessage(
        ResponseResult result,
        String message,
        String redirectUrl
    ) {
        this.result = result;
        if (ResponseResult.FAIL.equals(result)) {
            this.message = "[ERROR] 오류가 발생하였습니다.";
        } else {
            this.message = message;
        }
        this.redirectUrl = redirectUrl;
    }
}
