package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Objects;
import kr.co.oliveyoung.demeter.services.api.communication.education.model.enums.ActionTypeCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PostVO extends BaseVO{
    @JsonIgnore
    private ActionTypeCode actionTypeCode;
    private Long postNo;
    private Long boardNo = 1l;
    private String title;
    private String contents;
    private int viewCount;
    private String noticeYn;
    private String useYn;
    private List<TagVO> tags;

    @JsonIgnore
    private MultipartFile banner;
    @JsonIgnore
    private MultipartFile thumbnail;
    @JsonIgnore
    private List<MultipartFile> images;
    @JsonIgnore
    private MultipartFile attachment;

    private List<AttachmentVO> attachments;
    private Long attachGroupNo;
    private String mediaKey;

    private List<MemberGroupAuthorityVO> memberGroupAuthorities;

    public void addAttachment(AttachmentVO attachmentVO) {
        if(Objects.isNull(attachments)) {
            attachments = Lists.newArrayList(attachmentVO);
            return;
        }
        attachments.add(attachmentVO);
    }
}
