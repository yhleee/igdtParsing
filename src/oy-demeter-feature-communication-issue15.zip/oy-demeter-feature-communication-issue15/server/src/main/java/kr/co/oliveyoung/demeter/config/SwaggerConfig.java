package kr.co.oliveyoung.demeter.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any()) // 현재 RequestMapping으로 할당된 모든 URL 리스트 추출
                .paths(PathSelectors.ant("/api/**"))
                .build();
    }

    /*
    @Bean
    public Docket adminApi() {
        List<Parameter> global = new ArrayList<>();
        global.add(new ParameterBuilder()
                .name("ADM_CODE_001")
                .description("Access Token")
                .parameterType("header")
                .required(false)
                .modelRef(new ModelRef("string")).build());

        return new Docket(DocumentationType.SWAGGER_2)
                .globalOperationParameters(global)
                .groupName("latest")
                .select()
                .apis(RequestHandlerSelectors.basePackage("kr.co.oliveyoung.demeter.services.api"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo("OMS API", "OMS APIs..", "latest"));
    }

    private ApiInfo apiInfo(String title, String description, String version) {
        Contact contact = new Contact("cj oliveyoung", "http://www.oliveyoung.co.kr", "bongkeun.jeon@cj.net");

        return new ApiInfoBuilder()
                .title(title)
                .description(description)
                .version(version)
                .termsOfServiceUrl("terms of controller url")
                .license("all rights reserved cj oliveyoung")
                .licenseUrl("http://www.oliveyoung.co.kr")
                .contact(contact)
                .build();
    }
     */

}
