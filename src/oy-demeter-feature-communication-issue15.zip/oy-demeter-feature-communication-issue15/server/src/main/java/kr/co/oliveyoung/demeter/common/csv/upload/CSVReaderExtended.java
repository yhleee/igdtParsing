package kr.co.oliveyoung.demeter.common.csv.upload;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.IOException;
import java.io.Reader;

public class CSVReaderExtended extends CSVReader {

    private static final String EXP_ALPHA_AND_DIGITS = "\\s";   // 공백제거

    public CSVReaderExtended(Reader reader) {
        super(reader);
    }

    @Override
    public String[] readNext() throws IOException, CsvValidationException {
        String[] result = super.readNext();

        if (result == null)
            return null;

        for (int index = 0; index < result.length; index++) {
            result[index] = result[index];
        }

        return result;
    }
}
