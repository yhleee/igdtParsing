package kr.co.oliveyoung.feature.setting.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserMenu {
    private Integer menuNo;
    private String menuName;
    private String menuIconName;
    private Integer upperMenuNo;
    private Integer menuLevel;
    private Integer sortSeq;
    private String menuUrl;
    private String useYn;
    private String registerDatetime;
    private String registerId;
    private String modifyDatetime;
    private String modifierId;

    public boolean isUsable() {
        return BooleanUtils.toBoolean(this.useYn);
    }
}
