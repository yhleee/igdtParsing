package kr.co.oliveyoung.demeter.services.api.settle;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.settle.param.TeamProjectDTO;
import kr.co.oliveyoung.demeter.services.api.settle.param.TeamProjectListParam;
import kr.co.oliveyoung.demeter.services.api.settle.service.TeamProjectService;
import kr.co.oliveyoung.feature.settle.Asset;
import kr.co.oliveyoung.feature.settle.TeamProject;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("api/settle")
public class TeamProjectController {

    private final TeamProjectService teamProjectService;

    @ApiOperation("정보전략팀 투자/비용 취합 리스트")
    @GetMapping("teamProjects")
    public ApiResponseMessage getTeamProjectList(
        @ApiParam(value = "page 번호를 설정할 수 있으며 설정 값은 1-N까지 입니다.", name = "page", defaultValue = "1", required = true) @RequestParam int page,
        @ApiParam(value = "페이지 별 레코드 갯수를 설정 할 수 있습니다.", name = "size", defaultValue = "10", required = true) @RequestParam int size,
        TeamProjectListParam param
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(teamProjectService.getTeamProjectList(page, size, param));
        result.setParams(param);

        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 취합 미 확정 개수 체크(버튼값 표시 용도)")
    @GetMapping("teamProject/activeTypeCnt")
    public ApiResponseMessage getTeamProjectActiveType() {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(teamProjectService.getTeamProjectActiveTypeYnCnt("N"));
        return result;
    }

    @ApiOperation("팀 프로젝트 투자/비용 취합 상세")
    @GetMapping("teamProject/{teamProjectNo}")
    public ApiResponseMessage getTeamProjectDetail(
        @PathVariable("teamProjectNo") Integer teamProjectNo
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(teamProjectService.selectTeamProjectDetail(teamProjectNo));

        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 취합 등록")
    @PostMapping("teamProject")
    public ApiResponseMessage setTeamProject(
        @RequestBody TeamProjectDTO teamProjectDTO,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "등록이 완료되었습니다.", null);
        result.setParams(teamProjectDTO);
        teamProjectService.insertTeamProject(teamProjectDTO, tokenVO);

        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 취합 수정")
    @PutMapping("teamProject/{teamProjectNo}")
    public ApiResponseMessage updateTeamProject(
        @PathVariable("teamProjectNo") Integer teamProjectNo,
        @RequestBody TeamProjectDTO teamProjectDTO,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "변경이 완료되었습니다.", null);
        result.setParams(teamProjectDTO);
        teamProjectService.updateTeamProject(teamProjectNo, teamProjectDTO, tokenVO);

        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 취합 삭제")
    @DeleteMapping("teamProject/{teamProjectNo}")
    public ApiResponseMessage deleteTeamProject(
        @PathVariable("teamProjectNo") Integer teamProjectNo
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "삭제가 완료되었습니다.", null);
        teamProjectService.deleteTeamProject(teamProjectNo);
        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 취합 데이터 수정기능 활성화 변경")
    @PatchMapping("teamProjects/teamProjectActiveType")
    public ApiResponseMessage updateActiveUser(
        @RequestParam("teamProjectActiveType") String teamProjectActiveType,
        @RequestParam("teamProjectRegYearMonth") String teamProjectRegYearMonth
    ) {
        ApiResponseMessage result = new ApiResponseMessage(
            ResponseResult.SUCCESS,
            "확정 처리가 완료 되었습니다.",
            null
        );
        teamProjectService.updateTeamProjectActiveType(teamProjectActiveType, teamProjectRegYearMonth);

        return result;
    }

    @ApiOperation("정보전략팀 투자/비용 Excel DownLoad")
    @GetMapping("teamProjects/excelDownLoad")
    public void teamProjectExcelDownLoad(
        @ApiParam(value = "page 번호를 설정할 수 있으며 설정 값은 1-N까지 입니다.", name = "page", defaultValue = "1", required = true) @RequestParam int page,
        @ApiParam(value = "페이지 별 레코드 갯수를 설정 할 수 있습니다.", name = "size", defaultValue = "10", required = true) @RequestParam int size,
        HttpServletResponse response,
        TeamProjectListParam param
    ) {
        try {
            List<TeamProject> teamProjectList = teamProjectService.getTeamProjectList(page, size, param);

            Workbook wb = new HSSFWorkbook();
            Sheet sheet = wb.createSheet("team_project");
            Row row = null;
            Cell cell = null;
            int rowNo = 0;

            // header
            CellStyle headStyle = wb.createCellStyle();

            // 경계선
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);

            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 데이터는 가운데 정렬합니다.
            headStyle.setAlignment(HorizontalAlignment.CENTER);

            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);

            // 1depth headers
            row = sheet.createRow(rowNo++);

            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("No(추가할 경우 No값 0으로 입력)");

            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("정산구분");

            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("구분");

            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("발의부서");

            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("계약서명");

            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("품의서번호");

            cell = row.createCell(6);
            cell.setCellStyle(headStyle);
            cell.setCellValue("OY 품의 제목");

            cell = row.createCell(7);
            cell.setCellStyle(headStyle);
            cell.setCellValue("금액");

            cell = row.createCell(8);
            cell.setCellStyle(headStyle);
            cell.setCellValue("귀속 코스트 센터");

            cell = row.createCell(9);
            cell.setCellStyle(headStyle);
            cell.setCellValue("OY WBS(투자일 경우에만 입력)");

            cell = row.createCell(10);
            cell.setCellStyle(headStyle);
            cell.setCellValue("확정여부(Y:확정, N:확정안함)");

            // Output Data
            for(TeamProject teamProject : teamProjectList) {
                row = sheet.createRow(rowNo++);
                cell = row.createCell(0);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable((int) Double.parseDouble(teamProject.getTeamProjectNo().toString()))
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(1);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectSettleType() == 1 ? "투자" : "비용")
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(2);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectType() == 1 ? "프로젝트" : "일반")
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(3);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectDepartment())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(4);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectDealCheck())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(5);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectDocumentNumber())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(6);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectDocumentTitle())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(7);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectPrice())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(8);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectCostCenter())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(9);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectWBSCode())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );

                cell = row.createCell(10);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(teamProject.getTeamProjectActiveType())
                    .map(String::valueOf)
                    .orElse("")
                    .trim()
                );
            }

            // 컨텐츠 타입과 파일명 지정
            response.setContentType("ms-vnd/excel");
            response.setHeader("Content-Disposition", "attachment;filename=settle_team_project.xls");

            // 엑셀 출력
            wb.write(response.getOutputStream());
            wb.close();
        } catch (Exception e) {
            log.info("teamProjectExcelDownLoad ERROR !!", e);
        }
    }

//    @ApiOperation("정보전략팀 투자/비용 Excel UpLoad")
//    @PostMapping("teamProjects/excelUpLoad")
//    public ApiResponseMessage teamProjectExcelUpLoad(
//        @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart(required = true) MultipartFile uploadFile,
//        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
//    ) {
//        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드가 완료되었습니다.", null);
//
//        try {
//            Map<String, String> retMap = teamProjectService.setExcelParseTeamProject(uploadFile, tokenVO);
//            result.setMessage(retMap.get("msg"));
//            result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);
//        } catch (Exception e) {
//            log.info("excelUpLoad ERROR !!", e);
//        }
//
//        return result;
//    }

    @ApiOperation("정보전략팀 투자/비용 Excel UpLoad (DRM)")
    @PostMapping("teamProjects/drmExcelUpLoad")
    public ApiResponseMessage teamProjectDrmExcelUpLoad(
        @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart MultipartFile uploadFile,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드가 완료되었습니다.", null);

        try {
            Map<String, String> retMap = teamProjectService.setDrmExcelParseTeamProject(uploadFile, tokenVO);
            result.setMessage(retMap.get("msg"));
            result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);
        } catch (Exception e) {
            log.info("teamProjectExcelUpLoad ERROR !!", e);
        }

        return result;
    }

}
