package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "name",
    "language_code"
})
public class Filter {
    @JsonProperty("name")
    private String name;
    @JsonProperty("language_code")
    private String languageCode;
}
