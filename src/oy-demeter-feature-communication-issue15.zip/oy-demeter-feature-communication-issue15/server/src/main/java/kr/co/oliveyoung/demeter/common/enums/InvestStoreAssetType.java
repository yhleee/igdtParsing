package kr.co.oliveyoung.demeter.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * DESC
 * 신규/리뉴얼 매장 장비 투자(본사) 기준 => settle_hq_invest_store_asset 테이블 참조
 * 1:RACK
 * 2:VPN
 * 3:IC단말기
 * 4:LED
 * 5:셋탑PC
 * 6:POS
 * 7:서지보호기
 * 8:HUB
 * 9:핸드스캐너
 * 10:PDA
 * 11:사인패드
 * 12:CAT
 * 13:스위치
 */
@Getter
@AllArgsConstructor
public enum InvestStoreAssetType {
    RACK(1),
    VPN(2),
    IC_TERMINAL(3),
    LED(4),
    SETTOP_PC(5),
    POS(6),
    SURGE_PROTECTOR(7),
    HUB(8),
    HAND_SCANNER(9),
    PDA(10),
    SIGN_PAD(11),
    CAT(12),
    SWITCH(13);

    private int investStroeAssetNo;
}
