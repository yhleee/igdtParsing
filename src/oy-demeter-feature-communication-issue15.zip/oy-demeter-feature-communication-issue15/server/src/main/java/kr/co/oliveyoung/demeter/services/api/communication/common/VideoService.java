package kr.co.oliveyoung.demeter.services.api.communication.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import kr.co.oliveyoung.demeter.services.api.communication.common.model.video.MediaContent;
import kr.co.oliveyoung.demeter.services.api.communication.common.model.video.VideoServicePayload;
import kr.co.oliveyoung.demeter.services.api.communication.common.model.video.VideoWatermarkingCodePolicy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class VideoService {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final long VIDEO_TTL = 60 * 60 * 24; //24시간
    private static final String secretKey = "cjoliveyoung";

    public String token(String memberId, String mediaKey)
        throws JsonProcessingException, InvalidKeyException, NoSuchAlgorithmException {
        VideoServicePayload payload = VideoServicePayload.builder()
            .cuid(memberId)
            .expt(Instant.now().getEpochSecond() + VIDEO_TTL)
            .videoWatermarkingCodePolicy(
                VideoWatermarkingCodePolicy.builder()
                    .codeKind(memberId)
                    .alpha(150)
                    .showTime(10)
                    .hideTime(1)
                    .fontSize(15)
                    .enableHtml5Player(true)
                    .build())
            .build();
        payload.addMediaContent(MediaContent.builder()
            .mckey(mediaKey)
            .build());

        Map<String, Object> jwtHeader = new HashMap<>() {
            {
                put("alg", "HS256");
                put("typ", "JWT");
            }
        };
        String token = createJwt(objectMapper.writeValueAsString(jwtHeader),
            objectMapper.writeValueAsString(payload), secretKey);
        return token;
    }

    private String createJwt(String headerJson, String payloadJson, String secretKey)
        throws NoSuchAlgorithmException, InvalidKeyException {
        String header = Base64.encodeBase64URLSafeString(StringUtils.getBytesUtf8(headerJson));
        String payload = Base64.encodeBase64URLSafeString(StringUtils.getBytesUtf8(payloadJson));
        String content = String.format("%s.%s", header, payload);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(StringUtils.getBytesUtf8(secretKey), "HmacSHA256"));
        byte[] signatureBytes = mac.doFinal(StringUtils.getBytesUtf8(content));
        String signature = Base64.encodeBase64URLSafeString(signatureBytes);
        return String.format("%s.%s", content, signature);
    }
}
