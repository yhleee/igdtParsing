package kr.co.oliveyoung.demeter.common.csv.download;

import kr.co.oliveyoung.feature.settle.Asset;
import kr.co.oliveyoung.feature.settle.PtInvestStore;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

@Slf4j
public class CSVFileDownload extends FileDownloader {

    private final HttpServletResponse response;
    private final ServletOutputStream out;

    public CSVFileDownload(HttpServletResponse response) throws IOException {
        this.response = response;
        this.out = response.getOutputStream();
    }

    public void assetListPartDown(List<Asset> assetList, int page) {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition","attachment;filename=settle_assest.csv");
        response.setCharacterEncoding("EUC-KR");

        // csv
        try {
            StringBuffer sb = settleAssetCSVFileBuffer(assetList, page);
            InputStream in = new ByteArrayInputStream(sb.toString().getBytes("EUC-KR"));
            int fileSize = response.getBufferSize();

            byte[] outputByte = new byte[fileSize];
            int len = 0;
            while( (len = in.read(outputByte, 0, fileSize)) != -1) {
                out.write(outputByte, 0, len);
            }

            in.close();

        } catch (IOException e) {
            log.info("assetListPartDown ERROR !! : {}", e.getMessage());
        }
    }

    public void ptInvestStoreListPartDown(List<PtInvestStore> ptInvestStoreList, int page) {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition","attachment;filename=pt_invest_store.csv");
        response.setCharacterEncoding("EUC-KR");

        // csv
        try {
            StringBuffer sb = ptInvestStoreCSVFileBuffer(ptInvestStoreList, page);
            InputStream in = new ByteArrayInputStream(sb.toString().getBytes("EUC-KR"));
            int fileSize = response.getBufferSize();

            byte[] outputByte = new byte[fileSize];
            int len = 0;
            while( (len = in.read(outputByte, 0, fileSize)) != -1) {
                out.write(outputByte, 0, len);
            }

            in.close();

        } catch (IOException e) {
            log.info("assetListPartDown ERROR !! : {}", e.getMessage());
        }
    }

    @Override
    public void close() throws Exception {
        out.flush();
        out.close();
    }

    private static StringBuffer settleAssetCSVFileBuffer(List<Asset> assetList, int page) {
        StringBuffer writer = new StringBuffer();

        if (page == 1) {
            writer.append("자산번호")
                    .append(',')
                    .append("자산명")
                    .append(',')
                    .append("위치")
                    .append(',')
                    .append("관리코스트센터코드")
                    .append(',')
                    .append("관리코스트센터명")
                    .append(',')
                    .append("관리담당자명")
                    .append(',')
                    .append("이체구분(01:전체 / 02:비율 / 03:수량)")
                    .append(',')
                    .append("이체비율(%)")
                    .append(',')
                    .append("이체수량")
                    .append(',')
                    .append("변경코스트센터")
                    .append(',')
                    .append("변경코스트센터명")
                    .append('\n')
                    .append("ASSET_CD")
                    .append(',')
                    .append("ASSET_TXT")
                    .append(',')
                    .append("ASSET_LO")
                    .append(',')
                    .append("MNG_CST_CNTR_CD")
                    .append(',')
                    .append("MNG_CST_CNTR_NM")
                    .append(',')
                    .append("MNG_MN")
                    .append(',')
                    .append("ASSET_PART_TYPE_CD")
                    .append(',')
                    .append("PART_RATE")
                    .append(',')
                    .append("PROC_CNT")
                    .append(',')
                    .append("TO_CST_CNTR_CD")
                    .append(',')
                    .append("TO_CST_CNTR_NM")
                    .append('\n');
        }

        assetList.forEach(obj -> {
            writer
                    .append(Optional.ofNullable(obj.getAssetCd())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getAssetTxt())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getAssetLo())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getMngCstCntrCd())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getMngCstCntrNm())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getMngMn())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getAssetPartTypeCd())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getPartRate())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getProcCnt())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getToCstCntrCd())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getToCstCntrNm())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append('\n');
        });

        return writer;
    }

    private static StringBuffer ptInvestStoreCSVFileBuffer(List<PtInvestStore> ptInvestStoreList, int page) {
        StringBuffer writer = new StringBuffer();

        if (page == 1) {
            writer.append("매장명")
                    .append(",")
                    .append("신규/리뉴얼(1:신규점 / 2:리뉴얼)")
                    .append(",")
                    .append("메뉴 카테고리(수정X)")
                    .append(",")
                    .append("장비명(1:RACK / 2:VPN / 3:IC단말기)")
                    .append(",")
                    .append("수량")
                    .append(",")
                    .append("단가")
                    .append(",")
                    .append("비고")
                    .append('\n')
                    .append("INVEST_STORE_NAME")
                    .append(",")
                    .append("INVEST_STORE_TYPE")
                    .append(",")
                    .append("INVEST_STORE_CATEGORY_NO")
                    .append(",")
                    .append("INVEST_STORE_ASSET_NO")
                    .append(",")
                    .append("INVEST_STORE_COUNT")
                    .append(",")
                    .append("INVEST_STORE_PRICE")
                    .append(",")
                    .append("INVEST_STORE_REMARKS")
                    .append('\n');
        }

        ptInvestStoreList.forEach(obj -> {
            writer
                    .append(Optional.ofNullable(obj.getInvestStoreName())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStoreType())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStoreCategoryNo())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStoreAssetNo())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStoreCount())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStorePrice())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append(',')
                    .append(Optional.ofNullable(obj.getInvestStoreRemarks())
                            .map(String::valueOf)
                            .orElse("")
                            .trim())
                    .append('\n');
        });

        return writer;
    }

}
