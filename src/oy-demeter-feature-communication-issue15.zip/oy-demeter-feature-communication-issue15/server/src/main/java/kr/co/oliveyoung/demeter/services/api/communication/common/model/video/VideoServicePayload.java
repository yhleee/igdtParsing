package kr.co.oliveyoung.demeter.services.api.communication.common.model.video;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cuid",
    "awtc",
    "video_watermarking_code_policy",
    "expt",
    "pc_skin",
    "mc"
})
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VideoServicePayload {

    @JsonProperty("cuid")
    private String cuid;
    @JsonProperty("awtc")
    private String awtc;
    @JsonProperty("video_watermarking_code_policy")
    private VideoWatermarkingCodePolicy videoWatermarkingCodePolicy;
    @JsonProperty("expt")
    private Long expt;
    @JsonProperty("pc_skin")
    private PcSkin pcSkin;
    @JsonProperty("mc")
    private List<MediaContent> mc = null;

    public void addMediaContent(MediaContent content) {
        if(Objects.isNull(mc)) {
            mc = Lists.newArrayList(content);
            return;
        }
        mc.add(content);
    }
}
