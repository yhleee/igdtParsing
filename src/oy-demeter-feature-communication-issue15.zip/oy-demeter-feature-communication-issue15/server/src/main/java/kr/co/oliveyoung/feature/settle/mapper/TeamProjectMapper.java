package kr.co.oliveyoung.feature.settle.mapper;

import kr.co.oliveyoung.config.mybatis.MySqlOyisMapper;
import kr.co.oliveyoung.demeter.services.api.settle.param.TeamProjectListParam;
import kr.co.oliveyoung.feature.settle.TeamProject;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@MySqlOyisMapper
public interface TeamProjectMapper {
    List<TeamProject> selectTeamProjectList(
        @Param("size") Integer size,
        @Param("offset") Integer offset,
        @Param("param") TeamProjectListParam param
    );
    TeamProject selectTeamProjectDetail(Integer teamProjectId);
    Integer selectTeamProjectActiveTypeYnCnt(String teamProjectActiveType);
    void insertTeamProject(@Param("data") TeamProject teamProject);
    void updateTeamProject(@Param("data") TeamProject teamProject);
    void deleteTeamProject(Integer teamProjectId);
    void updateTeamProjectActiveType(String teamProjectActiveType, String teamProjectRegYearMonth);
    void upsertTeamProject(@Param("data") TeamProject teamProject);
}
