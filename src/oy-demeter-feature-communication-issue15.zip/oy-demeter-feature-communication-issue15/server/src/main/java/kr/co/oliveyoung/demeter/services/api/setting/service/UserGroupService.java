package kr.co.oliveyoung.demeter.services.api.setting.service;

import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import kr.co.oliveyoung.demeter.services.api.setting.model.UserGroupParam;
import kr.co.oliveyoung.feature.setting.UserGroupMapper;
import kr.co.oliveyoung.feature.setting.UserMenuAuthorityMapper;
import kr.co.oliveyoung.feature.setting.model.GroupUser;
import kr.co.oliveyoung.feature.setting.model.User;
import kr.co.oliveyoung.feature.setting.model.UserGroup;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class UserGroupService {

    private UserGroupMapper userGroupMapper;
    private UserMenuAuthorityMapper userMenuAuthorityMapper;

    @Transactional(readOnly = true)
    public List<UserGroup> getAllUserGroups() {
        return userGroupMapper.selectGroups();
    }

    @Transactional(readOnly = true)
    public GroupUser getGroupUsers(Integer groupNo) {
        GroupUser groupUser = new GroupUser();

        List<User> users = userGroupMapper.selectGroupUsersAndNoGroupUsers(groupNo);

        users.stream().forEach(user -> {
            if (Objects.isNull(user.getGroupNo())) {
                groupUser.getUnmappingUsers().add(user);
            } else {
                groupUser.getMappingUsers().add(user);
            }
        });

        return groupUser;
    }

    @Transactional
    public void insertUserGroup(UserGroupParam param) {
        UserGroup userGroup = UserGroup.builder()
                .groupName(param.getGroupName())
                .build();
        userGroupMapper.insertGroup(userGroup);
    }

    @Transactional
    public void updateUserGroup(UserGroupParam param) {
        UserGroup userGroup = UserGroup.builder()
                .groupNo(param.getGroupNo())
                .groupName(param.getGroupName())
                .build();
        userGroupMapper.updateGroup(userGroup);
    }

    @Transactional
    public void deleteUserGroups(Integer... groupNos) {
        userGroupMapper.deleteUserGroups(groupNos);
        userGroupMapper.deleteUserGroupMappingsByGroupNos(groupNos);
        userMenuAuthorityMapper.deleteUserMenuAuthorityByGroupNos(groupNos);
    }

//    public List<UserGroupMap> fetchUserGroupMappings(Integer groupNo, Integer userNo) {
//        return userGroupMapper.selectUserGroupMappings(groupNo, userNo);
//    }

    @Transactional
    public void insertUserGroupMappings(Integer groupNo, Integer... userNos) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("groupNo", groupNo);
        map.put("userNos", userNos);
        userGroupMapper.insertUserGroupMappings(map);
    }

    @Transactional
    public void deleteUserGroupMappings(Integer groupNo, Integer... userNos) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("groupNo", groupNo);
        map.put("userNos", userNos);
        userGroupMapper.deleteUserGroupMappings(map);
    }


    //    @Transactional(readOnly = true)
//    public List<UserGroup> getUserGroupAllList(String userId) {
//        List<UserGroup> userGroupList = userGroupMapper.selectUserGroupMapList(userId);
//        return userGroupList;
//    }
//





}
