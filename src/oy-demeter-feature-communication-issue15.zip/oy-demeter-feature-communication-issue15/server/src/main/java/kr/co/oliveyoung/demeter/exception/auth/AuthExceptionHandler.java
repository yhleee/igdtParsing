package kr.co.oliveyoung.demeter.exception.auth;

import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice("kr.co.oliveyoung.oms.services.api")
public class AuthExceptionHandler {

    @ExceptionHandler(AuthException.class)
    @ResponseBody
    public ApiResponseMessage bindException(AuthException exception) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.FAIL, null, null);
        result.setMessage(exception.getMessage());
        result.setStatusCode(exception.getStatusCode());
        return result;
    }

}
