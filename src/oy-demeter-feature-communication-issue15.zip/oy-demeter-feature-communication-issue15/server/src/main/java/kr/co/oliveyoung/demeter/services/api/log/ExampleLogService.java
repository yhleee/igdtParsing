package kr.co.oliveyoung.demeter.services.api.log;

import kr.co.oliveyoung.demeter.common.enums.ExampleLogActionType;
import kr.co.oliveyoung.feature.log.ExampleLogMapper;
import lombok.AllArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class ExampleLogService {

    // private ExampleLogMapper exampleLogMapper;

    // TODO: 리팩토링 필요 DTO로 받는걸로 변경 아래 조건처리 모두 제거
    @Transactional
    public void insertExampleLog(Object result, JoinPoint joinPoint) {
        /*
        String actionType = null;
        if (joinPoint.getSignature().getName().equals("insertExample")) {
            actionType = ExampleLogActionType.INSERT.getActionType();
        } else if (joinPoint.getSignature().getName().equals("updateExample")) {
            actionType = ExampleLogActionType.UPDATE.getActionType();
        } else if (joinPoint.getSignature().getName().equals("deleteExample")) {
            actionType = ExampleLogActionType.DELETE.getActionType();
        }

        Example example = (Example) result;
        ExampleLog exampleLog = ExampleLog.builder()
                .actionType(actionType)
                .methodName(joinPoint.getSignature().getName())
                .exampleId(example.getId())
                .exampleName(example.getName())
                .exampleAge(example.getAge())
                .exampleTitle(example.getTitle())
                .exampleDescription(example.getDescription())
                .regUser(CommonVariable.loginId)
                .regDate(LocalDateTime.now())
                .build();

        exampleLogMapper.insertExampleLog(exampleLog);
         */
    }

}
