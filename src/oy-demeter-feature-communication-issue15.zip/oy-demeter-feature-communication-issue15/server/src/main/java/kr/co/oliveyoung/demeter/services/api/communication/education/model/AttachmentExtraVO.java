package kr.co.oliveyoung.demeter.services.api.communication.education.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentExtraVO extends BaseVO implements Serializable {

    private static final long serialVersionUID = 6047250010268096977L;
    private String url;
    private Long size;
    private Integer width;
    private Integer height;
    private String fileKey;
    private String expiredDatetime; //yyyyMMddHHmmss
    private String duration; //hh:mm:ss
}
