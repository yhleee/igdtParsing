package kr.co.oliveyoung.feature.settle;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CostCenter {

    private String costcenterCode;
    private String costcenterName;

}
