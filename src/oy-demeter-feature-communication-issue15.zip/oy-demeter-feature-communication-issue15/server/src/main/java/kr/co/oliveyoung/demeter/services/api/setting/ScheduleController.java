package kr.co.oliveyoung.demeter.services.api.setting;

import io.swagger.annotations.ApiOperation;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.setting.param.ScheduleFireWallDTO;
import kr.co.oliveyoung.demeter.services.api.setting.service.ScheduleService;
import kr.co.oliveyoung.feature.setting.model.ScheduleFireWall;
import lombok.AllArgsConstructor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("api/setting/schedule")
public class ScheduleController {

    private final ScheduleService scheduleService;

    @ApiOperation("알림 저장(FireWall)")
    @PostMapping("fireWalls")
    public ApiResponseMessage setScheduleFireWall(
        @RequestBody List<ScheduleFireWallDTO> fireWallList,
        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
//        if (!fireWallList.isEmpty()) {
//            for (ScheduleFireWallDTO scheduleFireWallDTO: fireWallList) {
//                scheduleService.setScheduleFireWall(scheduleFireWallDTO, tokenVO);
//            }
//        }
        return result;
    }

    @ApiOperation("알림 리스트")
    @GetMapping("fireWalls")
    public ApiResponseMessage getScheduleFireWall() {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        List<ScheduleFireWall> scheduleFireWallList = scheduleService.getScheduleFireWallList();

        for (ScheduleFireWall item: scheduleFireWallList) {
            result.setLastCreatedNo(item.getScheduleNo());
            break;
        }

        result.setContents(scheduleFireWallList);
        result.setTotalCnt(scheduleFireWallList.size());
        return result;
    }

}
