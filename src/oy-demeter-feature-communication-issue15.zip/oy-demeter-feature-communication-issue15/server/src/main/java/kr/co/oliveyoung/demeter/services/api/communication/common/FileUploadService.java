package kr.co.oliveyoung.demeter.services.api.communication.common;

import ch.qos.logback.core.util.FileUtil;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.codehaus.plexus.util.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class FileUploadService {

    private static final String ABSOLUTE_PATH_PREFIX = "/upload"; //nas absolute path
    private static final String RELATIVE_PATH_PREFIX = "/upload"; //cdn relative path

    public Pair<String, String> save(MultipartFile multipartFile) {
        String filePath = null;
        String fileUrl = null;
        try {
            // 파일 정보
            String originFilename = multipartFile.getOriginalFilename();
            String extension = FileUtils.getExtension(originFilename);
            Long size = multipartFile.getSize();

            // 서버에서 저장 할 파일 이름
            String saveFileName = randomFileName(extension);
            writeFile(multipartFile, saveFileName);
            filePath = getAbsolutePath() + saveFileName;
            fileUrl = getRelativePath() + saveFileName;
        } catch (IOException e) {
            log.error("파일 저장 오류 {}", e);
            throw new RuntimeException(e);
        }
        return Pair.of(filePath, fileUrl);
    }

    public void delete(List<String> filePaths) {
        for(String filePath : filePaths) {
            try {
                FileUtils.forceDelete(filePath);
            } catch (IOException e) {
                //do nothing
            }
        }
    }


    // 현재 시간을 기준으로 파일 이름 생성
    private String randomFileName(String extName) {
        long currentTime = System.currentTimeMillis();
        int randomInt = (int) (Math.random() * 100);
        return StringUtils.join(currentTime, randomInt, ".", extName);
    }

    private String getAbsolutePath() {
        return ABSOLUTE_PATH_PREFIX + "/" + getYmdPath() + "/";
    }

    private String getRelativePath() {
        return RELATIVE_PATH_PREFIX + "/" + getYmdPath() + "/";
    }

    private String getYmdPath() {
        return DateFormatUtils.format(new Date(), "yy/MM/dd");
    }

    // 파일을 실제로 write 하는 메서드
    private boolean writeFile(MultipartFile multipartFile, String saveFileName) throws IOException {
        FileOutputStream fos = null;
        try {
            FileUtil.createMissingParentDirectories(new File(getAbsolutePath() + saveFileName));
            byte[] data = multipartFile.getBytes();
            fos = new FileOutputStream(
                getAbsolutePath() + saveFileName);
            fos.write(data);
            fos.close();
            return true;
        } catch (IOException ioe) {
            throw ioe;
        } finally {
            if(fos != null) {
                fos.close();
            }
        }
    }
}
