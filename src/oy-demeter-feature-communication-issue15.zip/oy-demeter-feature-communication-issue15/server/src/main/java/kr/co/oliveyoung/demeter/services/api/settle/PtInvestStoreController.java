package kr.co.oliveyoung.demeter.services.api.settle;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import kr.co.oliveyoung.demeter.common.csv.FileFactory;
import kr.co.oliveyoung.demeter.common.csv.download.FileDownloader;
import kr.co.oliveyoung.demeter.common.csv.upload.FileDBInsertParser;
import kr.co.oliveyoung.demeter.common.enums.ResponseResult;
import kr.co.oliveyoung.demeter.common.model.AccessTokenVO;
import kr.co.oliveyoung.demeter.common.model.ApiResponseMessage;
import kr.co.oliveyoung.demeter.services.api.settle.param.PtInvestStoreListParam;
import kr.co.oliveyoung.demeter.services.api.settle.service.PtInvestStoreService;
import kr.co.oliveyoung.feature.settle.PtInvestStore;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("api/settle")
public class PtInvestStoreController {

    private final PtInvestStoreService ptInvestStoreService;

    @ApiOperation("업체 정산 담당자 투자(매장) 정산 리스트")
    @GetMapping("ptInvestStores")
    public ApiResponseMessage getPtInvestStoreList(
        PtInvestStoreListParam param
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, null, null);
        result.setContents(ptInvestStoreService.getPtInvestStoreList(1, 100000, param));
        return result;
    }

//    @ApiOperation("업체 정산 담당자 투자(매장) 정산 리스트 엑셀 업로드")
//    @PostMapping("ptInvestStores/excelUpLoad")
//    public ApiResponseMessage ptInvestStoreExcelUpLoad(
//        @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart(required = true) MultipartFile uploadFile,
//        PtInvestStoreListParam param,
//        @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
//    ) {
//        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드가 완료되었습니다.", null);
//
//        try {
//            Map<String, String> retMap = ptInvestStoreService.setExcelParseInvestStore(uploadFile, param, tokenVO);
//            result.setMessage(retMap.get("msg"));
//            result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);
//        } catch (Exception e) {
//            log.info("ptInvestStoreExcelUpLoad ERROR !!", e);
//        }
//
//        /*
//        try {
//            FileFactory fileFactory = new FileFactory();
//            FileDBInsertParser fileDBInsertParser = fileFactory.fileDBInsert("csv", uploadFile);
//            List<Map<String, Object>> parseAssetList = fileDBInsertParser.getParsePtInvestStoreList();
//            Map<String, String> retMap = ptInvestStoreService.setCSVParseInvestStore(parseAssetList, param);
//            result.setMessage(retMap.get("msg"));
//            result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);
//        } catch (Exception e) {
//            log.info("ptInvestStoreExcelUpLoad ERROR !!", e);
//        }
//         */
//
//        return result;
//    }

    @ApiOperation("업체 정산 담당자 투자(매장) 정산 리스트 엑셀 업로드 (DRM)")
    @PostMapping("ptInvestStores/drmExcelUpLoad")
    public ApiResponseMessage ptInvestStoreDrmExcelUpLoad(
            @ApiParam(value = "csv 파일", name = "uploadFile", required = true) @RequestPart MultipartFile uploadFile,
            PtInvestStoreListParam param,
            @RequestAttribute("accessTokenVO") AccessTokenVO tokenVO
    ) {
        ApiResponseMessage result = new ApiResponseMessage(ResponseResult.SUCCESS, "업로드가 완료되었습니다.", null);

        try {
            Map<String, String> retMap = ptInvestStoreService.setDrmExcelParseInvestStore(uploadFile, param, tokenVO);
            result.setMessage(retMap.get("msg"));
            result.setResult(retMap.get("result").equals("FAIL") ? ResponseResult.FAIL : ResponseResult.SUCCESS);
        } catch (Exception e) {
            log.info("ptInvestStoreDrmExcelUpLoad ERROR !!", e);
        }

        return result;
    }

    @ApiOperation("업체 정산 담당자 투자(매장) 정산 리스트 엑셀 다운로드")
    @GetMapping("ptInvestStores/excelDownLoad")
    public void ptInvestStoreExcelDownLoad(
        HttpServletResponse response,
        PtInvestStoreListParam param
    ) {
        // Excel
        try {
            List<PtInvestStore> ptInvestStoreList = ptInvestStoreService.getPtInvestStoreList(1, 100000, param);

            Workbook wb = new HSSFWorkbook();
            Sheet sheet = wb.createSheet("pt_invest_store");
            Row row = null;
            Cell cell = null;
            int rowNo = 0;

            // header
            CellStyle headStyle = wb.createCellStyle();

            // 경계선
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);

            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 데이터는 가운데 정렬합니다.
            headStyle.setAlignment(HorizontalAlignment.CENTER);

            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);

            // 1depth headers
            row = sheet.createRow(rowNo++);

            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("매장명");

            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("신규/리뉴얼(1:신규점 / 2:리뉴얼)");

            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("메뉴 카테고리(1:RACK / 2:VPN / 3:IC단말기 / 4:CJ올리브네트웍스)");

            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("장비명");

            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("수량");

            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("단가");

            cell = row.createCell(6);
            cell.setCellStyle(headStyle);
            cell.setCellValue("비고");

            // 2depth headers
            row = sheet.createRow(rowNo++);

            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_NAME");

            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_TYPE");

            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_CATEGORY_NO");

            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_ASSET_NO");

            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_COUNT");

            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_PRICE");

            cell = row.createCell(6);
            cell.setCellStyle(headStyle);
            cell.setCellValue("INVEST_STORE_REMARKS");

            // Output Data
            for(PtInvestStore ptInvestStore: ptInvestStoreList) {
                row = sheet.createRow(rowNo++);
                cell = row.createCell(0);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreName())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(1);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreType())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(2);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreCategoryNo())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(3);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreAssetNo())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(4);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreCount())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(5);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStorePrice())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );

                cell = row.createCell(6);
                cell.setCellStyle(bodyStyle);
                cell.setCellValue(Optional.ofNullable(ptInvestStore.getInvestStoreRemarks())
                        .map(String::valueOf)
                        .orElse("")
                        .trim()
                );
            }

            // 컨텐츠 타입과 파일명 지정
            response.setContentType("ms-vnd/excel");
            response.setHeader("Content-Disposition", "attachment;filename=pt_invest_store.xls");

            // 엑셀 출력
            wb.write(response.getOutputStream());
            wb.close();
        } catch (Exception e) {
            log.info("ptInvestStoreExcelDownLoad ERROR !!", e);
        }


        /* CSV
        int page = 1;
        int size = 5000;
        FileFactory fileFactory = new FileFactory();
        try (FileDownloader fileDownloader = fileFactory.fileDownloader("csv", response)) {
            while (true) {
                List<PtInvestStore> ptInvestStoreList = ptInvestStoreService.getPtInvestStoreList(page, size, param);
                if (ptInvestStoreList.isEmpty()) {
                    break;
                }

                fileDownloader.ptInvestStoreListPartDown(ptInvestStoreList, page);
                page++;
            }
        } catch (Exception e) {
            log.info("ptInvestStoreExcelDownLoad ERROR !!", e);
        }
         */
    }

    @ApiOperation("업체 정산 담당자 투자(매장) 정산 데이터 업로드 활성화 변경")
    @PatchMapping("ptInvestStores/investStoreActiveType")
    public ApiResponseMessage updateActiveUser(
            @RequestParam("investStoreActiveType") String investStoreActiveType
    ) {
        ApiResponseMessage result = new ApiResponseMessage(
            ResponseResult.SUCCESS,
            ptInvestStoreService.updateInvestStoreActiveType(investStoreActiveType),
            null
        );
        return result;
    }

}
