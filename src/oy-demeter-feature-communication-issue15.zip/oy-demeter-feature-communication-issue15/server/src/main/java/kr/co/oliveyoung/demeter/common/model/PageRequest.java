package kr.co.oliveyoung.demeter.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PageRequest {
    private int page = 1;
    private int pageSize = 20;
    private int totalCount = Integer.MAX_VALUE;

    public int getOffset() {
        if(page <= 1) {
            return 0;
        }
        return pageSize * (page - 1);
    }

    public boolean isValidPage() {
        return (page - 1) * pageSize < totalCount;
    }
}
