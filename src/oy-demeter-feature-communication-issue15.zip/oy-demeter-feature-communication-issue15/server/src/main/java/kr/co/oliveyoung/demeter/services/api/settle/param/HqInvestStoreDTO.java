package kr.co.oliveyoung.demeter.services.api.settle.param;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class HqInvestStoreDTO {

    // Invest Store
    private String investStoreName;
    private String investStoreOpenDate;
    private Integer investStoreType;
    private String investStoreRemarks;

    // Re Invest Store Asset
    private Integer reInvestStoreAssetRack;
    private Integer reInvestStoreAssetVpn;
    private Integer reInvestStoreAssetLed;
    private Integer reInvestStoreAssetSettopPc;
    private Integer reInvestStoreAssetPos;
    private Integer reInvestStoreAssetSurgeProtector;
    private Integer reInvestStoreAssetHub;
    private Integer reInvestStoreAssetHandScanner;
    private Integer reInvestStoreAssetPda;
    private Integer reInvestStoreAssetSignPad;
    private Integer reInvestStoreAssetCat;
    private Integer reInvestStoreAssetSwitch;
    private Integer reInvestStoreAssetIcTerminal;

    // New Invest Store Asset
    private Integer newInvestStoreAssetRack;
    private Integer newInvestStoreAssetVpn;
    private Integer newInvestStoreAssetLed;
    private Integer newInvestStoreAssetSettopPc;
    private Integer newInvestStoreAssetPos;
    private Integer newInvestStoreAssetSurgeProtector;
    private Integer newInvestStoreAssetHub;
    private Integer newInvestStoreAssetHandScanner;
    private Integer newInvestStoreAssetPda;
    private Integer newInvestStoreAssetSignPad;
    private Integer newInvestStoreAssetCat;
    private Integer newInvestStoreAssetSwitch;
    private Integer newInvestStoreAssetIcTerminal;

    public HqInvestStoreDTO(
        String investStoreName,
        String investStoreOpenDate,
        Integer investStoreType,
        String investStoreRemarks,
        Integer reInvestStoreAssetRack,
        Integer reInvestStoreAssetVpn,
        Integer reInvestStoreAssetLed,
        Integer reInvestStoreAssetSettopPc,
        Integer reInvestStoreAssetPos,
        Integer reInvestStoreAssetSurgeProtector,
        Integer reInvestStoreAssetHub,
        Integer reInvestStoreAssetHandScanner,
        Integer reInvestStoreAssetPda,
        Integer reInvestStoreAssetSignPad,
        Integer reInvestStoreAssetCat,
        Integer reInvestStoreAssetSwitch,
        Integer reInvestStoreAssetIcTerminal,
        Integer newInvestStoreAssetRack,
        Integer newInvestStoreAssetVpn,
        Integer newInvestStoreAssetLed,
        Integer newInvestStoreAssetSettopPc,
        Integer newInvestStoreAssetPos,
        Integer newInvestStoreAssetSurgeProtector,
        Integer newInvestStoreAssetHub,
        Integer newInvestStoreAssetHandScanner,
        Integer newInvestStoreAssetPda,
        Integer newInvestStoreAssetSignPad,
        Integer newInvestStoreAssetCat,
        Integer newInvestStoreAssetSwitch,
        Integer newInvestStoreAssetIcTerminal
    ) {
        this.investStoreName = investStoreName;
        this.investStoreOpenDate = investStoreOpenDate;
        this.investStoreType = investStoreType;
        this.investStoreRemarks = investStoreRemarks;
        this.reInvestStoreAssetRack = reInvestStoreAssetRack;
        this.reInvestStoreAssetVpn = reInvestStoreAssetVpn;
        this.reInvestStoreAssetLed = reInvestStoreAssetLed;
        this.reInvestStoreAssetSettopPc = reInvestStoreAssetSettopPc;
        this.reInvestStoreAssetPos = reInvestStoreAssetPos;
        this.reInvestStoreAssetSurgeProtector = reInvestStoreAssetSurgeProtector;
        this.reInvestStoreAssetHub = reInvestStoreAssetHub;
        this.reInvestStoreAssetHandScanner = reInvestStoreAssetHandScanner;
        this.reInvestStoreAssetPda = reInvestStoreAssetPda;
        this.reInvestStoreAssetSignPad = reInvestStoreAssetSignPad;
        this.reInvestStoreAssetCat = reInvestStoreAssetCat;
        this.reInvestStoreAssetSwitch = reInvestStoreAssetSwitch;
        this.reInvestStoreAssetIcTerminal = reInvestStoreAssetIcTerminal;
        this.newInvestStoreAssetRack = newInvestStoreAssetRack;
        this.newInvestStoreAssetVpn = newInvestStoreAssetVpn;
        this.newInvestStoreAssetLed = newInvestStoreAssetLed;
        this.newInvestStoreAssetSettopPc = newInvestStoreAssetSettopPc;
        this.newInvestStoreAssetPos = newInvestStoreAssetPos;
        this.newInvestStoreAssetSurgeProtector = newInvestStoreAssetSurgeProtector;
        this.newInvestStoreAssetHub = newInvestStoreAssetHub;
        this.newInvestStoreAssetHandScanner = newInvestStoreAssetHandScanner;
        this.newInvestStoreAssetPda = newInvestStoreAssetPda;
        this.newInvestStoreAssetSignPad = newInvestStoreAssetSignPad;
        this.newInvestStoreAssetCat = newInvestStoreAssetCat;
        this.newInvestStoreAssetSwitch = newInvestStoreAssetSwitch;
        this.newInvestStoreAssetIcTerminal = newInvestStoreAssetIcTerminal;
    }

}
