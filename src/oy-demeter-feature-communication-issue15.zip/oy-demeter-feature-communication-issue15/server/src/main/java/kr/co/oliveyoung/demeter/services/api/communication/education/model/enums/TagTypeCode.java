package kr.co.oliveyoung.demeter.services.api.communication.education.model.enums;

import lombok.Getter;
import org.apache.commons.lang.StringUtils;

@Getter
public enum TagTypeCode {
    MENU("MENU", "메뉴타입 태그"),
    KEYWORD("KEYWORD", "관심키워드 태그"),
    USER("USER", "사용자 입력 태그");

    private String code;
    private String text;

    TagTypeCode(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public static TagTypeCode codeOf(String code) {
        for(TagTypeCode tagTypeCode: TagTypeCode.values()) {
            if(StringUtils.equalsIgnoreCase(tagTypeCode.getCode(), code)) {
                return tagTypeCode;
            }
        }
        return null;
    }
}
