package kr.co.oliveyoung.feature.setting.model;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Getter
public class UserGroupMap {

    private Integer groupNo;
    private Integer userNo;

    @Builder
    public UserGroupMap(Integer groupNo, Integer userNo) {
        this.groupNo = groupNo;
        this.userNo = userNo;
    }

}
