package kr.co.oliveyoung.demeter.services.api.setting.param;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Getter
@NoArgsConstructor
public class ScheduleFireWallDTO {

    @NotNull @NotEmpty(message = "몰라111")
    private String scheduleSystemName;

    @NotNull @NotEmpty(message = "몰라222")
    private String schedulePurpose;

    @NotNull @NotEmpty(message = "몰라333")
    private String sourceIp;

    @NotNull @NotEmpty(message = "몰라44")
    private String destinationIp;

    @NotNull @NotEmpty
    private String port;

    @NotNull @NotEmpty
    private String policyStartDate;

    @NotNull @NotEmpty
    private String policyEndDate;

    @NotNull @NotEmpty
    private String policyNoticeDate;

    private String docNumber;

    public ScheduleFireWallDTO(
        String scheduleSystemName,
        String schedulePurpose,
        String sourceIp,
        String destinationIp,
        String port,
        String policyStartDate,
        String policyEndDate,
        String policyNoticeDate,
        String docNumber
    ) {
        this.scheduleSystemName = scheduleSystemName;
        this.schedulePurpose = schedulePurpose;
        this.sourceIp = sourceIp;
        this.destinationIp = destinationIp;
        this.port = port;
        this.policyStartDate = policyStartDate;
        this.policyEndDate = policyEndDate;
        this.policyNoticeDate = policyNoticeDate;
        this.docNumber = docNumber;
    }

}
