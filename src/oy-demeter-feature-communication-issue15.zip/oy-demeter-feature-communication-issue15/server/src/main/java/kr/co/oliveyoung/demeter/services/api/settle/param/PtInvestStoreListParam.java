package kr.co.oliveyoung.demeter.services.api.settle.param;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PtInvestStoreListParam {

    private Integer investStoreCategoryNo;
    private String investStoreName;

}
