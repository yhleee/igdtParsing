import { Paths } from './paths'

export interface BuildConfiguration {
  paths: Paths
  webpackConfig: any
}
