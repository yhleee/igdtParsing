export enum ResponseResult {
    SUCCESS = 'SUCCESS',
    FAIL = 'FAIL',
}