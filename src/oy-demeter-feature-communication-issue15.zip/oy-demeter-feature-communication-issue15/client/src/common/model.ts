import { UserInfoState } from '../components/Layout/ducks/UserInfo'

export const loginInfo: UserInfoState = {
  name: null,
  id: null,
  storeCode: null,
  token: null,
}
