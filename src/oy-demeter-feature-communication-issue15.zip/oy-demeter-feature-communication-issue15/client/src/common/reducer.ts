import { combineReducers } from 'redux'
import layoutTitle, { LayoutTitleState } from 'components/Layout/ducks/LayoutTitle'
import userInfo, { UserInfoState } from 'components/Layout/ducks/UserInfo'

export interface RootState {
  layoutTitle: LayoutTitleState
  userInfo: UserInfoState
}

export default combineReducers({
  layoutTitle,
  userInfo,
})
