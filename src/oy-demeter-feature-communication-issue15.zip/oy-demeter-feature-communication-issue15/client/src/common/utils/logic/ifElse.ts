export const ifElse = condition => (then, or) => condition ? then : or
