import { axios } from '../utils'

export const getSelect = async (params: any) => {
  params['query'] = encodeURIComponent(params.query)
  const response = await axios.get('/api/querybrowser/select', {
    params,
  })
  return response && response.data && response.data.contents
}
