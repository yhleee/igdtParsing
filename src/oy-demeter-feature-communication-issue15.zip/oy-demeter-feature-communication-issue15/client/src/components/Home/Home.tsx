import * as React from 'react'
import { Row, Col, Card, Icon, Table, Typography, Divider } from 'antd'
import { DynamicCx } from 'common/types'
const { Text } = Typography

interface OwnProps {
  cx?: DynamicCx
}

interface OwnState {
  authority: any
}

type Props = OwnProps

class Home extends React.Component<Props, OwnState> {
  constructor(props) {
    super(props)
    this.state = {
      authority: [
        {
          key: '1',
          name: '관리자',
          desc: '모든 메뉴 접근 및 권한설정 가능',
        },
        {
          key: '2',
          name: '외부업체',
          desc: '신규/리뉴얼 매장 장비 투자(업체별) 메뉴만 접근가능',
        },
      ],
    }
  }

  async componentDidMount() {}

  componentWillUnmount() {}

  render() {
    const { authority } = this.state
    const columns = [
      {
        title: '권한명',
        dataIndex: 'name',
        key: 'name',
      },
      {
        title: '설명',
        dataIndex: 'desc',
        key: 'desc',
      },
    ]

    return (
      <div>
        <Row gutter={16}>
          <Col className="gutter-row" span={24}>
            <div className="gutter-box">
              <Divider orientation="left">Notice</Divider>
              <p>
                - 정보전략팀 투자/비용 취합 :{' '}
                <b>
                  <Text type={`warning`}>취합 요청(21日) > 등록 납기일(27日)</Text>
                </b>
              </p>
              <p>
                - 신규/리뉴얼 매장 장비 투자(본사) :{' '}
                <b>
                  <Text type={`warning`}>등록 및 업체등록요청(16日) > 대사작업후 확정(25日)</Text>
                </b>
              </p>
              <p>
                - 신규/리뉴얼 매장 장비 투자(업체별) :{' '}
                <b>
                  <Text type={`warning`}>등록 납기일(20日)</Text>
                </b>
              </p>
            </div>
          </Col>
          {/*<Col className="gutter-row" span={6}>
            <div className="gutter-box">
              <Divider orientation="left">사용자 정보</Divider>
              <Card
                style={{ width: 240, marginTop: 16 }}
                cover={<img alt="example" src="/images/om_logo.png" />}
                actions={[
                  <Icon type="setting" key="setting" />,
                  <Icon type="edit" key="edit" />,
                  <Icon type="ellipsis" key="ellipsis" />,
                ]}
              >
              </Card>
            </div>
          </Col>
          <Col className="gutter-row" span={12}>
            <div className="gutter-box">
              <Divider orientation="left">보유 권한목록</Divider>
              <Table dataSource={authority} columns={columns} />
            </div>
          </Col>
          <Col className="gutter-row" span={6}>
            <div className="gutter-box">
              <Divider orientation="left">필독</Divider>
              <div>
                <Text type={`warning`}>메뉴 접근 권한이 필요하시면 관리자에게 문의 부탁드립니다.</Text>
              </div>
            </div>
          </Col>*/}
        </Row>
      </div>
    )
  }
}

export default Home
