import * as React from 'react'
import RegistrationForm from './RegistrationForm'
import { Col, Layout, Row } from 'antd'
const { Header, Content, Footer } = Layout

interface IProps {}
interface IState {}

class Registration extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
  }

  render() {
    return (
      <>
        <Layout>
          <Header className="header">
            <Row>
              <Col xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }} />
            </Row>
          </Header>
          <Content
            style={{
              background: '#fff',
              padding: 24,
              margin: 0,
              minHeight: 280,
            }}
          >
            <div>
              <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
                <div style={{ display: 'table', width: '100%' }}>
                  <img src="/images/om_logo.png" />
                </div>
                <RegistrationForm />
              </div>
            </div>
          </Content>
          <Footer>
            <span>ⓒCJ OliveYoung</span>
          </Footer>
        </Layout>
      </>
    )
  }
}

export default Registration
