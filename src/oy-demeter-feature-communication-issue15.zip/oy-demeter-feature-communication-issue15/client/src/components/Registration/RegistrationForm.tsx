import * as React from 'react'
import { Button, Col, Form, Icon, Input, Row } from 'antd'
import * as styles from './Registration.scss'
import { setUser } from '../../services/login/user'
import { alertPopup } from '../../common/utils'
import { Base64 } from 'js-base64'

interface IProps {
  form: any
}

interface IState {}

class RegistrationForm extends React.Component<IProps, IState> {
  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields(async (err, values) => {
      const userData = {
        loginCode1: Base64.encode(values.loginId),
        loginCode2: Base64.encode(values.password),
        loginIp: '127.0.0.1',
      }
      await setUser(userData).then(response => {
        if (response === 'SUCCESS') {
          window.location.assign('/app/login')
        }

        alertPopup('가입실패')
      })

      if (!err) {
        // const response = await login(values)
        // if (response && response.result === 'SUCCESS') {
        //   // redirect to home
        // } else {
        //   Modal.error({
        //     title: '로그인 실패',
        //     content: response.message,
        //   })
        // }
      }
    })
  }

  render() {
    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    }

    const { getFieldDecorator } = this.props.form

    return (
      <Form onSubmit={this.handleSubmit} className={styles.loginForm}>
        <Form.Item label="로그인 ID" {...formItemLayout}>
          {getFieldDecorator('loginId', {
            rules: [{ required: true, message: 'Please input your username!' }],
          })(<Input prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />} placeholder="LoginId" />)}
        </Form.Item>
        <Form.Item label="비밀번호" {...formItemLayout}>
          {getFieldDecorator('password', {
            rules: [{ required: true, message: 'Please input your Password!' }],
          })(
            <Input
              prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
              type="password"
              placeholder="Password"
            />,
          )}
        </Form.Item>
        <Form.Item label="비밀번호 확인" {...formItemLayout}>
          {getFieldDecorator('passwordCheck', {
            rules: [{ required: true, message: 'Please input your PasswordCheck!' }],
          })(
            <Input
              prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
              type="password"
              placeholder="password Check"
            />,
          )}
        </Form.Item>
        <Form.Item {...buttonItemLayout}>
          <Row>
            <Col span={24} style={{ textAlign: 'center' }}>
              <Button type="primary" htmlType="submit" className={styles.registrationFormButton}>
                Registration
              </Button>
            </Col>
          </Row>
        </Form.Item>
      </Form>
    )
  }
}

export default Form.create()(RegistrationForm)
