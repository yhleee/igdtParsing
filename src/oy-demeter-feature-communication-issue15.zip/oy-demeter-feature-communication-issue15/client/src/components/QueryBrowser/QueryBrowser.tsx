import * as React from 'react'
import {
  Table,
  Divider,
  Button,
  Select,
  Input,
  Typography,
  Checkbox,
  Collapse,
  Skeleton,
  Spin,
  Switch,
  Icon,
  notification,
  message,
  Row,
  Col,
  Layout,
  Modal,
  Tag,
} from 'antd'
import { getSelect } from 'common/services/queryBrowser'
import { DynamicCx } from 'common/types'
import * as s from './QueryBrowser.scss'
import { styling } from 'common/utils'

const { Header, Content, Footer } = Layout
const { TextArea } = Input
const { Title } = Typography
const { Option } = Select
const { Panel } = Collapse

interface OwnProps {
  cx?: DynamicCx
}

interface OwnState {
  columns: object[]
  datasource: object[]
  tables: string[]
  checkColumns: any[]
  selectTableName: string
  loading: boolean
  autoComplete: boolean
  modalVisible: boolean
  confirmLoading: boolean
  explainColumns: object[]
  explainData: object[]
}

type Props = OwnProps

class QueryBrowser extends React.Component<Props, OwnState> {
  queryEditorEl: any
  tableSelectEl: any
  columnCheckEl: any
  columnOrderArray: string[]

  constructor(props) {
    super(props)
    this.state = {
      columns: [],
      datasource: [],
      tables: [],
      checkColumns: [],
      selectTableName: null,
      loading: false,
      autoComplete: false,
      modalVisible: false,
      confirmLoading: false,
      explainColumns: [],
      explainData: [],
    }
    this.queryEditorEl = React.createRef()
    this.tableSelectEl = React.createRef()
    this.columnCheckEl = React.createRef()
  }
  async componentDidMount() {
    await this.getTables()
  }

  componentWillUnmount() {}

  getTables = async () => {
    const result: object[] = await getSelect({
      query: 'show tables',
    })
    if (result && result.length > 0) {
      const tables = []
      result.forEach(obj => {
        for (let [key, value] of Object.entries(obj)) {
          tables.push(value)
        }
      })
      this.setState({ tables })
    }
  }

  selectTable = async tableName => {
    this.queryEditorEl.current.textAreaRef.value = `SELECT * \rFROM ${tableName}`
    const result: object[] = await getSelect({
      query: `SELECT column_name, column_comment FROM information_schema.columns WHERE table_name = '${tableName}'`,
    })
    if (result && result.length > 0) {
      const checkColumns = []
      result.forEach(obj => {
        const comment =
          obj['column_comment'] && obj['column_comment'] !== '' && obj['column_comment'] !== obj['column_name']
            ? ` AS '${obj['column_comment']}'`
            : ''

        const columnName = `${obj['column_name']}${comment}`
        checkColumns.push({
          value: columnName,
          label: columnName,
        })
      })
      this.setState({
        checkColumns,
        selectTableName: tableName,
      })
    }
  }

  handleCheckColumns = (selectColumnNames: string[]) => {
    const { selectTableName } = this.state
    const queryString = []
    queryString.push('SELECT \r  ')
    if (selectTableName.length > 0 && selectColumnNames.length > 0) {
      queryString.push(selectColumnNames.join(',\r  '))
    } else {
      queryString.push(' * ')
    }
    queryString.push('\r')
    queryString.push(`FROM ${selectTableName}`)
    this.queryEditorEl.current.textAreaRef.value = queryString.join('')
  }

  getColumnList = async (tableName: string) => {
    const result: string[] = []
    const columnList: object[] = await getSelect({
      query: `show full columns from ${tableName}`,
    })
    if (columnList && columnList.length > 0) {
      columnList.forEach(column => {
        result.push(column['Field'])
      })
    }
    return result
  }

  generateQueryResult = (queryResult: object[]) => {
    if (queryResult && queryResult.length > 0) {
      let columns = []
      const datasource = []
      if (this.columnOrderArray.length > 0) {
        this.columnOrderArray.forEach(columnName => {
          columns.push({
            key: columnName,
            title: columnName,
            dataIndex: columnName,
          })
        })
      }
      queryResult.forEach((result, index) => {
        if (columns.length === 0) {
          const tempColumns = []
          for (let [key, value] of Object.entries(result)) {
            tempColumns.push({
              key,
              title: key,
              dataIndex: key,
            })
          }
          if (tempColumns.length > columns.length) {
            columns = tempColumns
          }
        }
        result['key'] = index + 1
        datasource.push(result)
      })
      this.setState({
        datasource,
        columns,
        loading: false,
      })
    }
  }

  generateExplainResult = (queryResult: object[]) => {
    if (queryResult && queryResult.length > 0) {
      let explainColumns = []
      const explainData = []

      queryResult.forEach((result, index) => {
        const tempColumns = []
        for (let [key, value] of Object.entries(result)) {
          tempColumns.push({
            key,
            title: key,
            dataIndex: key,
          })
        }
        if (tempColumns.length > explainColumns.length) {
          explainColumns = tempColumns
        }
        result['key'] = index + 1
        explainData.push(result)
      })
      this.setState({
        explainColumns,
        explainData,
        modalVisible: true,
      })
    }
  }

  handleQueryReset = () => {
    this.queryEditorEl.current.textAreaRef.value = ''
    this.tableSelectEl.current.rcSelect.state.value = ''
    // this.columnCheckEl.current.state.value = []
    this.setState({
      columns: [],
      datasource: [],
    })
  }

  handleQueryInput = () => {
    if (!this.state.autoComplete) {
      return
    }
    const query = this.queryEditorEl.current.textAreaRef.value
    if (query) {
      const queryArray = query.split('\n')
      let lastInput = queryArray[queryArray.length - 1]
      if (lastInput === 'sele' || lastInput === 'SELE') {
        queryArray[queryArray.length - 1] = 'SELECT '
      } else if (lastInput === 'fro' || lastInput === 'FRO') {
        if (queryArray.length == 1) {
          queryArray[queryArray.length - 1] = 'SELECT * \nFROM '
        } else {
          queryArray[queryArray.length - 1] = 'FROM '
        }
      } else if (lastInput === 'whe' || lastInput === 'WHE') {
        queryArray[queryArray.length - 1] = 'WHERE '
      } else if (lastInput === 'grou' || lastInput === 'GROU') {
        queryArray[queryArray.length - 1] = 'GROUP BY '
      } else if (lastInput === 'orde' || lastInput === 'ORDE') {
        queryArray[queryArray.length - 1] = 'ORDER BY '
      } else if (lastInput === 'limit' || lastInput === 'LIMIT') {
        queryArray[queryArray.length - 1] = ''
        notification.open({
          key: 'noti_unacceptable_query',
          message: '사용할 수 없는 명령어 안내',
          description: 'LIMIT 쿼리는 사용할 수 없습니다.기본설정에서 최대 1,000건으로 조회수를 제한하고 있습니다.',
        })
      }
      this.queryEditorEl.current.textAreaRef.value = queryArray.join('\n')
    }
  }

  removeBlank = (text: string) => {
    let result = text.replace(/(?:\r\n|\r|\n)/g, '')
    result = result.replace(/ /g, '')
    return result
  }

  generateColumnArray = (columnArray: string[]) => {
    const resultArray: string[] = []
    let tempColumnName = ''
    let openCount = 0
    columnArray.forEach(column => {
      openCount = openCount + column.split('(').length - 1
      const closeCount = column.split(')').length - 1
      openCount = openCount - closeCount
      tempColumnName = tempColumnName + (tempColumnName === '' ? '' : ',') + column
      if (openCount === 0) {
        resultArray.push(tempColumnName)
        tempColumnName = ''
      }
    })
    return resultArray
  }

  handleQuerySend = async () => {
    this.columnOrderArray = []
    let query: string = this.queryEditorEl.current.textAreaRef.value
    if (!query) {
      message.error('쿼리를 입력 해 주세요.')
      return
    }
    this.setState({ loading: true })
    const lowerQuery = query.toLowerCase()
    if (lowerQuery.indexOf('select') > -1 && lowerQuery.indexOf('from') > -1) {
      const selectStart = (query.indexOf('select') > -1 ? query.indexOf('select') : query.indexOf('SELECT')) + 6
      const selectEnd = query.indexOf('from') > -1 ? query.indexOf('from') : query.indexOf('FROM')
      const columnText = query.substring(selectStart, selectEnd)
      const pureColumnText = this.removeBlank(columnText)
      if (pureColumnText.indexOf('*') === -1 || (pureColumnText.indexOf('*') > -1 && pureColumnText.length > 1)) {
        let columnArray = columnText.split(',')
        columnArray = this.generateColumnArray(columnArray)
        columnArray.forEach(column => {
          console.log(`column: ${column}`)
          let columnName = null
          let filteredColumn = column
          if (filteredColumn.indexOf(')') > -1) {
            const lastFuncPosition = filteredColumn.lastIndexOf(')') + 1
            filteredColumn = filteredColumn.substring(lastFuncPosition)
            let checkColumn = filteredColumn.replace(/(?:\r\n|\r|\n)/g, '')
            checkColumn = checkColumn.replace(/ /g, '')
            if (checkColumn.length === 0 || checkColumn === ' ') {
              filteredColumn = column
            }
          }
          if (filteredColumn.indexOf(' as ') > -1 || filteredColumn.indexOf(' AS ') > -1) {
            const columnNameStart =
              (filteredColumn.indexOf(' as ') > -1 ? filteredColumn.indexOf(' as ') : filteredColumn.indexOf(' AS ')) +
              4
            columnName = filteredColumn.substring(columnNameStart)
            columnName = columnName.replace(/(?:\r\n|\r|\n)/g, '')
            columnName = columnName.replace(/ /g, '')

            if (columnName.indexOf("'") > -1) {
              const columnNameStart = columnName.indexOf("'") + 1
              const columnNameEnd = columnName.lastIndexOf("'")
              columnName = columnName.substring(columnNameStart, columnNameEnd)
            } else if (columnName.indexOf('"') > -1) {
              const columnNameStart = columnName.indexOf('"') + 1
              const columnNameEnd = columnName.lastIndexOf('"')
              columnName = columnName.substring(columnNameStart, columnNameEnd)
            }
          } else {
            columnName = filteredColumn.replace(/(?:\r\n|\r|\n)/g, '')
            columnName = columnName.replace(/(^\s*)|(\s*$)/gi, '')
            const lastBlankPosition = columnName.lastIndexOf(' ')
            if (lastBlankPosition > -1) {
              columnName = columnName.substring(lastBlankPosition + 1)
              columnName = columnName.replace(/(^\s*)|(\s*$)/gi, '')
            }
            columnName = columnName.replace(/['"]/g, '')
            console.log(`columnName: ${columnName}`)
          }

          const dotPosition = columnName.indexOf('.')
          if (dotPosition > -1) {
            columnName = columnName.substring(dotPosition + 1)
          }
          this.columnOrderArray.push(columnName)
        })
      } else {
        // const lastFromPosition = query.toLowerCase().lastIndexOf('from') + 5
        // const lastWherePosition = query.toLowerCase().lastIndexOf('where')
        // let tableName = query.substring(lastFromPosition, lastWherePosition)
        // tableName = tableName.replace(/(^\s*)|(\s*$)/gi, '')
        // const columnList = await this.getColumnList(tableName)
        // if (columnList) {
        //   this.columnOrderArray = columnList
        // }
      }
    }
    if (query.toLowerCase().indexOf('select') > -1) {
      query = query.replace(';', '')
      query = query + ' limit 1000'
    }
    const queryResult = await this.sendQuery(query)
    if (queryResult) {
      this.generateQueryResult(queryResult)
    }
  }

  sendQuery = async (query: string) => {
    const params = {
      query,
    }
    try {
      const result = await getSelect(params)
      if (result) {
        return result
      }
    } catch (e) {
      this.setState({ loading: false })
    }
  }

  handleAutoComplete = checked => {
    let cont = '쿼리 자동완성 기능을 사용하지 않습니다.'
    if (checked) {
      cont = '쿼리 자동완성 기능을 사용합니다.'
    }
    message.info(cont)
    this.setState({ autoComplete: checked })
  }

  keyPress = event => {
    if (event.key == '\n') {
      this.handleQuerySend()
    }
  }

  handleExplain = async () => {
    let query: string = this.queryEditorEl.current.textAreaRef.value
    if (!query) {
      message.error('쿼리를 입력 해 주세요.')
      return
    }
    const explainResult = await this.sendQuery(`EXPLAIN\n${query}`)
    if (explainResult) {
      this.generateExplainResult(explainResult)
    }
  }

  handleModalOk = () => {
    this.setState({ modalVisible: false })
  }

  render() {
    const { cx } = this.props
    const {
      columns,
      datasource,
      tables,
      checkColumns,
      modalVisible,
      confirmLoading,
      explainColumns,
      explainData,
    } = this.state

    return (
      <Layout>
        <Header className="header">
          <Row>
            <Col xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }}>
              <div className={cx('logo_wrap')}>
                <div className={cx('logo')}>
                  <img src="/images/om_logo.png" />
                </div>
              </div>
            </Col>
            <Col>
              <img src="/images/querybrowser_logo2.png" />
            </Col>
          </Row>
        </Header>
        <Content style={{ padding: '30px 50px' }}>
          {/*<Title level={3}>*/}
          {/*  QueryBrowser <img src="/images/pochapeng_01.gif" style={{ width: '30px' }} />*/}
          {/*</Title>*/}
          <Collapse defaultActiveKey={['2', '3']}>
            <Panel header="간편 쿼리" key="1">
              <Divider orientation="left">조회대상 테이블</Divider>
              <Select
                ref={this.tableSelectEl}
                showSearch
                style={{ width: '300px' }}
                placeholder="테이블 선택"
                optionFilterProp="children"
                onChange={this.selectTable}
              >
                {tables.map(table => (
                  <Option key={`select_tables_${table}`} value={table}>
                    {table}
                  </Option>
                ))}
              </Select>
              <Divider orientation="left">조회 컬럼</Divider>
              {checkColumns && checkColumns.length > 0 ? (
                <>
                  <Checkbox.Group ref={this.columnCheckEl} options={checkColumns} onChange={this.handleCheckColumns} />
                </>
              ) : (
                <Skeleton active />
              )}
            </Panel>
            <Panel header="쿼리 에디터" key="2">
              <TextArea
                rows={10}
                ref={this.queryEditorEl}
                onChange={this.handleQueryInput}
                onKeyPress={this.keyPress}
              />
              <div style={{ paddingTop: '10px' }}>
                <Switch
                  checkedChildren={<Icon type="thunderbolt" />}
                  unCheckedChildren={<Icon type="close" />}
                  onChange={this.handleAutoComplete}
                />
                &nbsp;|&nbsp;
                <Button type="default" icon="delete" onClick={this.handleQueryReset}>
                  초기화
                </Button>
                &nbsp;|&nbsp;
                <Button type="dashed" icon="double-right" onClick={this.handleExplain}>
                  실행계획
                </Button>
                &nbsp;|&nbsp;
                <Button type="primary" icon="play-square" onClick={this.handleQuerySend}>
                  실행
                </Button>
              </div>
            </Panel>
            <Panel header="실행 결과" key="3">
              {datasource &&
                datasource.length > 0 && (
                  <span>
                    <Tag color="#2db7f5">데이터 수: {datasource.length}</Tag>
                    <Tag color="#87d068">
                      페이지 수: {Math.floor(datasource.length / 50) + (datasource.length % 50 > 0 ? 1 : 0)}
                    </Tag>
                    <Divider />
                  </span>
                )}
              <Spin spinning={this.state.loading} delay={500} tip="Loading...">
                <Table columns={columns} dataSource={datasource} pagination={{ pageSize: 50 }} />
              </Spin>
            </Panel>
          </Collapse>
        </Content>
        <Footer>
          <span>ⓒ46gom in OliveDior</span>
        </Footer>
        <Modal
          title="실행계획"
          visible={modalVisible}
          onOk={this.handleModalOk}
          onCancel={this.handleModalOk}
          confirmLoading={confirmLoading}
          width="80%"
        >
          <Table columns={explainColumns} dataSource={explainData} />
        </Modal>
      </Layout>
    )
  }
}

export default styling(s)(QueryBrowser)
