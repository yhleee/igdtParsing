import * as React from 'react'
import { EditableCell, EditableFormRow, ResizeableTitle } from './editable_cell'
import { Button, Table, Popconfirm } from 'antd'
import { IScheduleFireWall, ISetScheduleFireWall } from './entity/Schedule'
import { getScheduleFireWallList, setScheduleFireWall } from '../../../services/setting/schedule'
import { History } from 'history'

interface IProps {
  history?: History
}
interface IState {
  dataSource: IScheduleFireWall[]
  lastScheduleNo: number
  count: number
}

class Schedule extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      dataSource: null,
      lastScheduleNo: 0,
      count: 0,
    }
  }

  getColumns = () => {
    return [
      {
        title: '시스템명',
        dataIndex: 'scheduleSystemName',
        editable: true,
      },
      {
        title: '사용목적',
        dataIndex: 'schedulePurpose',
        editable: true,
      },
      {
        title: '출발지IP',
        dataIndex: 'sourceIp',
        editable: true,
      },
      {
        title: '목적지IP',
        dataIndex: 'destinationIp',
        editable: true,
      },
      {
        title: 'port',
        dataIndex: 'port',
        editable: true,
      },
      {
        title: '사용여부',
        dataIndex: 'useYn',
        editable: true,
      },
      {
        title: '시작일',
        dataIndex: 'policyStartDate',
        editable: true,
      },
      {
        title: '종료일',
        dataIndex: 'policyEndDate',
        editable: true,
      },
      {
        title: '알림일',
        dataIndex: 'policyNoticeDate',
        editable: true,
      },
      {
        title: '문서번호',
        dataIndex: 'docNumber',
        editable: true,
      },
      {
        title: '작성자',
        dataIndex: 'sysRegrId',
      },
      {
        title: '작성일자',
        dataIndex: 'sysRegDtime',
      },
      {
        title: '삭제',
        dataIndex: 'operation',
        render: (text, record) =>
          this.state.dataSource.length >= 1 ? (
            <Popconfirm title="Sure to delete?" onConfirm={() => this.handleDelete(record.key)}>
              <a>Delete</a>
            </Popconfirm>
          ) : null,
      },
    ]
  }

  async componentDidMount() {
    this.getScheduleFireWallList()
  }

  getScheduleFireWallList = async () => {
    const fireWallResult = await getScheduleFireWallList()
    const fireWallList: IScheduleFireWall[] = fireWallResult.contents
    if (fireWallList) {
      const datasource = []
      fireWallList.forEach((item, index) => {
        datasource.push({
          ...item,
        })
      })

      this.setState({
        dataSource: datasource,
        lastScheduleNo: fireWallResult.lastCreatedNo,
        count: fireWallResult.totalCnt,
      })
    }
  }

  handleDelete = key => {
    const dataSource = [...this.state.dataSource]
    this.setState({ dataSource: dataSource.filter(item => item.key !== key) })
  }

  handleAdd = () => {
    const { count, dataSource, lastScheduleNo } = this.state
    const newData = {
      key: lastScheduleNo,
      scheduleNo: lastScheduleNo,
      scheduleSystemName: ' ',
      schedulePurpose: ' ',
      sourceIp: ' ',
      destinationIp: ' ',
      port: ' ',
      useYn: 'N',
      policyStartDate: ' ',
      policyEndDate: ' ',
      policyNoticeDate: ' ',
      docNumber: ' ',
      sysRegrId: null,
      sysRegDtime: null,
    }

    this.setState({
      dataSource: [...dataSource, newData],
      lastScheduleNo: lastScheduleNo + 1,
      count: count + 1,
    })
  }

  setScheduleFireWall = async (param: IScheduleFireWall[]) => {
    await setScheduleFireWall(param)
  }

  handleSave = row => {
    const newData = [...this.state.dataSource]
    const index = newData.findIndex(item => row.key === item.key)
    const item = newData[index]
    newData.splice(index, 1, {
      ...item,
      ...row,
    })

    // vaild check
    // const vaildFields = [
    //   'scheduleSystemName',
    //   'schedulePurpose',
    //   'sourceIp',
    //   'destinationIp',
    //   'port',
    //   'policyStartDate',
    //   'policyEndDate',
    //   'policyNoticeDate',
    //   'docNumber',
    // ]
    newData.forEach(item => {})

    // SAVe
    // console.log(newData)
    // this.setScheduleFireWall(newData).then(response => {
    //   console.log(response)
    // })

    this.setState({ dataSource: newData })
  }

  render() {
    const { dataSource } = this.state
    const components = {
      header: {
        cell: ResizeableTitle,
      },
      body: {
        row: EditableFormRow,
        cell: EditableCell,
      },
    }

    const columns = this.getColumns().map(col => {
      if (!col.editable) {
        return col
      }
      return {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleSave,
        }),
      }
    })

    return (
      <>
        <div>
          <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
            <div style={{ display: 'table', width: '100%' }}>
              <div style={{ display: 'table-cell', width: '50%' }}>
                <h2>■ 방화벽 정책 기간 만료 알림(알림 메일 09:00 전송)</h2>
              </div>
            </div>
            <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
              <Button href="javascript:void(0)" onClick={this.handleAdd} type="default" style={{ marginBottom: 16 }}>
                신규 데이터 추가
              </Button>
              <Table
                components={components}
                columns={columns}
                dataSource={dataSource}
                bordered={true}
                rowClassName={() => 'editable-row'}
                size="small"
              />
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default Schedule
