export interface IScheduleFireWall {
  key: number
  scheduleNo: number
  scheduleSystemName: string
  schedulePurpose: string
  sourceIp: string
  destinationIp: string
  port: string
  useYn: string
  policyStartDate: string
  policyEndDate: string
  policyNoticeDate: string
  docNumber: string
  sysRegrId: string
  sysRegDtime: string
}

export interface ISetScheduleFireWall {
  scheduleSystemName: string
  schedulePurpose: string
  sourceIp: string
  destinationIp: string
  port: string
  policyStartDate: string
  policyEndDate: string
  policyNoticeDate: string
  docNumber: string
}
