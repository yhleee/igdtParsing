import * as React from 'react'
import { RouteComponentProps, withRouter } from 'react-router-dom'
import Routes from './routes'
import Layout from './Layout/CommonLayout'
import { ifElse } from 'common/utils'
import 'moment/locale/ko'

const { hot } = require('react-hot-loader')

const App: React.FC<RouteComponentProps<any>> = ({ location }) => {
  const pathName = location.pathname

  let showLayout = true
  if (pathName === '/app/querybrowser' || pathName === '/app/login' || pathName === '/app/registration') {
    showLayout = false
  }

  return (
    <>
      {ifElse(showLayout)(
        <Layout>
          <Routes />
        </Layout>,
        <Routes />,
      )}
    </>
  )
}

export default hot(module)(withRouter(App))
