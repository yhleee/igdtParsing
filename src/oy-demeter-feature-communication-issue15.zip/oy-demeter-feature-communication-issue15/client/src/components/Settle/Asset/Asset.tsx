import * as React from 'react'
import AssetList from './AssetList'
import { assetCSVUpLoad, getAssetCSVDownLoad, getAssetList } from '../../../services/settle/asset'
import { IAsset } from './entity/Asset'
import { Button } from 'antd'
import { alertPopup } from '../../../common/utils'

interface IProps {}
interface IState {
  list: any
  selectedFile: any
}

class Asset extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      list: null,
      selectedFile: null,
    }
  }

  async componentDidMount() {
    await this.getAssetList()
  }

  getAssetList = async () => {
    const assetList: IAsset[] = await getAssetList(null)
    if (assetList) {
      const datasource = []
      assetList.forEach((item, index) => {
        datasource.push({
          ...item,
        })
      })

      this.setState({
        list: datasource,
      })
    }
  }

  getAssetCSVDownLoad = async param => {
    const csvData = await getAssetCSVDownLoad(param)

    const blob = new Blob([csvData], {
      type: 'application/octet-stream;charset=EUC-KR',
    })

    // FOR OTHER BROWSERS
    const csvUrl = URL.createObjectURL(blob)

    const hiddenElement = document.createElement('a')
    hiddenElement.href = csvUrl
    hiddenElement.target = '_blank'
    hiddenElement.download = 'settle_asset.xls'
    hiddenElement.click()
  }

  handleFileInput(e) {
    this.setState({
      selectedFile: e.target.files[0],
    })
  }

  setAssetCSVUpLoad = async param => {
    if (confirm('업로드 하시겠습니까?')) {
      if (!this.state.selectedFile) {
        alert('업로드할 파일을 선택하여 주시길 바랍니다.')
        return false
      }

      const formData = new FormData()
      formData.append('uploadFile', this.state.selectedFile)

      await assetCSVUpLoad(formData).then(response => {
        if (response.result === 'SUCCESS') {
          location.reload()
        } else {
          alertPopup(response.message)
        }
      })
    }
  }

  render() {
    const { list } = this.state

    return (
      <>
        <div>
          <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
            <div style={{ display: 'table', width: '100%' }}>
              <div style={{ display: 'table-cell', width: '50%' }}>
                <h2>■ 자산이체(e-Acc양식)</h2>
              </div>
            </div>
            <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
              <input type="file" id="csv_file" name="csv_file" onChange={e => this.handleFileInput(e)} accept=".xls" />
              <Button type="default" onClick={() => this.setAssetCSVUpLoad(null)}>
                업로드
              </Button>&nbsp;&nbsp;
              <Button type="default" onClick={() => this.getAssetCSVDownLoad(null)}>
                다운로드
              </Button>
            </div>
            <AssetList assetList={list} />
          </div>
        </div>
      </>
    )
  }
}

export default Asset
