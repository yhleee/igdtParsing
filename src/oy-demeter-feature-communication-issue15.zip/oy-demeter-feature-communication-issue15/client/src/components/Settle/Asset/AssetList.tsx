import * as React from 'react'
import { IAsset } from './entity/Asset'
import { Button, Table } from 'antd'
import { ColumnProps } from 'antd/es/table'

interface IProps {
  assetList: IAsset[]
}
interface IState {}

class AssetList extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {}
  }

  getColumns = () => {
    return [
      {
        title: '자산번호',
        dataIndex: null,
        children: [
          {
            title: 'ASSET_CD',
            dataIndex: 'assetCd',
            key: 'assetCd',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '자산명',
        dataIndex: null,
        children: [
          {
            title: 'ASSET_TXT',
            dataIndex: 'assetTxt',
            key: 'assetTxt',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '위치',
        dataIndex: null,
        children: [
          {
            title: 'ASSET_LO',
            dataIndex: 'assetLo',
            key: 'assetLo',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '관리코스트센터코드',
        dataIndex: null,
        children: [
          {
            title: 'MNG_CST_CNTR_CD',
            dataIndex: 'mngCstCntrCd',
            key: 'mngCstCntrCd',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '관리코스트센터명',
        dataIndex: null,
        children: [
          {
            title: 'MNG_CST_CNTR_NM',
            dataIndex: 'mngCstCntrNm',
            key: 'mngCstCntrNm',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '관리담당자명',
        dataIndex: null,
        children: [
          {
            title: 'MNG_MN',
            dataIndex: 'mngMn',
            key: 'mngMn',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '이체구분(01:전체,02:비율,03:수량)',
        dataIndex: null,
        children: [
          {
            title: 'ASSET_PART_TYPE_CD',
            dataIndex: 'assetPartTypeCd',
            key: 'assetPartTypeCd',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '이체비율(%)',
        dataIndex: null,
        children: [
          {
            title: 'PART_RATE',
            dataIndex: 'partRate',
            key: 'partRate',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '이체수량',
        dataIndex: null,
        children: [
          {
            title: 'PROC_CNT',
            dataIndex: 'procCnt',
            key: 'procCnt',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '변경코스트센터',
        dataIndex: null,
        children: [
          {
            title: 'TO_CST_CNTR_CD',
            dataIndex: 'toCstCntrCd',
            key: 'toCstCntrCd',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '변경코스트센터명',
        dataIndex: null,
        children: [
          {
            title: 'TO_CST_CNTR_NM',
            dataIndex: 'toCstCntrNm',
            key: 'toCstCntrNm',
            width: 200,
            align: 'center',
          },
        ],
      },
      {
        title: '등록일자',
        dataIndex: null,
        children: [
          {
            title: 'SYS_REG_DTIME',
            dataIndex: 'sysRegDtime',
            key: 'sysRegDtime',
            width: 200,
            align: 'center',
          },
        ],
      },
    ]
  }

  render() {
    const { assetList } = this.props
    // @ts-ignore
    const _columns: ColumnProps = this.getColumns().map(col => {
      return {
        ...col,
        onCell: record => ({
          record,
          dataIndex: col.dataIndex,
          title: col.title,
        }),
      }
    })

    return (
      <>
        <div>
          <Table
            columns={_columns}
            dataSource={assetList}
            scroll={{ x: 'max-content', y: 'max-content' }}
            bordered={true}
            size="middle"
            pagination={false}
          />
        </div>
      </>
    )
  }
}

export default AssetList
