export interface IAsset {
  assetCd: number
  assetTxt: string
  assetLo: string
  mngCstCntrCd: number
  mngCstCntrNm: string
  mngMn: string
  assetPartTypeCd: string
  partRate: number
  procCnt: number
  toCstCntrCd: number
  toCstCntrNm: string
  sysRegDtime: string
}
