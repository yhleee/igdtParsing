import * as React from 'react'
import { Button, Modal, Table } from 'antd'

import TeamProjectLayerPopupForm from './TeamProjectLayerPopupForm'
import { ITeamProject } from './entity/teamProject'
import { ColumnProps } from 'antd/es/table'
import { delTeamProject } from 'services/settle/teamProject'

interface IProps {
  teamProjectList: ITeamProject[]
  activeType: string
  listTotalCnt: number
}

interface IState {
  detail: ITeamProject
  visible: boolean
  modalType: string // add or edit
}

class TeamProjectList extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      detail: null,
      visible: false,
      modalType: '', // add or edit
    }
  }

  // ------------------------------- Layer Popup Start ------------------------------
  teamProjectPopup = (data: ITeamProject) => {
    this.setState({
      visible: true,
      detail: data,
    })
  }

  handleCancel = () => {
    this.setState({
      visible: false,
      detail: null,
    })
  }
  // ------------------------------- Layer Popup End ------------------------------

  async delTeamProject(teamProjectNo: number) {
    if (window.confirm('정말 삭제하시겠습니까?')) {
      await delTeamProject(teamProjectNo).then(response => {
        location.reload()
      })
    } else {
      return false
    }
  }

  getColumns = () => {
    const teamProjectUpdatePopup = this.teamProjectPopup
    const delTeamProject = this.delTeamProject

    return [
      {
        title: 'No',
        dataIndex: 'teamProjectNo',
        key: 'teamProjectNo',
        align: 'center',
      },
      {
        title: '정산구분',
        dataIndex: 'teamProjectSettleType',
        key: 'teamProjectSettleType',
        align: 'center',
        render: teamProjectSettleType => {
          let retVal = '투자'
          if (teamProjectSettleType === 2) {
            retVal = '비용'
          }

          return retVal
        },
      },
      {
        title: '구분',
        dataIndex: 'teamProjectType',
        key: 'teamProjectType',
        align: 'center',
        render: teamProjectType => {
          let retVal = '프로젝트'
          if (teamProjectType === 2) {
            retVal = '일반'
          }

          return retVal
        },
      },
      {
        title: '발의부서',
        dataIndex: 'teamProjectDepartment',
        key: 'teamProjectDepartment',
      },
      {
        title: '계약서명',
        dataIndex: 'teamProjectDealCheck',
        key: 'teamProjectDealCheck',
      },
      {
        title: '품의서번호',
        dataIndex: 'teamProjectDocumentNumber',
        key: 'teamProjectDocumentNumber',
      },
      {
        title: 'OY 품의 제목',
        dataIndex: 'teamProjectDocumentTitle',
        key: 'teamProjectDocumentTitle',
      },
      {
        title: '금액',
        dataIndex: 'teamProjectPrice',
        key: 'teamProjectPrice',
        render(value) {
          return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
      },
      {
        title: '귀속 코스트센터',
        dataIndex: 'teamProjectCostCenter',
        key: 'teamProjectCostCenter',
      },
      {
        title: 'OY WBS',
        dataIndex: 'teamProjectWBSCode',
        key: 'teamProjectWBSCode',
        align: 'center',
      },
      {
        title: '작성자',
        dataIndex: 'teamProjectRegUser',
        key: 'teamProjectRegUser',
        align: 'center',
      },
      {
        title: '등록일자',
        dataIndex: 'teamProjectRegDate',
        key: 'teamProjectRegDate',
        align: 'center',
      },
      {
        title: 'updateAction',
        key: 'Action',
        align: 'center',
        render(data) {
          if (data.teamProjectActiveType === 'N') {
            return <Button onClick={() => teamProjectUpdatePopup(data)}>수정</Button>
          }
        },
      },
      {
        title: 'deleteAction',
        key: 'Action',
        align: 'center',
        render(data) {
          if (data.teamProjectActiveType === 'N') {
            return <Button onClick={() => delTeamProject(data.teamProjectNo)}>삭제</Button>
          }
        },
      },
    ]
  }

  render() {
    const { detail, visible } = this.state
    const { teamProjectList, listTotalCnt, activeType } = this.props

    // @ts-ignore
    const _columns: ColumnProps = this.getColumns().map(col => {
      return {
        ...col,
        onCell: record => ({
          record,
          dataIndex: col.dataIndex,
          title: col.title,
        }),
      }
    })

    let setDataBtn = null
    // activeType=N 개수가 0이 아닐 때 버튼 표시(즉, 확정이 안된 상태)
    if (activeType === 'Y' || listTotalCnt === 0) {
      setDataBtn = (
        <Button type="default" onClick={() => this.teamProjectPopup(null)}>
          신규 데이터 추가
        </Button>
      )
    }

    return (
      <>
        <div>
          <Table
            columns={_columns}
            dataSource={teamProjectList}
            scroll={{ x: 'max-content' }}
            bordered={true}
            size="middle"
          />
          <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>{setDataBtn}</div>
        </div>
        <Modal
          title={detail === null ? '등록' : '수정'}
          visible={visible}
          onCancel={this.handleCancel}
          footer={null}
          closable={false}
        >
          <TeamProjectLayerPopupForm detail={detail} handleCancel={this.handleCancel} />
        </Modal>
      </>
    )
  }
}

export default TeamProjectList
