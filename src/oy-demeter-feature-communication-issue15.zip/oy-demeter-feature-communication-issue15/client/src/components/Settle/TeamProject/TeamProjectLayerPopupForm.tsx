import * as React from 'react'
import { Button, Col, Form, Input, Row, Select } from 'antd'
import { updateTeamProject, setTeamProject } from 'services/settle/teamProject'
import { alertPopup } from 'common/utils'

interface IProps {
  form: any
  history?: History
  detail: any
  handleCancel: any
}

interface IState {}

const { Option } = Select

class TeamProjectLayerPopupForm extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {}
  }

  handleSubmit = e => {
    e.preventDefault()
    const { detail } = this.props

    this.props.form.validateFields((err, values) => {
      if (detail === null) {
        if (window.confirm('정말 등록 하시겠습니까?')) {
          const insertTeamProject = {
            teamProjectSettleType: values.teamProjectSettleType,
            teamProjectType: values.teamProjectType,
            teamProjectDepartment: values.teamProjectDepartment,
            teamProjectDealCheck: values.teamProjectDealCheck,
            teamProjectDocumentNumber: values.teamProjectDocumentNumber,
            teamProjectDocumentTitle: values.teamProjectDocumentTitle,
            teamProjectPrice: Number(values.teamProjectPrice),
            teamProjectCostCenter: values.teamProjectCostCenter,
          }

          this.setTeamProject(insertTeamProject).then(response => {
            alertPopup(response)
          })
        }
      } else {
        if (window.confirm('정말 수정 하시겠습니까?')) {
          const updateTeamProject = {
            teamProjectNo: Number(detail.teamProjectNo),
            teamProjectSettleType: values.teamProjectSettleType,
            teamProjectType: values.teamProjectType,
            teamProjectDepartment: values.teamProjectDepartment,
            teamProjectDealCheck: values.teamProjectDealCheck,
            teamProjectDocumentNumber: values.teamProjectDocumentNumber,
            teamProjectDocumentTitle: values.teamProjectDocumentTitle,
            teamProjectPrice: Number(values.teamProjectPrice),
            teamProjectCostCenter: values.teamProjectCostCenter,
            teamProjectWBSCode: values.teamProjectWBSCode,
          }
          this.updateTeamProject(updateTeamProject).then(response => {
            alertPopup(response)
          })
        }
      }

      this.handleReset()
      location.reload()
    })
  }

  handleReset = () => {
    const { handleCancel } = this.props
    const { resetFields } = this.props.form
    resetFields()
    handleCancel()
  }

  async setTeamProject(teamProject) {
    const response = await setTeamProject(teamProject)
    return response
  }

  async updateTeamProject(teamProject) {
    const response = await updateTeamProject(teamProject)
    return response
  }

  render() {
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    }

    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const { getFieldDecorator } = this.props.form
    const { detail } = this.props

    let bongTest = null
    if (detail && detail.teamProjectSettleType === 1) {
      bongTest = (
        <Form.Item label="OY WBS" {...formItemLayout}>
          {getFieldDecorator('teamProjectWBSCode', {
            initialValue: detail === null ? undefined : detail.teamProjectWBSCode,
          })(<Input placeholder="OY WBS를 입력하세요." />)}
        </Form.Item>
      )
    }

    return (
      <>
        <Form onSubmit={this.handleSubmit}>
          <Form.Item label="정산구분" {...formItemLayout}>
            {getFieldDecorator('teamProjectSettleType', {
              rules: [{ required: true, message: '정산구분값을 선택하세요.' }],
              initialValue: detail === null ? undefined : detail.teamProjectSettleType,
            })(
              <Select placeholder="선택">
                <Option value={1}>투자</Option>
                <Option value={2}>비용</Option>
              </Select>,
            )}
          </Form.Item>
          <Form.Item label="구분" {...formItemLayout}>
            {getFieldDecorator('teamProjectType', {
              rules: [{ required: true, message: '구분값을 선택하세요.' }],
              initialValue: detail === null ? undefined : detail.teamProjectType,
            })(
              <Select placeholder="선택">
                <Option value={1}>프로젝트</Option>
                <Option value={2}>일반</Option>
              </Select>,
            )}
          </Form.Item>
          <Form.Item label="발의부서" {...formItemLayout}>
            {getFieldDecorator('teamProjectDepartment', {
              rules: [{ required: true, message: '발의부서는 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectDepartment,
            })(<Input placeholder="발의부서를 입력하세요." />)}
          </Form.Item>
          <Form.Item label="계약서명" {...formItemLayout}>
            {getFieldDecorator('teamProjectDealCheck', {
              rules: [{ required: true, message: '계약서명은 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectDealCheck,
            })(<Input placeholder="계약서명을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="품의서번호" {...formItemLayout}>
            {getFieldDecorator('teamProjectDocumentNumber', {
              rules: [{ required: true, message: '품의서번호는 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectDocumentNumber,
            })(<Input placeholder="품의서번호를 입력하세요." />)}
          </Form.Item>
          <Form.Item label="OY 품의 제목" {...formItemLayout}>
            {getFieldDecorator('teamProjectDocumentTitle', {
              rules: [{ required: true, message: 'OY 품의 제목은 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectDocumentTitle,
            })(<Input placeholder="OY 품의 제목을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="금액" {...formItemLayout}>
            {getFieldDecorator('teamProjectPrice', {
              rules: [{ required: true, message: '금액은 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectPrice,
            })(<Input placeholder="금액을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="귀속 코스트센터" {...formItemLayout}>
            {getFieldDecorator('teamProjectCostCenter', {
              rules: [{ required: true, message: '귀속 코스트센터는 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.teamProjectCostCenter,
            })(<Input placeholder="귀속 코스트센터를 입력하세요." />)}
          </Form.Item>
          {bongTest}
          <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
            <Form.Item {...buttonItemLayout}>
              <Row>
                <Col span={24}>
                  <Button type="primary" htmlType="submit">
                    저장
                  </Button>&nbsp;&nbsp;
                  <Button type="default" onClick={this.handleReset}>
                    취소
                  </Button>
                </Col>
              </Row>
            </Form.Item>
          </div>
        </Form>
      </>
    )
  }
}

export default Form.create<IProps>()(TeamProjectLayerPopupForm)
