import * as React from 'react'
import { Form, Row, Col, Input, Button, Collapse, DatePicker, Select, Radio } from 'antd'
const { MonthPicker } = DatePicker

interface IProps {
  form: any
  getTeamProjectList: Function
}

interface IState {
  selectTeamProjectSettleType: 1
}

const { Option } = Select
const { Panel } = Collapse

function callback(key) {}

class TeamProjectSearchForm extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      selectTeamProjectSettleType: 1,
    }
  }

  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      const { getTeamProjectList } = this.props
      const { selectTeamProjectSettleType } = this.state

      const parseTeamProjectRegDate = values['teamProjectRegDate']
        ? values['teamProjectRegDate'].format('YYYY-MM')
        : null
      const listSearchParam = {
        page: 1,
        size: 100000,
        teamProjectSettleType: selectTeamProjectSettleType ? Number(selectTeamProjectSettleType) : null,
        teamProjectType: values.teamProjectType ? Number(values.teamProjectType) : null,
        teamProjectRegUser: values.teamProjectRegUser ? values.teamProjectRegUser : null,
        teamProjectRegYearMonth: parseTeamProjectRegDate ? parseTeamProjectRegDate : null,
      }
      getTeamProjectList(listSearchParam)
    })
  }

  onChange = e => {
    this.setState({
      selectTeamProjectSettleType: e.target.value,
    })
  }

  render() {
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }

    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const { getFieldDecorator } = this.props.form

    return (
      <>
        <div>
          <Collapse defaultActiveKey={['1']} onChange={callback}>
            <Panel header="검색조건 설정" key="1">
              <Row>
                <Col>
                  <Form onSubmit={this.handleSubmit}>
                    <Form.Item label="정산구분" {...formItemLayout}>
                      <Radio.Group onChange={this.onChange} value={this.state.selectTeamProjectSettleType}>
                        <Radio value={1}>투자</Radio>
                        <Radio value={2}>비용</Radio>
                      </Radio.Group>
                    </Form.Item>
                    <Form.Item label="구분(기본값: 전체)" {...formItemLayout}>
                      {getFieldDecorator('teamProjectType')(
                        <Select placeholder="전체">
                          <Option value="">전체</Option>
                          <Option value="1">프로젝트</Option>
                          <Option value="2">일반</Option>
                        </Select>,
                      )}
                    </Form.Item>
                    <Form.Item label="작성자" {...formItemLayout}>
                      {getFieldDecorator('teamProjectRegUser')(<Input />)}
                    </Form.Item>
                    <Form.Item label="작성일자" {...formItemLayout}>
                      {getFieldDecorator('teamProjectRegDate')(<MonthPicker />)}
                    </Form.Item>
                    <Form.Item {...buttonItemLayout}>
                      <Row>
                        <Col span={24} style={{ textAlign: 'center' }}>
                          <Button type="primary" htmlType="submit">
                            검색
                          </Button>
                        </Col>
                      </Row>
                    </Form.Item>
                  </Form>
                </Col>
              </Row>
            </Panel>
          </Collapse>
        </div>
        <br />
      </>
    )
  }
}

export default Form.create<IProps>()(TeamProjectSearchForm)
