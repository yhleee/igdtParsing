import * as React from 'react'
import TeamProjectList from './TeamProjectList'
import TeamProjectSearchForm from './TeamProjectSearchForm'
import { ITeamProject } from './entity/teamProject'
import {
  getTeamProjectList,
  updateTeamProjectActiveType,
  getTeamProjectActiveTypeNCnt,
  getTeamProjectCSVDownLoad,
  setTeamProjectCSVUpLoad,
} from '../../../services/settle/teamProject'
import { Button, Menu } from 'antd'
import { weekNumberByMonth } from '../../../common/utils/stringUtils'
import { alertPopup } from '../../../common/utils'

interface IProps {}
interface IState {
  list: ITeamProject[]
  listTotalCnt: number
  activeTypeVal: string
  activeType: string
  selectedFile: any
  setSearchParam: any
}

class TeamProject extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      list: null,
      listTotalCnt: 0,
      activeTypeVal: null,
      activeType: null,
      selectedFile: null,
      setSearchParam: null,
    }
  }

  async componentDidMount() {
    const date = new Date()
    const toDate = `${date.getFullYear()}-${this.getDateFormat(date.getMonth() + 1)}`  
  
    await this.getTeamProjectList({
      page: 1,
      size: 100000,
      teamProjectRegYearMonth: toDate
    })
    await this.setActiveTypeNCnt()
  }
  
  getDateFormat(day: number) {
    if (day < 10) {
      return `0${day}`
    }
    return day
  }  

  getTeamProjectList = async searchParam => {
    const teamProjectList: ITeamProject[] = await getTeamProjectList(searchParam)
    if (teamProjectList) {
      const datasource = []
      teamProjectList.forEach((item, index) => {
        datasource.push({
          ...item,
        })
      })

      this.setState({
        list: datasource,
        listTotalCnt: datasource.length,
        setSearchParam: searchParam,
      })
    }
  }

  setActiveTypeNCnt = async () => {
    const activeTypeNCnt = await getTeamProjectActiveTypeNCnt()
    const activeTypeVal = activeTypeNCnt === 0 ? '확정취소' : '확정'
    const activeType = activeTypeNCnt === 0 ? 'N' : 'Y'
    this.setState({
      activeTypeVal,
      activeType,
    })
  }

  handleActiveType = async teamProjectRegYearMonth => {
    const { activeType } = this.state
    let confirmMsg = '정말 확정 하시겠습니까?'

    if (activeType === 'N') {
      confirmMsg = '확정을 취소 하시겠습니까?'
    }

    if (window.confirm(confirmMsg)) {
      await updateTeamProjectActiveType({
        teamProjectActiveType: activeType,
        teamProjectRegYearMonth: teamProjectRegYearMonth.weekOfMonth,
      }).then(response => {
        location.reload()
      })
    } else {
      return false
    }
  }

  getTeamProjectCSVDownLoad = async () => {
    const { setSearchParam } = this.state
    const csvData = await getTeamProjectCSVDownLoad(setSearchParam)

    const blob = new Blob([csvData], {
      type: 'application/octet-stream;charset=EUC-KR',
    })

    // FOR OTHER BROWSERS
    const csvUrl = URL.createObjectURL(blob)

    const hiddenElement = document.createElement('a')
    hiddenElement.href = csvUrl
    hiddenElement.target = '_blank'
    hiddenElement.download = 'settle_team_project.xls'
    hiddenElement.click()
  }

  handleFileInput(e) {
    this.setState({
      selectedFile: e.target.files[0],
    })
  }

  setTeamProjectCSVUpLoad = async () => {
    if (confirm('업로드 하시겠습니까?')) {
      if (!this.state.selectedFile) {
        alert('업로드할 파일을 선택하여 주시길 바랍니다.')
        return false
      }

      const formData = new FormData()
      formData.append('uploadFile', this.state.selectedFile)

      await setTeamProjectCSVUpLoad(formData).then(response => {
        if (response.result === 'SUCCESS') {
          location.reload()
        } else {
          alertPopup(response.message)
        }
      })
    }
  }

  render() {
    const { list, listTotalCnt, activeTypeVal, activeType } = this.state
    const weekOfMonthInfo = weekNumberByMonth(new Date())
    const monthData = weekOfMonthInfo.month < 10 ? `0${weekOfMonthInfo.month}` : weekOfMonthInfo.month
    const weekOfMonth = `${weekOfMonthInfo.year}-${monthData}`

    let activeTypeBtn = null
    if (listTotalCnt !== 0) {
      activeTypeBtn = (
        <Button type="default" onClick={() => this.handleActiveType({ weekOfMonth })}>
          [{weekOfMonth}] {activeTypeVal}
        </Button>
      )
    }

    const excelUpLoadBtn = (
      <Button type="default" onClick={() => this.setTeamProjectCSVUpLoad()}>
        업로드
      </Button>
    )
    const excelDownLoadBtn = (
      <Button type="default" onClick={() => this.getTeamProjectCSVDownLoad()}>
        다운로드
      </Button>
    )

    return (
      <>
        <div>
          <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
            <div style={{ display: 'table', width: '100%' }}>
              <div style={{ display: 'table-cell', width: '50%' }}>
                <h2>■ 정보전략팀 투자/비용 취합</h2>
              </div>
            </div>
            <TeamProjectSearchForm getTeamProjectList={this.getTeamProjectList} />
            <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
              <input type="file" id="csv_file" name="csv_file" onChange={e => this.handleFileInput(e)} accept=".xls" />
              {excelUpLoadBtn}&nbsp;&nbsp;
              {excelDownLoadBtn}&nbsp;&nbsp;
              {activeTypeBtn}
            </div>
            <TeamProjectList teamProjectList={list} activeType={activeType} listTotalCnt={listTotalCnt} />
          </div>
        </div>
      </>
    )
  }
}

export default TeamProject
