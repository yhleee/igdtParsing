export interface ITeamProject {
  teamProjectNo: number
  teamProjectSettleType: number
  teamProjectType: number
  teamProjectDepartment: string
  teamProjectDealCheck: string
  teamProjectDocumentNumber: string
  teamProjectDocumentTitle: string
  teamProjectPrice: number
  teamProjectCostCenter: string
  teamProjectWBSCode: string
  teamProjectActiveType: string
  teamProjectRegUser: string
  teamProjectRegDate: string
}
