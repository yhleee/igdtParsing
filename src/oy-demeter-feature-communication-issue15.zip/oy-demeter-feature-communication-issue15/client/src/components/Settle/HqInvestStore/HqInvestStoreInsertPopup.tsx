import * as React from 'react'
import { Button, Card, Col, DatePicker, Form, Input, Row, Select } from 'antd'
import { alertPopup } from 'common/utils'
import { setHqInvestStore, putHqInvestStore } from '../../../services/settle/investStore'
import * as moment from 'moment'

interface IProps extends React.Props<any> {
  form: any
  detail: any
  handleCancel: any
}

interface IState {}

const { Option } = Select

class HqInvestStoreInsertPopup extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {}
  }

  handleSubmit = e => {
    e.preventDefault()
    const { detail } = this.props

    if (window.confirm('정말 저장 하시겠습니까?')) {
      this.props.form.validateFields((err, values) => {
        const rangeValue = values['investStoreOpenDate']
        const parseInvestStoreOpenDate = `${rangeValue.format('YYYY-MM-DD')} 00:00:00`
        const parseInvestStoreType =
          values.investStoreType === '1' || values.investStoreType === '2'
            ? values.investStoreType
            : values.investStoreType === '신규점' ? '1' : '2'

        const investStoreForm = {
          investStoreName: values.investStoreName,
          investStoreOpenDate: parseInvestStoreOpenDate,
          investStoreRemarks: values.investStoreRemarks,
          investStoreType: Number(parseInvestStoreType),
          newInvestStoreAssetCat: Number(values.newInvestStoreAssetCat),
          newInvestStoreAssetHandScanner: Number(values.newInvestStoreAssetHandScanner),
          newInvestStoreAssetHub: Number(values.newInvestStoreAssetHub),
          newInvestStoreAssetIcTerminal: Number(values.newInvestStoreAssetIcTerminal),
          newInvestStoreAssetLed: Number(values.newInvestStoreAssetLed),
          newInvestStoreAssetPda: Number(values.newInvestStoreAssetPda),
          newInvestStoreAssetPos: Number(values.newInvestStoreAssetPos),
          newInvestStoreAssetRack: Number(values.newInvestStoreAssetRack),
          newInvestStoreAssetSettopPc: Number(values.newInvestStoreAssetSettopPc),
          newInvestStoreAssetSignPad: Number(values.newInvestStoreAssetSignPad),
          newInvestStoreAssetSurgeProtector: Number(values.newInvestStoreAssetSurgeProtector),
          newInvestStoreAssetSwitch: Number(values.newInvestStoreAssetSwitch),
          newInvestStoreAssetVpn: Number(values.newInvestStoreAssetVpn),
          reInvestStoreAssetCat: Number(values.reInvestStoreAssetCat),
          reInvestStoreAssetHandScanner: Number(values.reInvestStoreAssetHandScanner),
          reInvestStoreAssetHub: Number(values.reInvestStoreAssetHub),
          reInvestStoreAssetIcTerminal: Number(values.reInvestStoreAssetIcTerminal),
          reInvestStoreAssetLed: Number(values.reInvestStoreAssetLed),
          reInvestStoreAssetPda: Number(values.reInvestStoreAssetPda),
          reInvestStoreAssetPos: Number(values.reInvestStoreAssetPos),
          reInvestStoreAssetRack: Number(values.reInvestStoreAssetRack),
          reInvestStoreAssetSettopPc: Number(values.reInvestStoreAssetSettopPc),
          reInvestStoreAssetSignPad: Number(values.reInvestStoreAssetSignPad),
          reInvestStoreAssetSurgeProtector: Number(values.reInvestStoreAssetSurgeProtector),
          reInvestStoreAssetSwitch: Number(values.reInvestStoreAssetSwitch),
          reInvestStoreAssetVpn: Number(values.reInvestStoreAssetVpn),
        }

        if (detail === null) {
          this.setHqInvestStore(investStoreForm).then(response => {
            alertPopup(response)
          })
        } else {
          this.putHqInvestStore(detail.investStoreNo, investStoreForm).then(response => {
            alertPopup(response)
          })
        }

        this.handleReset()
        location.reload()
      })
    }
  }

  handleReset = () => {
    const { handleCancel } = this.props
    const { resetFields } = this.props.form
    resetFields()
    handleCancel()
  }

  async setHqInvestStore(insertInvestStoreForm) {
    const response = await setHqInvestStore(insertInvestStoreForm)
    return response
  }

  async putHqInvestStore(investStoreNo, updateInvestStoreForm) {
    const response = await putHqInvestStore(investStoreNo, updateInvestStoreForm)
    return response
  }

  render() {
    const formItemSubLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
    }

    const { getFieldDecorator } = this.props.form
    const { detail } = this.props

    const dateFormat = 'YYYY/MM/DD'

    return (
      <>
        <Form layout={'inline'} onSubmit={this.handleSubmit}>
          <Form.Item label="매장명">
            {getFieldDecorator('investStoreName', {
              rules: [{ required: true, message: '매장명은 필수 값 입니다.' }],
              initialValue: detail === null ? undefined : detail.investStoreName,
            })(<Input placeholder="매장명을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="오픈일자">
            {getFieldDecorator('investStoreOpenDate', {
              rules: [{ type: 'object', required: true, message: 'Please select time!' }],
              initialValue: detail === null ? undefined : moment(detail.investStoreOpenDate),
            })(<DatePicker />)}
          </Form.Item>
          <Form.Item label="신규/리뉴얼">
            {getFieldDecorator('investStoreType', {
              rules: [{ required: true, message: '신규/리뉴얼 구분값을 선택하세요.' }],
              initialValue: detail === null ? '신규점' : detail.investStoreType === 1 ? '신규점' : '리뉴얼',
              // initialValue: detail === null ? undefined : detail.investStoreType,
            })(
              <Select placeholder="선택">
                <Option value="1">신규점</Option>
                <Option value="2">리뉴얼</Option>
              </Select>,
            )}
          </Form.Item>
          <Form.Item label="비고">
            {getFieldDecorator('investStoreRemarks', {
              initialValue: detail === null ? undefined : detail.investStoreRemarks,
            })(<Input placeholder="비고를 입력하세요." />)}
          </Form.Item>
          <br />
          <br />
          <div style={{ background: '#ECECEC', padding: '30px' }}>
            <Row gutter={24}>
              <Col span={24}>
                <Card title="신규" bordered={false}>
                  <Form.Item label="RACK" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetRack', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetRack,
                    })(<Input placeholder="신규 RACK을 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="VPN" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetVpn', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetVpn,
                    })(<Input placeholder="신규 VPN을 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="LED" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetLed', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetLed,
                    })(<Input placeholder="신규 LED를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="셋탑PC" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetSettopPc', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetSettopPc,
                    })(<Input placeholder="신규 셋탑PC를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="POS" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetPos', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetPos,
                    })(<Input placeholder="신규 POS를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="서지보호기" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetSurgeProtector', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetSurgeProtector,
                    })(<Input placeholder="신규 서지보호기를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="HUB" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetHub', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetHub,
                    })(<Input placeholder="신규 HUB를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="핸드스캐너" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetHandScanner', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetHandScanner,
                    })(<Input placeholder="신규 핸드스캐너를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="PDA" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetPda', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetPda,
                    })(<Input placeholder="신규 PDA를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="사인패드" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetSignPad', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetSignPad,
                    })(<Input placeholder="신규 사인패드를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="CAT" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetCat', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetCat,
                    })(<Input placeholder="신규 CAT를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="스위치" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetSwitch', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetSwitch,
                    })(<Input placeholder="신규 스위치를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="IC단말기" {...formItemSubLayout}>
                    {getFieldDecorator('newInvestStoreAssetIcTerminal', {
                      initialValue: detail === null ? 0 : detail.newInvestStoreAssetIcTerminal,
                    })(<Input placeholder="신규 IC단말기를 입력하세요." />)}
                  </Form.Item>
                </Card>
              </Col>
            </Row>
            <Row gutter={24}>
              <Col span={24}>
                <Card title="재사용" bordered={false}>
                  <Form.Item label="RACK" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetRack', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetRack,
                    })(<Input placeholder="재사용 RACK을 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="VPN" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetVpn', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetVpn,
                    })(<Input placeholder="재사용 VPN을 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="LED" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetLed', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetLed,
                    })(<Input placeholder="재사용 LED를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="셋탑PC" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetSettopPc', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetSettopPc,
                    })(<Input placeholder="재사용 셋탑PC를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="POS" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetPos', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetPos,
                    })(<Input placeholder="재사용 POS를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="서지보호기" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetSurgeProtector', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetSurgeProtector,
                    })(<Input placeholder="재사용 서지보호기를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="HUB" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetHub', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetHub,
                    })(<Input placeholder="재사용 HUB를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="핸드스캐너" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetHandScanner', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetHandScanner,
                    })(<Input placeholder="재사용 핸드스캐너를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="PDA" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetPda', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetPda,
                    })(<Input placeholder="재사용 PDA를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="사인패드" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetSignPad', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetSignPad,
                    })(<Input placeholder="재사용 사인패드를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="CAT" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetCat', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetCat,
                    })(<Input placeholder="재사용 CAT를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="스위치" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetSwitch', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetSwitch,
                    })(<Input placeholder="재사용 스위치를 입력하세요." />)}
                  </Form.Item>
                  <Form.Item label="IC단말기" {...formItemSubLayout}>
                    {getFieldDecorator('reInvestStoreAssetIcTerminal', {
                      initialValue: detail === null ? 0 : detail.reInvestStoreAssetIcTerminal,
                    })(<Input placeholder="재사용 IC단말기를 입력하세요." />)}
                  </Form.Item>
                </Card>
              </Col>
            </Row>
          </div>
          <div style={{ background: '#ECECEC', padding: '30px' }}>
            <Form.Item>
              <Row>
                <Col span={24} style={{ textAlign: 'center' }}>
                  <Button type="primary" htmlType="submit">
                    저장
                  </Button>&nbsp;&nbsp;
                  <Button type="default" onClick={this.handleReset}>
                    취소
                  </Button>
                </Col>
              </Row>
            </Form.Item>
          </div>
        </Form>
      </>
    )
  }
}

export default Form.create<IProps>()(HqInvestStoreInsertPopup)
