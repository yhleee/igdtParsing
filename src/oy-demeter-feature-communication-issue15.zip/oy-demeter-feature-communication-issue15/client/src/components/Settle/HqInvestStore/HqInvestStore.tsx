import * as React from 'react'
import HqInvestStoreList from './HqInvestStoreList'
import { Button, Menu } from 'antd'
import InvestStoreSearchForm from './HqInvestStoreSearchForm'
import { IHqInvestStore } from './entity/hqInvestStore'
import { getHqInvestStoreList, updateInvestStoreActiveType } from '../../../services/settle/investStore'
import { alertPopup } from '../../../common/utils'

interface IProps {}
interface IState {
  list: IHqInvestStore[]
}

class HqInvestStore extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      list: null,
    }
  }

  async componentDidMount() {
    await this.getHqInvestStoreList({
      page: 1,
      size: 100000,
    })
  }

  getHqInvestStoreList = async searchParam => {
    const hqInvestStoreList: IHqInvestStore[] = await getHqInvestStoreList(searchParam)
    if (hqInvestStoreList) {
      const datasource = []
      hqInvestStoreList.forEach((item, index) => {
        datasource.push({
          ...item,
        })
      })

      this.setState({
        list: datasource,
      })
    }
  }

  handleActiveType = async () => {
    if (window.confirm('정말 확정 하시겠습니까?')) {
      await updateInvestStoreActiveType({
        investStoreActiveType: 'Y',
      }).then(response => {
        alertPopup(response)
      })
    }
  }

  handleActiveTypeCancel = async () => {
    if (window.confirm('정말 확정을 취소 하시겠습니까?')) {
      await updateInvestStoreActiveType({
        investStoreActiveType: 'N',
      }).then(response => {
        alertPopup(response)
      })
    }
  }

  render() {
    const { list } = this.state

    return (
      <>
        <div>
          <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
            <div style={{ display: 'table', width: '100%' }}>
              <div style={{ display: 'table-cell', width: '50%' }}>
                <h2>■ 신규/리뉴얼 매장 장비 투자(본사)</h2>
              </div>
            </div>
            <InvestStoreSearchForm getHqInvestStoreList={this.getHqInvestStoreList} />
            <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
              <Button type="default" onClick={() => this.handleActiveType()}>
                확정
              </Button>&nbsp;&nbsp;
              <Button type="default" onClick={() => this.handleActiveTypeCancel()}>
                확정취소
              </Button>
            </div>
            <HqInvestStoreList hqInvestStoreList={list} />
          </div>
        </div>
      </>
    )
  }
}

export default HqInvestStore
