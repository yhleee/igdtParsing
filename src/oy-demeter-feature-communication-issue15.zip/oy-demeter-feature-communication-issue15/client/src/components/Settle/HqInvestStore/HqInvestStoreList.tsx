import * as React from 'react'
import { Badge, Button, Modal, Table } from 'antd'
import HqInvestStoreInsertPopup from './HqInvestStoreInsertPopup'
import { delHqInvestStore } from '../../../services/settle/investStore'
import { alertPopup } from '../../../common/utils'
import { IHqInvestStore, IHqInvestStoreDetail } from './entity/hqInvestStore'
import { ColumnProps } from 'antd/es/table'

interface IProps {
  hqInvestStoreList: IHqInvestStore[]
}

interface IState {
  detail: IHqInvestStoreDetail
  visible: boolean
}

class HqInvestStoreList extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      detail: null,
      visible: false,
    }
  }

  investStoreDelete = async investStoreNo => {
    if (window.confirm('정말 삭제 하시겠습니까?')) {
      await delHqInvestStore(investStoreNo).then(response => {
        alertPopup(response)
        location.reload()
      })
    }
  }

  // ------------------------------- Layer Popup Start ------------------------------
  investStorePopup = (data: IHqInvestStore) => {
    if (data) {
      const hqInvestStoreDetail = {
        investStoreNo: data.investStoreNo,
        investStoreName: data.investStoreName,
        investStoreOpenDate: data.investStoreOpenDate,
        investStoreType: data.investStoreType,
        investStoreRemarks: data.investStoreRemarks,
        newInvestStoreAssetType: undefined,
        newInvestStoreAssetRack: undefined,
        newInvestStoreAssetVpn: undefined,
        newInvestStoreAssetLed: undefined,
        newInvestStoreAssetSettopPc: undefined,
        newInvestStoreAssetPos: undefined,
        newInvestStoreAssetSurgeProtector: undefined,
        newInvestStoreAssetHub: undefined,
        newInvestStoreAssetHandScanner: undefined,
        newInvestStoreAssetPda: undefined,
        newInvestStoreAssetSignPad: undefined,
        newInvestStoreAssetCat: undefined,
        newInvestStoreAssetSwitch: undefined,
        newInvestStoreAssetIcTerminal: undefined,
        reInvestStoreAssetType: undefined,
        reInvestStoreAssetRack: undefined,
        reInvestStoreAssetVpn: undefined,
        reInvestStoreAssetLed: undefined,
        reInvestStoreAssetSettopPc: undefined,
        reInvestStoreAssetPos: undefined,
        reInvestStoreAssetSurgeProtector: undefined,
        reInvestStoreAssetHub: undefined,
        reInvestStoreAssetHandScanner: undefined,
        reInvestStoreAssetPda: undefined,
        reInvestStoreAssetSignPad: undefined,
        reInvestStoreAssetCat: undefined,
        reInvestStoreAssetSwitch: undefined,
        reInvestStoreAssetIcTerminal: undefined,
      }

      if (data.investStoreAssetList) {
        data.investStoreAssetList.forEach(element => {
          if (element.investStoreAssetType === 1) {
            // 신규
            hqInvestStoreDetail.newInvestStoreAssetType = element.investStoreAssetType
            hqInvestStoreDetail.newInvestStoreAssetRack = element.investStoreAssetRack
            hqInvestStoreDetail.newInvestStoreAssetVpn = element.investStoreAssetVpn
            hqInvestStoreDetail.newInvestStoreAssetLed = element.investStoreAssetLed
            hqInvestStoreDetail.newInvestStoreAssetSettopPc = element.investStoreAssetSettopPc
            hqInvestStoreDetail.newInvestStoreAssetPos = element.investStoreAssetPos
            hqInvestStoreDetail.newInvestStoreAssetSurgeProtector = element.investStoreAssetSurgeProtector
            hqInvestStoreDetail.newInvestStoreAssetHub = element.investStoreAssetHub
            hqInvestStoreDetail.newInvestStoreAssetHandScanner = element.investStoreAssetHandScanner
            hqInvestStoreDetail.newInvestStoreAssetPda = element.investStoreAssetPda
            hqInvestStoreDetail.newInvestStoreAssetSignPad = element.investStoreAssetSignPad
            hqInvestStoreDetail.newInvestStoreAssetCat = element.investStoreAssetCat
            hqInvestStoreDetail.newInvestStoreAssetSwitch = element.investStoreAssetSwitch
            hqInvestStoreDetail.newInvestStoreAssetIcTerminal = element.investStoreAssetIcTerminal
          } else {
            // 재사용
            hqInvestStoreDetail.reInvestStoreAssetType = element.investStoreAssetType
            hqInvestStoreDetail.reInvestStoreAssetRack = element.investStoreAssetRack
            hqInvestStoreDetail.reInvestStoreAssetVpn = element.investStoreAssetVpn
            hqInvestStoreDetail.reInvestStoreAssetLed = element.investStoreAssetLed
            hqInvestStoreDetail.reInvestStoreAssetSettopPc = element.investStoreAssetSettopPc
            hqInvestStoreDetail.reInvestStoreAssetPos = element.investStoreAssetPos
            hqInvestStoreDetail.reInvestStoreAssetSurgeProtector = element.investStoreAssetSurgeProtector
            hqInvestStoreDetail.reInvestStoreAssetHub = element.investStoreAssetHub
            hqInvestStoreDetail.reInvestStoreAssetHandScanner = element.investStoreAssetHandScanner
            hqInvestStoreDetail.reInvestStoreAssetPda = element.investStoreAssetPda
            hqInvestStoreDetail.reInvestStoreAssetSignPad = element.investStoreAssetSignPad
            hqInvestStoreDetail.reInvestStoreAssetCat = element.investStoreAssetCat
            hqInvestStoreDetail.reInvestStoreAssetSwitch = element.investStoreAssetSwitch
            hqInvestStoreDetail.reInvestStoreAssetIcTerminal = element.investStoreAssetIcTerminal
          }
        })
      }

      this.setState({
        visible: true,
        detail: hqInvestStoreDetail,
      })
    } else {
      this.setState({
        visible: true,
        detail: null,
      })
    }
  }

  handleCancel = () => {
    this.setState({
      visible: false,
      detail: null,
    })
  }
  // ------------------------------- Layer Popup End ------------------------------

  getColumns = () => {
    const investStoreDelete = this.investStoreDelete
    const investStorePopup = this.investStorePopup

    return [
      { title: '코스트센터코드', dataIndex: 'toCstCntrCd', key: 'toCstCntrCd' },
      { title: '매장명', dataIndex: 'investStoreName', key: 'investStoreName' },
      {
        title: '오픈일',
        dataIndex: 'investStoreOpenDate',
        key: 'investStoreOpenDate',
        render(value) {
          return value.substr(0, value.length - 9).replace(/-/gi, '/')
        },
      },
      {
        title: '신규/리뉴얼',
        dataIndex: 'investStoreType',
        key: 'investStoreType',
        render(value) {
          return value === 1 ? '신규점' : '리뉴얼'
        },
      },
      { title: '비고', dataIndex: 'investStoreRemarks', key: 'investStoreRemarks' },
      {
        title: 'updateAction',
        key: 'operation',
        align: 'center',
        render(data) {
          return <Button onClick={() => investStorePopup(data)}>수정</Button>
        },
      },
      {
        title: 'deleteAction',
        key: 'operation',
        align: 'center',
        render(data) {
          return <Button onClick={() => investStoreDelete(data.investStoreNo)}>삭제</Button>
        },
      },
    ]
  }

  getNestedColumns = () => {
    return [
      {
        title: '신규/재사용',
        dataIndex: 'investStoreAssetType',
        key: 'investStoreAssetType',
        render(value) {
          return value === 1 ? '신규' : '재사용'
        },
      },
      {
        title: 'RACK',
        key: 'investStoreAssetRack',
        render: data => {
          let retVal = data.investStoreAssetRack
          if (data.investStoreAssetType === 1 && data.investStoreAssetRackYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetRack}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'VPN',
        key: 'investStoreAssetVpn',
        render: data => {
          let retVal = data.investStoreAssetVpn
          if (data.investStoreAssetType === 1 && data.investStoreAssetVpnYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetVpn}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'LED',
        key: 'investStoreAssetLed',
        render: data => {
          let retVal = data.investStoreAssetLed
          if (data.investStoreAssetType === 1 && data.investStoreAssetLedYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetLed}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: '셋탑PC',
        key: 'investStoreAssetSettopPc',
        render: data => {
          let retVal = data.investStoreAssetSettopPc
          if (data.investStoreAssetType === 1 && data.investStoreAssetSettopPcYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetSettopPc}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'POS',
        key: 'investStoreAssetPos',
        render: data => {
          let retVal = data.investStoreAssetPos
          if (data.investStoreAssetType === 1 && data.investStoreAssetPosYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetPos}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: '서지보호기',
        key: 'investStoreAssetSurgeProtector',
        render: data => {
          let retVal = data.investStoreAssetSurgeProtector
          if (data.investStoreAssetType === 1 && data.investStoreAssetSurgeProtectorYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetSurgeProtector}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'HUB',
        key: 'investStoreAssetHub',
        render: data => {
          let retVal = data.investStoreAssetHub
          if (data.investStoreAssetType === 1 && data.investStoreAssetHubYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetHub}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: '핸드스캐너',
        key: 'investStoreAssetHandScanner',
        render: data => {
          let retVal = data.investStoreAssetHandScanner
          if (data.investStoreAssetType === 1 && data.investStoreAssetHandScannerYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetHandScanner}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'PDA',
        key: 'investStoreAssetPda',
        render: data => {
          let retVal = data.investStoreAssetPda
          if (data.investStoreAssetType === 1 && data.investStoreAssetPdaYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetPda}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: '사인패드',
        key: 'investStoreAssetSignPad',
        render: data => {
          let retVal = data.investStoreAssetSignPad
          if (data.investStoreAssetType === 1 && data.investStoreAssetSignPadYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetSignPad}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'CAT',
        key: 'investStoreAssetCat',
        render: data => {
          let retVal = data.investStoreAssetCat
          if (data.investStoreAssetType === 1 && data.investStoreAssetCatYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetCat}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: '스위치',
        key: 'investStoreAssetSwitch',
        render: data => {
          let retVal = data.investStoreAssetSwitch
          if (data.investStoreAssetType === 1 && data.investStoreAssetSwitchYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetSwitch}
              </span>
            )
          }

          return retVal
        },
      },
      {
        title: 'IC단말기',
        key: 'investStoreAssetIcTerminal',
        render: data => {
          let retVal = data.investStoreAssetIcTerminal
          if (data.investStoreAssetType === 1 && data.investStoreAssetIcTerminalYn === 'N') {
            retVal = (
              <span>
                <Badge status="error" />
                {data.investStoreAssetIcTerminal}
              </span>
            )
          }

          return retVal
        },
      },
    ]
  }

  render() {
    const { detail, visible } = this.state
    const { hqInvestStoreList } = this.props

    // ------------------------------- 1depth --------------------------------------
    // @ts-ignore
    const _columns: ColumnProps = this.getColumns().map(col => {
      return {
        ...col,
        onCell: record => ({
          record,
          dataIndex: col.dataIndex,
          title: col.title,
        }),
      }
    })

    const getHqInvestStoreList = () => {
      const parseHqInvestStoreList = []
      for (const key in hqInvestStoreList) {
        const hqInvestStoreObj = {
          investStoreNo: hqInvestStoreList[key].investStoreNo,
          toCstCntrCd: hqInvestStoreList[key].toCstCntrCd,
          investStoreName: hqInvestStoreList[key].investStoreName,
          investStoreOpenDate: hqInvestStoreList[key].investStoreOpenDate,
          investStoreType: hqInvestStoreList[key].investStoreType,
          investStoreRemarks: hqInvestStoreList[key].investStoreRemarks,
          sysRegDtime: hqInvestStoreList[key].sysRegDtime,
          sysRegrId: hqInvestStoreList[key].sysRegrId,
          investStoreAssetList: [],
        }

        // tslint:disable-next-line:no-increment-decrement
        for (let k = 0; k < 2; k++) {
          hqInvestStoreObj.investStoreAssetList.push(hqInvestStoreList[key].investStoreAssetList[k])
        }

        parseHqInvestStoreList.push(hqInvestStoreObj)
      }

      return parseHqInvestStoreList
    }
    // ------------------------------- 1depth End --------------------------------------

    // ------------------------------- 2depth --------------------------------------
    const nestedColumns = this.getNestedColumns().map(col => {
      return {
        ...col,
        onCell: record => ({
          record,
          dataIndex: col.dataIndex,
          title: col.title,
        }),
      }
    })

    const expandedRowRender = record => {
      const nestedData = record.investStoreAssetList
      return <Table columns={nestedColumns} dataSource={nestedData} pagination={false} bordered={true} size="middle" />
    }
    // ------------------------------- 2depth End --------------------------------------

    // const data = []

    // console.log(parseData[i].investStoreNo)
    // console.log(parseData[i].toCstCntrCd)
    // console.log(parseData[i].investStoreName)
    // console.log(parseData[i].investStoreOpenDate)
    // console.log(parseData[i].investStoreType)
    // console.log(parseData[i].investStoreRemarks)
    // console.log(parseData[i].sysRegDtime)
    // console.log(parseData[i].sysRegrId)

    // Foreach 에서 table의 defaultExpandAllRows=true값이 적용 안되는 현상 때문이 미리 가공
    /*
    for (const key in hqInvestStoreList) {
      const dataFirstObj = {
        investStoreNo: hqInvestStoreList[key].investStoreNo,
        toCstCntrCd: hqInvestStoreList[key].toCstCntrCd,
        investStoreName: hqInvestStoreList[key].investStoreName,
        investStoreOpenDate: hqInvestStoreList[key].investStoreOpenDate,
        investStoreType: hqInvestStoreList[key].investStoreType,
        investStoreRemarks: hqInvestStoreList[key].investStoreRemarks,
        sysRegDtime: hqInvestStoreList[key].sysRegDtime,
        sysRegrId: hqInvestStoreList[key].sysRegrId,
        investStoreAssetList: []
      }

      // tslint:disable-next-line:no-increment-decrement
      for (let k=0; k<2; k++) {
        dataFirstObj.investStoreAssetList.push(hqInvestStoreList[key].investStoreAssetList[k])
      }

      data.push(dataFirstObj)
    }
     */

    // tslint:disable-next-line:no-increment-decrement
    // for (let i = 0; i < 3; i++) {
    //
    //   const dataObj = {
    //     investStoreNo: 2,
    //     toCstCntrCd: '20009384',
    //     investStoreName: '개봉역북부점2호점',
    //     investStoreOpenDate: '2019-09-27 16:44:38',
    //     investStoreType: 1,
    //     investStoreRemarks: '동여의도점 폐점 매장 회수 POS 2대, PDA 1대, VPN 1대, 셋탑PC 1대 이전설치',
    //     sysRegDtime: '2014-12-24 23:12:00',
    //     sysRegrId: 'bkjeon',
    //     investStoreAssetList: [
    //       {
    //         investStoreAssetNo: 17,
    //         investStoreNo: 4,
    //         investStoreAssetType: 1,
    //         investStoreAssetRack: 3,
    //         investStoreAssetVpn: 0,
    //         investStoreAssetLed: 10,
    //         investStoreAssetSettopPc: 0,
    //         investStoreAssetPos: 0,
    //         investStoreAssetSurgeProtector: 0,
    //         investStoreAssetHub: 0,
    //         investStoreAssetHandScanner: 0,
    //         investStoreAssetPda: 0,
    //         investStoreAssetSignPad: 0,
    //         investStoreAssetCat: 0,
    //         investStoreAssetSwitch: 0,
    //         investStoreAssetIcTerminal: 0,
    //         sysRegDtime: "2019-11-14 18:39:58",
    //         sysRegrId: "bkjeon",
    //         investStoreAssetRackYn: "N",
    //         investStoreAssetVpnYn: "N",
    //         investStoreAssetLedYn: "N",
    //         investStoreAssetSettopPcYn: "N",
    //         investStoreAssetPosYn: "N",
    //         investStoreAssetSurgeProtectorYn: "N",
    //         investStoreAssetHubYn: "N",
    //         investStoreAssetHandScannerYn: "N",
    //         investStoreAssetPdaYn: "N",
    //         investStoreAssetSignPadYn: "N",
    //         investStoreAssetCatYn: "N",
    //         investStoreAssetSwitchYn: "N",
    //         investStoreAssetIcTerminalYn: "N"
    //       },
    //       {
    //         investStoreAssetNo: 28,
    //         investStoreNo: 4,
    //         investStoreAssetType: 2,
    //         investStoreAssetRack: 2,
    //         investStoreAssetVpn: 0,
    //         investStoreAssetLed: 0,
    //         investStoreAssetSettopPc: 0,
    //         investStoreAssetPos: 0,
    //         investStoreAssetSurgeProtector: 0,
    //         investStoreAssetHub: 0,
    //         investStoreAssetHandScanner: 0,
    //         investStoreAssetPda: 0,
    //         investStoreAssetSignPad: 0,
    //         investStoreAssetCat: 0,
    //         investStoreAssetSwitch: 0,
    //         investStoreAssetIcTerminal: 0,
    //         sysRegDtime: '2019-11-14 18:39:58',
    //         sysRegrId: 'bkjeon',
    //         investStoreAssetRackYn: null,
    //         investStoreAssetVpnYn: null,
    //         investStoreAssetLedYn: null,
    //         investStoreAssetSettopPcYn: null,
    //         investStoreAssetPosYn: null,
    //         investStoreAssetSurgeProtectorYn: null,
    //         investStoreAssetHubYn: null,
    //         investStoreAssetHandScannerYn: null,
    //         investStoreAssetPdaYn: null,
    //         investStoreAssetSignPadYn: null,
    //         investStoreAssetCatYn: null,
    //         investStoreAssetSwitchYn: null,
    //         investStoreAssetIcTerminalYn: null
    //       }
    //     ],
    //   }
    //   data.push(dataObj)
    //
    //
    //
    //   /*
    //   const dataObj = {
    //     investStoreNo: 2,
    //     toCstCntrCd: '20009384',
    //     investStoreName: '개봉역북부점2호점',
    //     investStoreOpenDate: '2019-09-27 16:44:38',
    //     investStoreType: 1,
    //     investStoreRemarks: '동여의도점 폐점 매장 회수 POS 2대, PDA 1대, VPN 1대, 셋탑PC 1대 이전설치',
    //     sysRegDtime: '2014-12-24 23:12:00',
    //     sysRegrId: 'bkjeon',
    //     investStoreAssetList: [
    //       {
    //         investStoreAssetNo: 17,
    //         investStoreNo: 4,
    //         investStoreAssetType: 1,
    //         investStoreAssetRack: 3,
    //         investStoreAssetVpn: 0,
    //         investStoreAssetLed: 10,
    //         investStoreAssetSettopPc: 0,
    //         investStoreAssetPos: 0,
    //         investStoreAssetSurgeProtector: 0,
    //         investStoreAssetHub: 0,
    //         investStoreAssetHandScanner: 0,
    //         investStoreAssetPda: 0,
    //         investStoreAssetSignPad: 0,
    //         investStoreAssetCat: 0,
    //         investStoreAssetSwitch: 0,
    //         investStoreAssetIcTerminal: 0,
    //         sysRegDtime: "2019-11-14 18:39:58",
    //         sysRegrId: "bkjeon",
    //         investStoreAssetRackYn: "N",
    //         investStoreAssetVpnYn: "N",
    //         investStoreAssetLedYn: "N",
    //         investStoreAssetSettopPcYn: "N",
    //         investStoreAssetPosYn: "N",
    //         investStoreAssetSurgeProtectorYn: "N",
    //         investStoreAssetHubYn: "N",
    //         investStoreAssetHandScannerYn: "N",
    //         investStoreAssetPdaYn: "N",
    //         investStoreAssetSignPadYn: "N",
    //         investStoreAssetCatYn: "N",
    //         investStoreAssetSwitchYn: "N",
    //         investStoreAssetIcTerminalYn: "N"
    //       },
    //       {
    //         investStoreAssetNo: 28,
    //         investStoreNo: 4,
    //         investStoreAssetType: 2,
    //         investStoreAssetRack: 2,
    //         investStoreAssetVpn: 0,
    //         investStoreAssetLed: 0,
    //         investStoreAssetSettopPc: 0,
    //         investStoreAssetPos: 0,
    //         investStoreAssetSurgeProtector: 0,
    //         investStoreAssetHub: 0,
    //         investStoreAssetHandScanner: 0,
    //         investStoreAssetPda: 0,
    //         investStoreAssetSignPad: 0,
    //         investStoreAssetCat: 0,
    //         investStoreAssetSwitch: 0,
    //         investStoreAssetIcTerminal: 0,
    //         sysRegDtime: '2019-11-14 18:39:58',
    //         sysRegrId: 'bkjeon',
    //         investStoreAssetRackYn: null,
    //         investStoreAssetVpnYn: null,
    //         investStoreAssetLedYn: null,
    //         investStoreAssetSettopPcYn: null,
    //         investStoreAssetPosYn: null,
    //         investStoreAssetSurgeProtectorYn: null,
    //         investStoreAssetHubYn: null,
    //         investStoreAssetHandScannerYn: null,
    //         investStoreAssetPdaYn: null,
    //         investStoreAssetSignPadYn: null,
    //         investStoreAssetCatYn: null,
    //         investStoreAssetSwitchYn: null,
    //         investStoreAssetIcTerminalYn: null
    //       }
    //     ],
    //   }
    //   data.push(dataObj)
    //   */
    //
    // }

    return (
      <>
        <div>
          <Table
            className="components-table-demo-nested"
            columns={_columns}
            expandedRowRender={expandedRowRender}
            dataSource={hqInvestStoreList}
            bordered={true}
            defaultExpandAllRows={true}
            size="middle"
          />
          <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
            <Button type="default" onClick={() => this.investStorePopup(null)}>
              신규 데이터 추가
            </Button>
          </div>
          <Modal
            title={detail === null ? '등록' : '수정'}
            visible={visible}
            onCancel={this.handleCancel}
            footer={null}
            closable={false}
            width={1500}
          >
            <HqInvestStoreInsertPopup detail={detail} handleCancel={this.handleCancel} />
          </Modal>
        </div>
      </>
    )
  }
}

export default HqInvestStoreList
