export interface IHqInvestStore {
  sysRegrId: string
  sysRegDtime: string
  investStoreNo: number
  toCstCntrCd: string
  investStoreName: string
  investStoreOpenDate: string
  investStoreType: number
  investStoreRemarks: string
  investStoreAssetList: any
}

export interface IHqInvestStoreDetail {
  investStoreName: string
  investStoreOpenDate: any
  investStoreType: number
  investStoreRemarks: string
  newInvestStoreAssetType: number
  newInvestStoreAssetRack: number
  newInvestStoreAssetVpn: number
  newInvestStoreAssetLed: number
  newInvestStoreAssetSettopPc: number
  newInvestStoreAssetPos: number
  newInvestStoreAssetSurgeProtector: number
  newInvestStoreAssetHub: number
  newInvestStoreAssetHandScanner: number
  newInvestStoreAssetPda: number
  newInvestStoreAssetSignPad: number
  newInvestStoreAssetCat: number
  newInvestStoreAssetSwitch: number
  newInvestStoreAssetIcTerminal: number
  reInvestStoreAssetType: number
  reInvestStoreAssetRack: number
  reInvestStoreAssetVpn: number
  reInvestStoreAssetLed: number
  reInvestStoreAssetSettopPc: number
  reInvestStoreAssetPos: number
  reInvestStoreAssetSurgeProtector: number
  reInvestStoreAssetHub: number
  reInvestStoreAssetHandScanner: number
  reInvestStoreAssetPda: number
  reInvestStoreAssetSignPad: number
  reInvestStoreAssetCat: number
  reInvestStoreAssetSwitch: number
  reInvestStoreAssetIcTerminal: number
}
