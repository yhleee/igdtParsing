import * as React from 'react'
import { Form, Row, Col, Input, Button, Collapse, DatePicker, Select } from 'antd'
const { MonthPicker } = DatePicker

interface IProps {
  form: any
  getHqInvestStoreList: Function
}

interface IState {}

const { Option } = Select
const { Panel } = Collapse

class HqInvestStoreSearchForm extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
  }

  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      const { getHqInvestStoreList } = this.props
      const parseInvestStoreOpenDate = values['investStoreOpenDate']
        ? values['investStoreOpenDate'].format('YYYY-MM')
        : null
      const listSearchParam = {
        page: 1,
        size: 100000,
        investStoreOpenYearMonth: parseInvestStoreOpenDate ? parseInvestStoreOpenDate : null,
      }
      getHqInvestStoreList(listSearchParam)
    })
  }

  btnReset = () => {
    this.props.form.resetFields()
  }

  render() {
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }

    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const { getFieldDecorator } = this.props.form

    return (
      <>
        <div>
          <Collapse>
            <Panel header="검색조건 설정" key="1">
              <Row>
                <Col>
                  <Form onSubmit={this.handleSubmit}>
                    <Form.Item label="기간조회" {...formItemLayout}>
                      {getFieldDecorator('investStoreOpenDate')(<MonthPicker />)}
                    </Form.Item>
                    <Form.Item {...buttonItemLayout}>
                      <Row>
                        <Col span={24} style={{ textAlign: 'center' }}>
                          <Button type="primary" htmlType="submit">
                            검색
                          </Button>
                        </Col>
                      </Row>
                    </Form.Item>
                  </Form>
                </Col>
              </Row>
            </Panel>
          </Collapse>
        </div>
        <br />
      </>
    )
  }
}

export default Form.create<IProps>()(HqInvestStoreSearchForm)
