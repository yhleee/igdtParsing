import * as React from 'react'
import { Button, Table, Tabs } from 'antd'
import { IPtInvestStore } from './entity/ptInvestStore'
import { getPtInvestStoreCSVDownLoad, ptInvestStoreCSVUpLoad } from '../../../services/settle/investStore'
import { alertPopup } from '../../../common/utils'
import { ColumnProps } from 'antd/es/table'

interface IProps {
  ptInvestStoreList: IPtInvestStore[]
  investStoreCategoryNo: number
}
interface IState {
  selectedFile: any
}

class PtInvestStoreList extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      selectedFile: null,
    }
  }

  getColumns = () => {
    return [
      {
        title: '매장명',
        dataIndex: 'investStoreName',
        key: 'investStoreName',
        align: 'center',
      },
      {
        title: '신규/리뉴얼',
        dataIndex: 'investStoreType',
        key: 'investStoreType',
        align: 'center',
        render(value) {
          return value === 1 ? '신규점' : '리뉴얼'
        },
      },
      {
        title: '장비명',
        dataIndex: 'investStoreAssetNo',
        key: 'investStoreAssetNo',
        align: 'center',
        render(value) {
          switch (value) {
            case 1:
              return 'RACK'
              break
            case 2:
              return 'VPN'
              break
            case 3:
              return 'IC단말기'
              break
            case 4:
              return 'LED'
              break
            case 5:
              return '셋탑PC'
              break
            case 6:
              return 'POS'
              break
            case 7:
              return '서지보호기'
              break
            case 8:
              return 'HUB'
              break
            case 9:
              return '핸드스캐너'
              break
            case 10:
              return 'PDA'
              break
            case 11:
              return '사인패드'
              break
            case 12:
              return 'CAT'
              break
            case 13:
              return '스위치'
              break
          }
        },
      },
      {
        title: '수량',
        dataIndex: 'investStoreCount',
        key: 'investStoreCount',
        align: 'center',
      },
      {
        title: '단가',
        dataIndex: 'investStorePrice',
        key: 'investStorePrice',
        align: 'center',
        render(value) {
          return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
      },
      {
        title: '합계',
        key: 'investStorePriceSum',
        align: 'center',
        render(data) {
          return (data.investStorePrice * data.investStoreCount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
      },
      {
        title: '비고',
        dataIndex: 'investStoreRemarks',
        key: 'investStoreRemarks',
        align: 'center',
      },
    ]
  }

  getAssetCSVDownLoad = async investStoreCateNo => {
    const csvData = await getPtInvestStoreCSVDownLoad({
      investStoreCategoryNo: investStoreCateNo,
    })

    const blob = new Blob([csvData], {
      type: 'application/octet-stream;charset=EUC-KR',
    })

    // FOR OTHER BROWSERS
    const csvUrl = URL.createObjectURL(blob)

    const hiddenElement = document.createElement('a')
    hiddenElement.href = csvUrl
    hiddenElement.target = '_blank'
    hiddenElement.download = 'settle_pt_invest_store.xls'
    hiddenElement.click()
  }

  handleFileInput(e) {
    this.setState({
      selectedFile: e.target.files[0],
    })
  }

  setPtInvestStoreCSVUpLoad = async investStoreCategoryNo => {
    if (confirm('업로드 하시겠습니까?')) {
      if (!this.state.selectedFile) {
        alert('업로드할 파일을 선택하여 주시길 바랍니다.')
        return false
      }

      const formData = new FormData()
      formData.append('uploadFile', this.state.selectedFile)
      formData.append('investStoreCategoryNo', investStoreCategoryNo)

      await ptInvestStoreCSVUpLoad(formData).then(response => {
        if (response.result === 'SUCCESS') {
          location.reload()
        } else {
          alertPopup(response.message)
        }
      })
    }
  }

  render() {
    const { ptInvestStoreList, investStoreCategoryNo } = this.props

    // @ts-ignore
    const _columns: ColumnProps = this.getColumns().map(col => {
      return {
        ...col,
        onCell: record => ({
          record,
          dataIndex: col.dataIndex,
          title: col.title,
        }),
      }
    })

    return (
      <>
        <div style={{ padding: '20px 20px', width: '100%', textAlign: 'right' }}>
          <input type="file" id="csv_file" name="csv_file" onChange={e => this.handleFileInput(e)} accept=".xls" />
          <Button type="default" onClick={() => this.setPtInvestStoreCSVUpLoad(investStoreCategoryNo)}>
            업로드
          </Button>&nbsp;&nbsp;
          <Button type="default" onClick={() => this.getAssetCSVDownLoad(investStoreCategoryNo)}>
            다운로드
          </Button>
        </div>
        <div>
          <Table
            columns={_columns}
            dataSource={ptInvestStoreList}
            scroll={{ x: 'max-content' }}
            bordered={true}
            size="middle"
          />
        </div>
      </>
    )
  }
}

export default PtInvestStoreList
