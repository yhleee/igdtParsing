export interface IPtInvestStore {
  investStoreNo: number
  investStoreName: string
  investStoreType: number
  investStoreCategoryNo: number
  investStoreAssetNo: number
  investStoreCount: number
  investStorePrice: number
  investStoreRemarks: string
}
