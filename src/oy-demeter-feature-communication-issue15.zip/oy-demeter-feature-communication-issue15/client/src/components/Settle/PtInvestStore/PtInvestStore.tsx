import * as React from 'react'
import PtInvestStoreList from './PtInvestStoreList'
import { IPtInvestStore } from './entity/ptInvestStore'
import { getPtInvestStoreList } from '../../../services/settle/investStore'
import PtInvestStoreSearchForm from './PtInvestStoreSearchForm'
import { Row, Col, Layout, Menu } from 'antd'

const { Header, Content, Footer } = Layout

interface IProps {}

interface IState {
  list: IPtInvestStore[]
  searchInvestStoreCategoryNo: number
}

class PtInvestStore extends React.Component<IProps, IState> {
  contentsWrapEl: React.RefObject<HTMLDivElement>

  constructor(props) {
    super(props)
    this.contentsWrapEl = React.createRef()
    this.state = {
      list: null,
      searchInvestStoreCategoryNo: null,
    }
  }

  async componentDidMount() {
    await this.getPtInvestStoreList({
      page: 1,
      size: 100000,
      investStoreCategoryNo: 1,
    })
  }

  getPtInvestStoreList = async searchParam => {
    const ptInvestStoreList: IPtInvestStore[] = await getPtInvestStoreList(searchParam)
    if (ptInvestStoreList) {
      const datasource = []
      ptInvestStoreList.forEach((item, index) => {
        datasource.push({
          ...item,
        })
      })

      this.setState({
        list: datasource,
        searchInvestStoreCategoryNo: searchParam.investStoreCategoryNo,
      })
    }
  }

  render() {
    const { list, searchInvestStoreCategoryNo } = this.state

    return (
      <>
        <div>
          <div style={{ padding: '20px 10px' }} ref={this.contentsWrapEl}>
            <div style={{ display: 'table', width: '100%' }}>
              <div style={{ display: 'table-cell', width: '50%' }}>
                <h2>■ 신규/리뉴얼 매장 장비 투자(업체별)</h2>
              </div>
            </div>
            <PtInvestStoreSearchForm getPtInvestStoreList={this.getPtInvestStoreList} />
            <PtInvestStoreList ptInvestStoreList={list} investStoreCategoryNo={searchInvestStoreCategoryNo} />
          </div>
        </div>
      </>
    )
  }
}

export default PtInvestStore
