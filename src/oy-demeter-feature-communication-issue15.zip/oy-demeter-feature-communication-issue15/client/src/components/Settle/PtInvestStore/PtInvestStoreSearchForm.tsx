import * as React from 'react'
import { Form, Radio } from 'antd'

interface IProps {
  form: any
  getPtInvestStoreList: Function
}

interface IState {
  selectInvestStoreCategoryNo: number
}

class PtInvestStoreSearchForm extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      selectInvestStoreCategoryNo: 1,
    }
  }

  onChange = e => {
    const { getPtInvestStoreList } = this.props

    const listSearchParam = {
      page: 1,
      size: 100000,
      investStoreCategoryNo: e.target.value ? Number(e.target.value) : null,
    }
    getPtInvestStoreList(listSearchParam)

    this.setState({
      selectInvestStoreCategoryNo: e.target.value,
    })
  }

  render() {
    return (
      <>
        <div>
          <br />
          <br />
          <Radio.Group onChange={this.onChange} value={this.state.selectInvestStoreCategoryNo}>
            <Radio value={1}>RACK</Radio>
            <Radio value={2}>VPN</Radio>
            <Radio value={3}>IC단말기</Radio>
            <Radio value={4}>CJ올리브네트웍스</Radio>
          </Radio.Group>
        </div>
        <br />
      </>
    )
  }
}

export default Form.create<IProps>()(PtInvestStoreSearchForm)
