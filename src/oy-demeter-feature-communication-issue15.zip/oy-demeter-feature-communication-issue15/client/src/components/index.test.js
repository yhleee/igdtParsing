"use strict";
exports.__esModule = true;
var React = require("react");
var ReactDOM = require("react-dom");
var index_1 = require("./index");
it('renders without crashing', function () {
    var div = document.createElement('div');
    ReactDOM.render(<index_1["default"] />, div);
});
//# sourceMappingURL=index.test.js.map