import * as React from 'react'
import { Icon, List } from 'antd'
import InfiniteScroll from 'react-infinite-scroller'
import { IUser } from '../Authority/entity/User'

interface IProps {
  userType: any
  manageUsers: Function
  users: IUser[]
}
interface IState {}

class UserList extends React.Component<IProps, IState> {
  handleUser = user => () => {
    const { userType, manageUsers } = this.props
    manageUsers(userType, user)
  }

  render() {
    const { userType, users } = this.props
    return (
      <div
        style={{
          border: '1px solid #e8e8e8',
          borderRadius: '4px',
          overflow: 'auto',
          padding: '8px 24px',
          height: '250px',
        }}
      >
        <InfiniteScroll initialLoad={false} pageStart={0} loadMore={() => {}} hasMore={false} useWindow={false}>
          <List
            dataSource={users}
            renderItem={user => (
              <List.Item key={user.userNo}>
                <List.Item.Meta
                  title={
                    <>
                      <span>{user.loginId}</span>&nbsp;
                      {userType === 'groupUsers' ? (
                        <Icon type="down-square" theme="twoTone" onClick={this.handleUser(user)} />
                      ) : (
                        <Icon type="up-square" theme="twoTone" onClick={this.handleUser(user)} />
                      )}
                    </>
                  }
                />
              </List.Item>
            )}
          />
        </InfiniteScroll>
      </div>
    )
  }
}

export default UserList
