import * as React from 'react'
import { Button, Col, Form, Input, Row } from 'antd'

import { addGroup, updateGroup } from '../../services/authority/userGroup'

interface IProps {
  handleModalCancel: any
  groupModal: any
  form: any
}
interface IState {}

class GroupForm extends React.Component<IProps, IState> {
  handleSubmit = e => {
    e.preventDefault()
    const { selectedGroup, modalType } = this.props.groupModal
    console.log(selectedGroup)
    this.props.form.validateFields(async (err, values) => {
      if (!err) {
        console.log('Received values of form: ', values)
        if (modalType === 'edit') {
          values.groupNo = selectedGroup.groupNo
          await updateGroup(values)
        } else {
          await addGroup(values)
        }
      }
    })
    this.resetAndClose()
  }

  resetAndClose = () => {
    const { handleModalCancel } = this.props
    const { resetFields } = this.props.form
    resetFields()
    handleModalCancel()
  }

  render() {
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }

    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const { getFieldDecorator, setFieldsValue } = this.props.form

    const { selectedGroup, modalType } = this.props.groupModal

    return (
      <>
        <Form onSubmit={this.handleSubmit}>
          <Form.Item label="그룹명" {...formItemLayout}>
            {getFieldDecorator('groupName', {
              rules: [{ required: true, message: '메뉴명은 필수 값 입니다.' }],
              initialValue: modalType === 'edit' ? selectedGroup.groupName : undefined,
            })(<Input placeholder="그룹명을 입력하세요." />)}
          </Form.Item>
          <Form.Item {...buttonItemLayout}>
            <Row>
              <Col span={24} style={{ textAlign: 'center' }}>
                <Button type="default" onClick={this.resetAndClose}>
                  취소
                </Button>
                <Button type="primary" htmlType="submit" style={{ marginLeft: 8 }}>
                  {modalType === 'add' ? '등록' : '수정'}
                </Button>
              </Col>
            </Row>
          </Form.Item>
        </Form>
      </>
    )
  }
}

export default Form.create<IProps>()(GroupForm)
