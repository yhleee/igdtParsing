import * as React from 'react'
import { Button, Icon, List, Modal } from 'antd'
import InfiniteScroll from 'react-infinite-scroller'
import GroupForm from './GroupForm'

import { deleteGroups } from '../../services/authority/userGroup'
import { IAuthorizedGroup } from '../Authority/entity/AuthorizedGroup'

const { confirm } = Modal

interface IProps {
  handleGroupSelect: any
  groups: IAuthorizedGroup[]
}
interface IState {
  groupModal: any
}

class GroupList extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      groupModal: {
        visible: false,
        modalType: '', // add or edit
        selectedGroup: {},
      },
    }
  }

  /*
  state = {
    groupModal: {
      visible: false,
      modalType: '', // add or edit
      selectedGroup: {},
    },
  }
   */

  onClickGroup = groupNo => event => {
    this.props.handleGroupSelect(groupNo)
  }

  handleModalCancel = () => {
    const { groupModal } = this.state
    this.setState({
      groupModal: {
        ...groupModal,
        visible: false,
      },
    })
  }

  showModalForm = (modalType, group) => e => {
    console.log('modalType', modalType, 'group', group)
    e.stopPropagation()
    const { groupModal } = this.state
    this.setState({
      groupModal: {
        visible: true,
        // tslint:disable-next-line:object-shorthand-properties-first
        modalType,
        selectedGroup: group,
      },
    })
  }
  showModalConfirm = group => {
    return e => {
      e.stopPropagation()
      confirm({
        title: <>{group.menuName}를 삭제하시겠습니까?</>,
        content: '그룹이 삭제되어도 사용자는 유지됩니다.',
        async onOk() {
          const response = await deleteGroups([group.groupNo])
          if (response.result === 'SUCCESS') {
            Modal.success({
              content: '삭제되었습니다.',
            })
          } else {
            Modal.error({
              title: '오류가 발생하였습니다.',
              content: response.message,
            })
          }
        },
        onCancel() {},
      })
    }
  }

  render() {
    const { groups } = this.props
    const { groupModal } = this.state
    return (
      <div
        style={{
          border: '1px solid #e8e8e8',
          borderRadius: '4px',
          overflow: 'auto',
          padding: '8px 24px',
          height: '300px',
        }}
      >
        <InfiniteScroll initialLoad={false} pageStart={0} loadMore={() => {}} hasMore={false} useWindow={false}>
          <List
            dataSource={groups}
            renderItem={group => (
              <List.Item key={group.groupNo} onClick={this.onClickGroup(group.groupNo)}>
                <List.Item.Meta
                  title={
                    <>
                      <a>{group.groupName}</a>&nbsp;
                      <Button size={'small'} ghost={true} onClick={this.showModalForm('edit', group)}>
                        <Icon type="edit" theme="twoTone" />
                      </Button>
                      <Button size={'small'} ghost={true} onClick={this.showModalConfirm(group)}>
                        <Icon type="delete" theme="twoTone" />
                      </Button>
                    </>
                  }
                />
              </List.Item>
            )}
          />
        </InfiniteScroll>
        <Modal
          title={groupModal.modalType === 'add' ? '그룹등록' : '그룹수정'}
          visible={groupModal.visible}
          footer={null}
          closable={false}
          onCancel={this.handleModalCancel}
        >
          <GroupForm groupModal={groupModal} handleModalCancel={this.handleModalCancel} />
        </Modal>
      </div>
    )
  }
}

export default GroupList
