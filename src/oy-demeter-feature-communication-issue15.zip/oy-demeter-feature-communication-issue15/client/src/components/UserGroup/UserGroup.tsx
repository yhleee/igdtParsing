import * as React from 'react'
import { Button, Card, Col, Icon, Modal, Row } from 'antd'
import GroupList from './GroupList'
import UserList from './UserList'
import GroupForm from './GroupForm'
import { addGroupUsers, deleteGroupUsers, fetchGroups, fetchGroupUsers } from '../../services/authority/userGroup'
import { IAuthorizedGroup } from '../Authority/entity/AuthorizedGroup'

interface IProps {}
interface IState {
  groups: IAuthorizedGroup[]
  selectedGroupNo: number
  groupType: any
  groupUsers: any
  nonGroupUsers: any
  isLoadingGroupList: boolean
  groupModal: any
}

class UserGroup extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      groups: [],
      selectedGroupNo: undefined,
      groupType: undefined,
      groupUsers: [],
      nonGroupUsers: [],
      isLoadingGroupList: false,
      groupModal: {
        visible: false,
        modalType: '', // add or edit
        selectedGroup: {},
      },
    }
  }

  sleep = time => {
    return new Promise(resolve => setTimeout(resolve, time))
  }

  async componentDidMount() {
    this.loadGroupsList()
  }

  loadGroupsList = async () => {
    const groupList = await fetchGroups()
    const { groups } = this.state
    this.setState({
      groups: groupList,
      isLoadingGroupList: false,
    })
  }

  handleReloadGroupList = async () => {
    this.setState({ isLoadingGroupList: true })
    this.sleep(300).then(async () => {
      await this.loadGroupsList()
    })
  }

  handleGroupSelect = async groupNo => {
    const { groupUsers, nonGroupUsers, selectedGroupNo } = this.state

    // 그룹 유저 조회
    const groupUser = await fetchGroupUsers(groupNo)
    this.setState({
      selectedGroupNo: groupNo,
      groupUsers: groupUser.mappingUsers,
      nonGroupUsers: groupUser.unmappingUsers,
    })
  }

  showModalForm = (modalType, group) => e => {
    console.log('modalType', modalType, 'group', group)
    e.stopPropagation()
    const { groupModal } = this.state
    this.setState({
      groupModal: {
        visible: true,
        // tslint:disable-next-line:object-shorthand-properties-first
        modalType,
        selectedGroup: group,
      },
    })
  }

  handleModalCancel = () => {
    const { groupModal } = this.state
    this.setState({
      groupModal: {
        ...groupModal,
        visible: false,
      },
    })
  }

  manageUsers = async (groupType, user) => {
    const { groupUsers, nonGroupUsers, selectedGroupNo } = this.state
    let updatedGroupUsers = undefined
    let updatedNonGroupUsers = undefined
    let response = undefined
    if (groupType === 'groupUsers') {
      updatedGroupUsers = groupUsers.filter(item => item.userNo !== user.userNo)
      updatedNonGroupUsers = nonGroupUsers.concat(user)
      response = await deleteGroupUsers(selectedGroupNo, user.userNo)
    } else if (groupType === 'nonGroupUsers') {
      updatedGroupUsers = groupUsers.concat(user)
      updatedNonGroupUsers = nonGroupUsers.filter(item => item.userNo !== user.userNo)
      response = await addGroupUsers(selectedGroupNo, user.userNo)
    }

    if (response.result === 'SUCCESS') {
      this.setState({
        groupUsers: updatedGroupUsers,
        nonGroupUsers: updatedNonGroupUsers,
      })
    } else {
      Modal.error({
        title: '에러가 발생되었습니다.',
        content: response.message,
      })
    }
  }

  render() {
    const { groups, groupUsers, nonGroupUsers, isLoadingGroupList, groupModal } = this.state
    return (
      <>
        <Row gutter={16}>
          <Col span={10}>
            <Card
              title={
                <Row>
                  <Col span={12} style={{ textAlign: 'left' }}>
                    {
                      <>
                        Group List&nbsp;
                        <Button size={'small'} ghost={true} onClick={this.showModalForm('add', null)}>
                          <Icon type="folder-add" theme="twoTone" />
                        </Button>
                      </>
                    }
                  </Col>
                  <Col span={12} style={{ textAlign: 'right' }}>
                    <Icon type="sync" onClick={this.handleReloadGroupList} spin={isLoadingGroupList} />
                  </Col>
                </Row>
              }
            >
              <GroupList groups={groups} handleGroupSelect={this.handleGroupSelect} />
            </Card>
          </Col>
          <Col span={14}>
            <Card title={'Users in the Group'}>
              <UserList userType={'groupUsers'} users={groupUsers} manageUsers={this.manageUsers} />
            </Card>
            <br />
            <Card title={'Users Not in the Group'}>
              <UserList userType={'nonGroupUsers'} users={nonGroupUsers} manageUsers={this.manageUsers} />
            </Card>
          </Col>
        </Row>
        <Modal
          title={groupModal.modalType === 'add' ? '그룹등록' : '그룹수정'}
          visible={groupModal.visible}
          footer={null}
          closable={false}
          onCancel={this.handleModalCancel}
        >
          <GroupForm groupModal={groupModal} handleModalCancel={this.handleModalCancel} />
        </Modal>
      </>
    )
  }
}

export default UserGroup
