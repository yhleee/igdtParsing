import * as React from 'react'
import { Card, Col, Icon, Row } from 'antd'
import UserMenuTree from './UserMenuTree'
import UserMenuGroup from './UserMenuGroup'
import {
  fetchAuthorizedGroup,
  fetchUnauthorizedGroup,
  fetchUserMenuAuthority,
  updateAuthority,
} from '../../services/authority/authority'

interface IProps {}
interface IState {
  menuData: any
  selectedMenuNo: any
  authorizedGroups: any
  unauthorizedGroups: any
  isLoadingMenuTree: any
}

class Authority extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      menuData: [],
      selectedMenuNo: undefined,
      authorizedGroups: [],
      unauthorizedGroups: [],
      isLoadingMenuTree: false,
    }
  }

  sleep = time => {
    return new Promise(resolve => setTimeout(resolve, time))
  }

  async componentDidMount() {
    this.loadMenuTree()
  }

  loadMenuTree = async () => {
    const userMenu = await fetchUserMenuAuthority()
    const { menuData, isLoadingMenuTree, selectedMenuNo, authorizedGroups, unauthorizedGroups } = this.state
    this.setState({
      menuData: userMenu,
      isLoadingMenuTree: false,
      selectedMenuNo: undefined,
      authorizedGroups: [],
      unauthorizedGroups: [],
    })
  }

  handleReloadMenu = async () => {
    this.setState({ isLoadingMenuTree: true })
    this.sleep(300).then(async () => {
      await this.loadMenuTree()
    })
  }

  handleMenuSelect = async menuNos => {
    const { authorizedGroups, unauthorizedGroups, selectedMenuNo } = this.state
    const menuNo = menuNos.pop()

    // 루트노드 선택시
    if (menuNo === '-1') {
      this.setState({
        authorizedGroups: [],
        unauthorizedGroups: [],
        selectedMenuNo: undefined,
      })
      return
    }
    // 권한 보유 그룹 조회
    const authorizedUserGroups = await fetchAuthorizedGroup(menuNo)
    // 권한 미보유 그룹조회
    const unauthorizedUserGroups = await fetchUnauthorizedGroup(menuNo)
    this.setState({
      authorizedGroups: authorizedUserGroups,
      unauthorizedGroups: unauthorizedUserGroups,
      selectedMenuNo: menuNo,
    })
  }

  manageGroups = async (groupType, group) => {
    const { authorizedGroups, unauthorizedGroups, selectedMenuNo } = this.state
    let updatedAuthorizedGroups = undefined
    let updatedUnauthorizedGroups = undefined
    if (groupType === 'authorizedGroups') {
      updatedAuthorizedGroups = authorizedGroups.filter(item => item.groupNo !== group.groupNo)
      updatedUnauthorizedGroups = unauthorizedGroups.concat(group)
    } else if (groupType === 'unauthorizedGroups') {
      updatedAuthorizedGroups = authorizedGroups.concat(group)
      updatedUnauthorizedGroups = unauthorizedGroups.filter(item => item.groupNo !== group.groupNo)
    }

    this.setState({
      authorizedGroups: updatedAuthorizedGroups,
      unauthorizedGroups: updatedUnauthorizedGroups,
    })

    const userMenuAuthority = {
      menuNo: selectedMenuNo,
      authorizedGroups: updatedAuthorizedGroups,
      unauthorizedGroups: updatedUnauthorizedGroups,
    }

    await updateAuthority(userMenuAuthority)
  }

  render() {
    const { menuData, authorizedGroups, unauthorizedGroups, isLoadingMenuTree } = this.state
    return (
      <>
        <Row gutter={16}>
          <Col span={10}>
            <Card
              title={
                <Row>
                  <Col span={12} style={{ textAlign: 'left' }}>
                    Menu Tree
                  </Col>
                  <Col span={12} style={{ textAlign: 'right' }}>
                    <Icon type="sync" onClick={this.handleReloadMenu} spin={isLoadingMenuTree} />
                  </Col>
                </Row>
              }
            >
              <UserMenuTree userMenus={menuData} handleMenuSelect={this.handleMenuSelect} />
            </Card>
          </Col>
          <Col span={14}>
            <Card title={'Authorized Groups'}>
              <UserMenuGroup
                groupType={'authorizedGroups'}
                groups={authorizedGroups}
                manageGroups={this.manageGroups}
              />
            </Card>
            <br />
            <Card title={'Unauthorized Groups'}>
              <UserMenuGroup
                groupType={'unauthorizedGroups'}
                groups={unauthorizedGroups}
                manageGroups={this.manageGroups}
              />
            </Card>
          </Col>
        </Row>
      </>
    )
  }
}

export default Authority
