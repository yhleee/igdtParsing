import * as React from 'react'
import { Button, Icon, Modal, Tree } from 'antd'
import UserMenuForm from './UserMenuForm'

import { deleteMenu } from '../../services/authority/menu'

const { TreeNode } = Tree

const { confirm } = Modal

interface IProps {
  userMenus: any
  handleMenuSelect: any
}
interface IState {
  menuModal: any
}

class UserMenuTree extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {
      menuModal: {
        visible: false,
        modalType: '', // add or edit
        selectedMenu: {},
      },
    }
  }

  /*
  state = {
    menuModal: {
      visible: false,
      modalType: '', // add or edit
      selectedMenu: {},
    },
  }
   */

  showMenuNode = (key, event) => {
    this.props.handleMenuSelect(key)
  }

  showModalForm = (modalType, userMenu) => e => {
    e.stopPropagation()
    const { menuModal } = this.state
    this.setState({
      menuModal: {
        visible: true,
        // tslint:disable-next-line:object-shorthand-properties-first
        modalType,
        selectedMenu: userMenu,
      },
    })
  }
  showModalConfirm = userMenu => {
    const findChildrenMenuNo = this.findChildrenMenuNo
    return e => {
      e.stopPropagation()
      confirm({
        title: <>{userMenu.menuName}를 삭제하시겠습니까?</>,
        content: '하위 메뉴가 있을 경우 같이 삭제됩니다.',
        async onOk() {
          const foundMenuNos = []
          findChildrenMenuNo(foundMenuNos, userMenu)
          const result = await deleteMenu(foundMenuNos)
          if (result === 'SUCCESS') {
            Modal.success({
              content: '삭제되었습니다.',
            })
            location.reload()
          } else {
            Modal.error({
              content: '에러가 발생하였습니다.',
            })
          }
        },
        onCancel() {},
      })
    }
  }

  findChildrenMenuNo = (foundNos, userMenu) => {
    if (userMenu.children && userMenu.children.length > 0) {
      userMenu.children.forEach(menu => {
        this.findChildrenMenuNo(foundNos, menu)
      })
    }
    foundNos.push(userMenu.menuNo)
  }

  handleModalCancel = () => {
    const { menuModal } = this.state
    this.setState({
      menuModal: {
        ...menuModal,
        visible: false,
      },
    })
  }

  renderMenuNodes = data =>
    data.map(item => {
      if (item.children && item.children.length > 0) {
        return (
          <TreeNode
            title={
              <>
                {item.menuName}&nbsp;
                <Button size={'small'} ghost={true} onClick={this.showModalForm('add', item)}>
                  <Icon type="folder-add" theme="twoTone" />
                </Button>
                <Button size={'small'} ghost={true} onClick={this.showModalForm('edit', item)}>
                  <Icon type="edit" theme="twoTone" />
                </Button>
                <Button size={'small'} ghost={true} onClick={this.showModalConfirm(item)}>
                  <Icon type="delete" theme="twoTone" />
                </Button>
              </>
            }
            key={item.menuNo}
            isLeaf={item.leaf}
            dataRef={item}
          >
            {this.renderMenuNodes(item.children)}
          </TreeNode>
        )
      }
      return (
        <TreeNode
          title={
            <>
              {item.menuName}&nbsp;
              <Button size={'small'} ghost={true} onClick={this.showModalForm('add', item)}>
                <Icon type="folder-add" theme="twoTone" />
              </Button>
              <Button size={'small'} ghost={true} onClick={this.showModalForm('edit', item)}>
                <Icon type="edit" theme="twoTone" />
              </Button>
              <Button size={'small'} ghost={true} onClick={this.showModalConfirm(item)}>
                <Icon type="delete" theme="twoTone" />
              </Button>
            </>
          }
          key={item.menuNo}
          isLeaf={item.leaf}
          dataRef={item}
        />
      )
    })

  render() {
    const { userMenus } = this.props
    const { menuModal } = this.state
    return (
      <>
        <Tree showLine={true} onSelect={this.showMenuNode}>
          <TreeNode
            title={
              <>
                {'Root'}&nbsp;
                <Button size={'small'} ghost={true} onClick={this.showModalForm('add', undefined)}>
                  <Icon type="folder-add" theme="twoTone" />
                </Button>
              </>
            }
            key={'-1'}
            isLeaf={userMenus.length === 0}
          >
            {this.renderMenuNodes(userMenus)}
          </TreeNode>
          {/*{this.renderMenuNodes(userMenus)}*/}
        </Tree>
        <Modal
          title={menuModal.modalType === 'add' ? '메뉴등록' : '메뉴수정'}
          visible={menuModal.visible}
          footer={null}
          closable={false}
          onCancel={this.handleModalCancel}
        >
          <UserMenuForm menuModal={menuModal} handleModalCancel={this.handleModalCancel} />
        </Modal>
      </>
    )
  }
}

export default UserMenuTree
