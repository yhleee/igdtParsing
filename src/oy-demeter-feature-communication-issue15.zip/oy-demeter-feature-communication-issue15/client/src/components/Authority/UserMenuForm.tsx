import * as React from 'react'
import { Button, Col, Form, Input, InputNumber, Row, Switch } from 'antd'

import { addMenu, updateMenu } from '../../services/authority/menu'

interface IProps {
  form: any
  menuModal: any
  handleModalCancel: any
}
interface IState {}

class UserMenuForm extends React.Component<IProps, IState> {
  handleSubmit = e => {
    e.preventDefault()
    const { selectedMenu, modalType } = this.props.menuModal
    console.log(selectedMenu)
    this.props.form.validateFields(async (err, values) => {
      if (!err) {
        console.log('Received values of form: ', values)
        if (modalType === 'edit') {
          values.menuNo = selectedMenu.menuNo
          values.level = selectedMenu.level
          await updateMenu(values)
        } else {
          values.upperMenuNo = selectedMenu && selectedMenu.menuNo
          values.level = (selectedMenu && selectedMenu.level && selectedMenu.level + 1) || 1
          await addMenu(values)
        }
      }
    })
    // this.resetAndClose()
    location.reload()
  }

  resetAndClose = () => {
    const { handleModalCancel } = this.props
    const { resetFields } = this.props.form
    resetFields()
    handleModalCancel()
  }

  render() {
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }

    const buttonItemLayout = {
      wrapperCol: { span: 14, offset: 4 },
    }

    const { getFieldDecorator, setFieldsValue } = this.props.form

    const { selectedMenu, modalType } = this.props.menuModal

    return (
      <>
        <Form onSubmit={this.handleSubmit}>
          <Form.Item label="메뉴명" {...formItemLayout}>
            {getFieldDecorator('menuName', {
              rules: [{ required: true, message: '메뉴명은 필수 값 입니다.' }],
              initialValue: modalType === 'edit' ? selectedMenu.menuName : undefined,
            })(<Input placeholder="메뉴명을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="메뉴 아이콘" {...formItemLayout}>
            {getFieldDecorator('menuIconName', {
              initialValue: modalType === 'edit' ? selectedMenu.iconName : undefined,
            })(<Input placeholder="아이콘명을 입력하세요." />)}
          </Form.Item>
          <Form.Item label="메뉴 노출 순서" {...formItemLayout}>
            {getFieldDecorator('sortSeq', { initialValue: modalType === 'edit' ? selectedMenu.sortSeq : 1 })(
              <InputNumber min={1} max={100} />,
            )}
          </Form.Item>
          <Form.Item label="메뉴 URL" {...formItemLayout}>
            {getFieldDecorator('menuUrl', { initialValue: modalType === 'edit' ? selectedMenu.url : undefined })(
              <Input placeholder="메뉴 경로(URL)를 입력하세요." />,
            )}
          </Form.Item>
          <Form.Item label="사용여부" {...formItemLayout}>
            {getFieldDecorator('useYn', {
              valuePropName: 'checked',
              initialValue: modalType === 'edit' ? selectedMenu.usable : true,
            })(<Switch />)}
          </Form.Item>
          <Form.Item {...buttonItemLayout}>
            <Row>
              <Col span={24} style={{ textAlign: 'center' }}>
                <Button type="default" onClick={this.resetAndClose}>
                  취소
                </Button>
                <Button type="primary" htmlType="submit" style={{ marginLeft: 8 }}>
                  {modalType === 'add' ? '등록' : '수정'}
                </Button>
              </Col>
            </Row>
          </Form.Item>
        </Form>
      </>
    )
  }
}

export default Form.create<IProps>()(UserMenuForm)
