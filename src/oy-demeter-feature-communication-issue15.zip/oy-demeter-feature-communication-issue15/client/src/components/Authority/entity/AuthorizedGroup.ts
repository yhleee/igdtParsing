export interface IAuthorizedGroup {
  groupNo: number
  groupName: string
}
