export interface IUser {
  userNo: number
  loginId: string
}
