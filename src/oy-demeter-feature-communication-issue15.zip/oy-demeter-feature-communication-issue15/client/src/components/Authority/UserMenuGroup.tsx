import * as React from 'react'
import { Icon, List } from 'antd'
import InfiniteScroll from 'react-infinite-scroller'
import { IAuthorizedGroup } from './entity/AuthorizedGroup'

interface IProps {
  groupType: any
  groups: IAuthorizedGroup[]
  manageGroups: any
}
interface IState {}

class UserMenuGroup extends React.Component<IProps, IState> {
  constructor(props) {
    super(props)
    this.state = {}
  }

  handleGroup = group => () => {
    const { groupType, manageGroups } = this.props
    manageGroups(groupType, group)
  }

  render() {
    const { groupType, groups } = this.props
    return (
      <div
        style={{
          border: '1px solid #e8e8e8',
          borderRadius: '4px',
          overflow: 'auto',
          padding: '8px 24px',
          height: '250px',
        }}
      >
        <InfiniteScroll initialLoad={false} pageStart={0} loadMore={() => {}} hasMore={false} useWindow={false}>
          <List
            dataSource={groups}
            renderItem={group => (
              <List.Item key={group.groupNo}>
                <List.Item.Meta
                  title={
                    <>
                      <span>{group.groupName}</span>&nbsp;
                      {groupType === 'authorizedGroups' ? (
                        <Icon type="down-square" theme="twoTone" onClick={this.handleGroup(group)} />
                      ) : (
                        <Icon type="up-square" theme="twoTone" onClick={this.handleGroup(group)} />
                      )}
                    </>
                  }
                />
              </List.Item>
            )}
          />
        </InfiniteScroll>
      </div>
    )
  }
}

export default UserMenuGroup
