import * as React from 'react'
import { Link, withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import { RootState } from 'common/reducer'
import { fetchLayoutTitle, LayoutTitleState, updateLayoutTile } from './ducks/LayoutTitle'
import { DynamicCx } from 'common/types'
import { alertPopup, styling } from 'common/utils'
import { History } from 'history'
import * as s from './Layout.scss'
import PageNotFound from '../Error/PageNotFound'
import { fetchUserInfo, resetUserInfo, UserInfoState } from './ducks/UserInfo'
import { Layout, Menu, Breadcrumb, Icon, Row, Col, Avatar, Button } from 'antd'
import { getUserAuthorityMenuList } from '../../services/authority/menu'
import { IUserAuthorityMenu } from './entity/CommonLayout'

const { SubMenu } = Menu
const { Header, Content, Sider } = Layout

interface OwnProps {
  cx?: DynamicCx
  children?: any
  history?: History
}

interface StateProps {
  layoutTitle: LayoutTitleState
  userInfo: UserInfoState
}

interface DispatchProps {
  fetchLayoutTitle: typeof fetchLayoutTitle
  updateLayoutTile: typeof updateLayoutTile
  fetchUserInfo: typeof fetchUserInfo
  resetUserInfo: typeof resetUserInfo
}

interface OwnState {
  visible: boolean
  displayUserAuthorityMenuList: IUserAuthorityMenu[]
}

type Props = StateProps & OwnProps & DispatchProps

class CommonLayout extends React.Component<Props, OwnState> {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      displayUserAuthorityMenuList: null,
    }
  }

  async componentDidMount() {
    this.getInitAuthorityMenuList()
  }

  getInitAuthorityMenuList = async () => {
    const displayUserAuthorityMenuList: IUserAuthorityMenu[] = []

    const userAuthorityMenuList = await getUserAuthorityMenuList()
    userAuthorityMenuList.forEach(element => displayUserAuthorityMenuList.push(element))
    this.setState({
      displayUserAuthorityMenuList,
    })
  }

  handleClick = e => {
    this.props.history.push(`/app/${e.key}`)
  }

  handleLogoutBtn = () => {
    this.props.history.push(`/app/login`)
  }

  handleHomeBtn = () => {
    this.props.history.push(`/app/home`)
  }

  render() {
    const { cx, children, layoutTitle, history } = this.props
    const { displayUserAuthorityMenuList } = this.state
    const { name } = this.props.userInfo

    const pathName = history.location.pathname.replace('/app/', '')
    const pathNameArray = pathName.split('/')

    return (
      <Layout>
        <Header className="header">
          <Row>
            <Col xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }}>
              <div className={cx('logo_wrap')}>
                <div className={cx('logo')}>
                  <img src="/images/om_logo.png" />
                </div>
              </div>
            </Col>
            <Col xs={{ span: 11, offset: 1 }} lg={{ span: 6, offset: 2 }}>
              <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['1']} style={{ lineHeight: '64px' }}>
                {/*<Menu.Item key="1">정보전략팀</Menu.Item>
                <Menu.Item key="2">소유권한 2</Menu.Item>
                <Menu.Item key="3">소유권한 3</Menu.Item>*/}
              </Menu>
            </Col>
            <Col xs={{ span: 5, offset: 1 }} lg={{ span: 6, offset: 2 }}>
              <div className={cx('user_info')}>
                <Avatar shape="square" icon="user" />
                &nbsp; <span>환영합니다</span>
                &nbsp;&nbsp; <Button onClick={this.handleHomeBtn}>Home</Button>
                &nbsp;&nbsp; <Button onClick={this.handleLogoutBtn}>Logout</Button>
              </div>
            </Col>
          </Row>
        </Header>
        <Layout>
          <Sider width={300} style={{ background: '#fff' }}>
            {/*<Menu
              onClick={this.handleClick}
              mode="inline"
              defaultSelectedKeys={['1']}
              defaultOpenKeys={['sub1']}
              style={{ height: '100%', borderRight: 0 }}
            >*/}
            <Menu
              onClick={this.handleClick}
              mode="inline"
              defaultSelectedKeys={['1']}
              defaultOpenKeys={['item_0']}
              style={{ height: '100%', borderRight: 0 }}
            >
              {displayUserAuthorityMenuList &&
                displayUserAuthorityMenuList.map(
                  (menuItem, index) =>
                    menuItem && menuItem.menuLevel === 1 ? (
                      <SubMenu
                        key={`item_${index}`}
                        title={
                          <span>
                            <Icon type={menuItem.menuIconName} />
                            {menuItem.menuName}
                          </span>
                        }
                      >
                        {displayUserAuthorityMenuList.map(
                          (subMenuItem, index) =>
                            subMenuItem.menuLevel === 2 && subMenuItem.upperMenuNo === menuItem.menuNo ? (
                              <Menu.Item key={subMenuItem.menuUrl}>{subMenuItem.menuName}</Menu.Item>
                            ) : (
                              ''
                            ),
                        )}
                      </SubMenu>
                    ) : (
                      ''
                    ),
                )}
              {/*<SubMenu
                key="sub1"
                title={
                  <span>
                    <Icon type="account-book" />
                    정산
                  </span>
                }
              >
                <Menu.Item key="settle/teamProject">정보전략팀 투자/비용 취합</Menu.Item>
                <Menu.Item key="settle/asset">자산이체(e-Acc양식)</Menu.Item>
                <Menu.Item key="settle/hqInvestStore">신규/리뉴얼 매장 장비 투자(본사)</Menu.Item>
                <Menu.Item key="settle/ptInvestStore">신규/리뉴얼 매장 장비 투자(업체별)</Menu.Item>
              </SubMenu>*/}
              {/*<SubMenu
                key="sub2"
                title={
                  <span>
                    <Icon type="laptop" />
                    Etc
                  </span>
                }
              >
                <Menu.Item key="querybrowser">Query Browser</Menu.Item>
              </SubMenu>*/}
            </Menu>
          </Sider>
          <Layout style={{ padding: '0 24px 24px' }}>
            <Breadcrumb style={{ margin: '16px 0' }}>
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              {pathNameArray.map((pathName, index) => (
                <Breadcrumb.Item key={`menu_path_${index}`}>{pathName}</Breadcrumb.Item>
              ))}
            </Breadcrumb>
            <Content
              style={{
                background: '#fff',
                padding: 24,
                margin: 0,
                minHeight: 280,
              }}
            >
              {children ? children : <PageNotFound />}
            </Content>
          </Layout>
        </Layout>
      </Layout>
    )
  }
}

export default connect<StateProps, DispatchProps, OwnProps>(
  (state: RootState) => ({
    layoutTitle: state.layoutTitle,
    userInfo: state.userInfo,
  }),
  {
    fetchLayoutTitle,
    updateLayoutTile,
    fetchUserInfo,
    resetUserInfo,
  },
)(styling(s)(withRouter(CommonLayout)))
