export interface IUserAuthorityMenu {
  menuNo: number
  menuName: string
  menuIconName: string
  upperMenuNo: number
  menuLevel: number
  sortSeq: number
  menuUrl: string
  useYn: string
}
