export default {
  protocol: 'http',
  host: '127.0.0.1',
  port: 9090,
  clientPort: 5000,
}
