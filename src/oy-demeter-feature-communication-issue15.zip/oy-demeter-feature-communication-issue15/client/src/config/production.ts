export default {
  protocol: 'https',
  host: '',
  port: 80,
}
