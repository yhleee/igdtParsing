import { axios } from 'common/utils'

export const getHqInvestStoreList = async param => {
  const response = await axios.get('/api/settle/hqInvestStores', {
    params: param,
  })
  return response && response.data && response.data.contents
}

export const getHqInvestStoreAssetList = async (investStoreNo, param) => {
  const response = await axios.get(`/api/settle/hqInvestStore/${investStoreNo}/assets`, {
    params: param,
  })
  return response && response.data && response.data.contents
}

export const setHqInvestStore = async insertInvestStoreForm => {
  const response = await axios.post('/api/settle/hqInvestStore', insertInvestStoreForm)
  return response && response.data && response.data.message
}

export const putHqInvestStore = async (investStoreNo, updateInvestStoreForm) => {
  const response = await axios.put(`/api/settle/hqInvestStore/${investStoreNo}`, updateInvestStoreForm)
  return response && response.data && response.data.message
}

export const delHqInvestStore = async investStoreNo => {
  const response = await axios.delete(`/api/settle/hqInvestStore/${investStoreNo}`)
  return response && response.data && response.data.message
}

export const getPtInvestStoreList = async param => {
  const response = await axios.get('/api/settle/ptInvestStores', {
    params: param,
  })
  return response && response.data && response.data.contents
}

export const getPtInvestStoreCSVDownLoad = async param => {
  const response = await axios.get('/api/settle/ptInvestStores/excelDownLoad', {
    params: param,
    responseType: 'arraybuffer',
  })
  return response && response.data
}

export const ptInvestStoreCSVUpLoad = async formData => {
  const response = await axios.post('/api/settle/ptInvestStores/drmExcelUpLoad', formData, {
    headers: {
      'content-type': 'multipart/form-data',
    },
  })
  return response && response.data
}

export const updateInvestStoreActiveType = async param => {
  const response = await axios.patch(
    `/api/settle/ptInvestStores/investStoreActiveType?investStoreActiveType=${param.investStoreActiveType}`,
  )
  return response && response.data && response.data.message
}
