import { axios } from 'common/utils'

export const getTeamProjectList = async param => {
  const response = await axios.get('/api/settle/teamProjects', {
    params: param,
  })
  return response && response.data && response.data.contents
}

export const getTeamProjectActiveTypeNCnt = async () => {
  const response = await axios.get('/api/settle/teamProject/activeTypeCnt')
  return response && response.data && response.data.contents
}

export const setTeamProject = async teamProject => {
  const response = await axios.post('/api/settle/teamProject', teamProject)
  return response && response.data && response.data.message
}

export const updateTeamProject = async teamProject => {
  const response = await axios.put(`/api/settle/teamProject/${teamProject.teamProjectNo}`, teamProject)
  return response && response.data && response.data.message
}

export const delTeamProject = async teamProjectNo => {
  const response = await axios.delete(`/api/settle/teamProject/${teamProjectNo}`)
  return response && response.data && response.data.message
}

export const updateTeamProjectActiveType = async param => {
  const response = await axios.patch(
    `/api/settle/teamProjects/teamProjectActiveType?teamProjectActiveType=${
      param.teamProjectActiveType
    }&teamProjectRegYearMonth=${param.teamProjectRegYearMonth}`,
  )
  return response && response.data && response.data.message
}

export const getTeamProjectCSVDownLoad = async param => {
  const response = await axios.get('/api/settle/teamProjects/excelDownLoad', {
    params: param,
    responseType: 'arraybuffer',
  })
  return response && response.data
}

export const setTeamProjectCSVUpLoad = async formData => {
  const response = await axios.post('/api/settle/teamProjects/drmExcelUpLoad', formData, {
    headers: {
      'content-type': 'multipart/form-data',
    },
  })
  return response && response.data
}
