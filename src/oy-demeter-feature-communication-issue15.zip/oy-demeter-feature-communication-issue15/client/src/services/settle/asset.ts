import { axios } from 'common/utils'

export const getAssetList = async param => {
  const response = await axios.get('/api/settle/assets', {
    params: param,
  })
  return response && response.data && response.data.contents
}

export const getAssetCSVDownLoad = async param => {
  const response = await axios.get('/api/settle/assets/excelDownLoad', {
    params: param,
    responseType: 'arraybuffer',
  })
  return response && response.data
}

export const assetCSVUpLoad = async formData => {
  const response = await axios.post('/api/settle/assets/drmExcelUpLoad', formData, {
    headers: {
      'content-type': 'multipart/form-data',
    },
  })
  return response && response.data
}
