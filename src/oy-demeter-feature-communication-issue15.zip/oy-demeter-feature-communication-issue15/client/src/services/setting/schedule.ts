import { axios } from 'common/utils'

export const getScheduleFireWallList = async () => {
  const response = await axios.get('/api/setting/schedule/fireWalls')
  return response && response.data
}

export const setScheduleFireWall = async param => {
  const response = await axios.post('/api/setting/schedule/fireWalls', param)
  return response && response.data
}
