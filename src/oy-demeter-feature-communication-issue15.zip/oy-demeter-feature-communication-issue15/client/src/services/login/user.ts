import { axios } from '../../common/utils'

export const setUser = async userParam => {
  const response = await axios.post('/api/setting/user', userParam)
  return response && response.data && response.data.result
}

export const getUserInfo = async param => {
  const response = await axios.get(`/api/setting/user`, {
    params: param,
  })
  return response && response.data && response.data.contents
}
