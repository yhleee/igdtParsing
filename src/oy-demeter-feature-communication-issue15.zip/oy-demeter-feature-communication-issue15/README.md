### Prerequisites
* JDK 10
* Node 8.9.0 or above
* Yarn 1.3.2 or above

### Run
- local server
  ```
  // client
  cd client
  yarn start:demeter
  
  // server
  cd server
  gradlew clean bootRun -Dspring.profiles.active=local -Dfile.encoding=UTF-8
  ```
- build (dev, prod 올리기 전)
  ```
  cd server
  gradlew yarnBuild
  ```  
- dev, prod
  ```
  // dev
  cd app
  jdk-11/bin/java -jar oy-demeter.jar -Denv=dev -Dspring.profiles.active=dev -Dfile.encoding=UTF-8 -Xms1024M -Xmx2048M -XX:NewSize=512m -XX:MaxNewSize=512m -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:/home/olive/app/logs/gc.log -XX:+UseGCLogFileRotation -XX:GCLogFileSize=1m -XX:NumberOfGCLogFiles=100 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=jvm.hprof &
  
  // prod
  cd app
  jdk-11/bin/java -jar oy-demeter.jar -Denv=production -Dspring.profiles.active=production -Dfile.encoding=UTF-8 -Xms1024M -Xmx2048M -XX:NewSize=512m -XX:MaxNewSize=512m -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:/home/olive/app/logs/gc.log -XX:+UseGCLogFileRotation -XX:GCLogFileSize=1m -XX:NumberOfGCLogFiles=100 -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=jvm.hprof &
  ```
  
    
### Built with
- Backend
  - spring framework 5
  - spring boot 2
  - gradle  
- Frontend 
  - react 16
  - npm, yarn
  - webpack
  - ant design - react ui framework

